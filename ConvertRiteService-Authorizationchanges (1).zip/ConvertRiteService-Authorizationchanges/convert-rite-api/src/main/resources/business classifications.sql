SELECT PBCA.CLASSIFICATION_ID                         "CLASSIFICATION_ID"
      ,APS.VENDOR_ID                                  "VENDOR_ID"
      ,APS.SEGMENT1                                   "VENDOR_NUM"
      ,APS.VENDOR_NAME                                "VENDOR_NAME"
						,PBCA.LOOKUP_CODE                               "CLASSIFICATION_LOOKUP_CODE"
						,PBCA.CERTIFYING_AGENCY                         "CERTIFYING_AGENCY_NAME"
						,PBCA.CERTIFICATE_NUMBER                        "CERTIFICATE_NUMBER"
						,PBCA.START_DATE_ACTIVE                         "START_DATE"
						,PBCA.EXPIRATION_DATE                           "EXPIRATION_DATE"
      ,HP_CONTACT.PARTY_ID                            "PROVIDED_BY_CONTACT_ID"
						,HP_CONTACT.PERSON_FIRST_NAME                   "PROVIDED_BY_CONTACT_FIRST_NAME"
      ,HP_CONTACT.PERSON_LAST_NAME                    "PROVIDED_BY_CONTACT_LAST_NAME"
      ,HP_CONTACT.EMAIL_ADDRESS                       "PROVIDED_BY_CONTACT_EMAIL"
						,APS.ATTRIBUTE_CATEGORY                          "ATTRIBUTE_CATEGORY"
						,APS.ATTRIBUTE1                                  "ATTRIBUTE1"
						,APS.ATTRIBUTE2                                  "ATTRIBUTE2"
						,APS.ATTRIBUTE3                                  "ATTRIBUTE3"
						,APS.ATTRIBUTE4                                  "ATTRIBUTE4"
						,APS.ATTRIBUTE5                                  "ATTRIBUTE5"
						,APS.ATTRIBUTE6                                  "ATTRIBUTE6"
						,APS.ATTRIBUTE7                                  "ATTRIBUTE7"
						,APS.ATTRIBUTE8                                  "ATTRIBUTE8"
						,APS.ATTRIBUTE9                                  "ATTRIBUTE9"
						,APS.ATTRIBUTE10                                 "ATTRIBUTE10"
						,APS.ATTRIBUTE11                                 "ATTRIBUTE11"
						,APS.ATTRIBUTE12                                 "ATTRIBUTE12"
						,APS.ATTRIBUTE13                                 "ATTRIBUTE13"
						,APS.ATTRIBUTE14                                 "ATTRIBUTE14"
						,APS.ATTRIBUTE15                                 "ATTRIBUTE15"
						,APS.GLOBAL_ATTRIBUTE_CATEGORY                   "GLOBAL_ATTRIBUTE_CATEGORY"
						,APS.GLOBAL_ATTRIBUTE1                           "GLOBAL_ATTRIBUTE1"
						,APS.GLOBAL_ATTRIBUTE2                           "GLOBAL_ATTRIBUTE2"
						,APS.GLOBAL_ATTRIBUTE3                           "GLOBAL_ATTRIBUTE3"
						,APS.GLOBAL_ATTRIBUTE4                           "GLOBAL_ATTRIBUTE4"
						,APS.GLOBAL_ATTRIBUTE5                           "GLOBAL_ATTRIBUTE5"
						,APS.GLOBAL_ATTRIBUTE6                           "GLOBAL_ATTRIBUTE6"
						,APS.GLOBAL_ATTRIBUTE7                           "GLOBAL_ATTRIBUTE7"
						,APS.GLOBAL_ATTRIBUTE8                           "GLOBAL_ATTRIBUTE8"
						,APS.GLOBAL_ATTRIBUTE9                           "GLOBAL_ATTRIBUTE9"
						,APS.GLOBAL_ATTRIBUTE10                          "GLOBAL_ATTRIBUTE10"
		FROM AP_SUPPLIERS@{0} APS
						,POS_BUS_CLASS_ATTR@{0} PBCA
      --,FND_LOOKUP_VALUES FLV
						,HZ_PARTIES@{0} HP
						,HZ_RELATIONSHIPS@{0} HR
						,HZ_PARTIES@{0} HP_CONTACT
	WHERE 1=1
   AND APS.SEGMENT1 = '5033'
	  AND APS.VENDOR_ID = PBCA.VENDOR_ID
   --AND FLV.LOOKUP_TYPE = 'POS_BUSINESS_CLASSIFICATIONS'
   --AND FLV.LOOKUP_CODE = PBCA.LOOKUP_CODE
			AND APS.PARTY_ID = HR.SUBJECT_ID
			AND HR.OBJECT_ID = HP_CONTACT.PARTY_ID
			AND HR.PARTY_ID = HP.PARTY_ID
   AND HR.RELATIONSHIP_CODE = 'CONTACT'
			AND HR.OBJECT_TABLE_NAME = 'HZ_PARTIES'
   --AND ASU.SEGMENT1=5033
   