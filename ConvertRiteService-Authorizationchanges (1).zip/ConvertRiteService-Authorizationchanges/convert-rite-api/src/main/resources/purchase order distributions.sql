SELECT pda.po_distribution_id                                        interface_distribution_key
						,pda.line_location_id                                          interface_line_location_key
						,pda.distribution_num                                          distribution_num
						,(SELECT hl.location_code
										FROM hr_locations@{0} hl
									WHERE hl.location_id = pda.deliver_to_location_id)          deliver_to_location
						,(SELECT papf.full_name
										FROM per_all_people_f@{0} papf
									WHERE papf.person_id = pda.deliver_to_person_id
											AND sysdate BETWEEN NVL(TRUNC(papf.effective_start_date)
											                       ,TRUNC(sysdate) - 1) 
																											AND NVL(TRUNC(papf.effective_end_date)
																											       ,TRUNC(sysdate) + 1))              deliver_to_person_full_name
						,pda.destination_subinventory                                  destination_subinventory
						,NULL                                                          amount_ordered
						,(pda.quantity_ordered - pda.quantity_delivered)               quantity_ordered
						,glcc.segment1                                                 charge_account_segment1
						,glcc.segment2                                                 charge_account_segment2
						,glcc.segment3                                                 charge_account_segment3
						,glcc.segment4                                                 charge_account_segment4
						,glcc.segment5                                                 charge_account_segment5
						,glcc.segment6                                                 charge_account_segment6
						,glcc.segment7                                                 charge_account_segment7
						,glcc.segment8                                                 charge_account_segment8
						,glcc.segment9                                                 charge_account_segment9
						,glcc.segment10                                                charge_account_segment10
						,NULL                                                          charge_account_segment11
						,NULL                                                          charge_account_segment12
						,NULL                                                          charge_account_segment13
						,NULL                                                          charge_account_segment14
						,NULL                                                          charge_account_segment15
						,NULL                                                          charge_account_segment16
						,NULL                                                          charge_account_segment17
						,NULL                                                          charge_account_segment18
						,NULL                                                          charge_account_segment19
						,NULL                                                          charge_account_segment20
						,NULL                                                          charge_account_segment21
						,NULL                                                          charge_account_segment22
						,NULL                                                          charge_account_segment23
						,NULL                                                          charge_account_segment24
						,NULL                                                          charge_account_segment25
						,NULL                                                          charge_account_segment26
						,NULL                                                          charge_account_segment27
						,NULL                                                          charge_account_segment28
						,NULL                                                          charge_account_segment29
						,NULL                                                          charge_account_segment30
						,pda.destination_context                                       destination_context
						,(SELECT ppa.segment1
										FROM pa_projects_all@{0} ppa
									WHERE ppa.project_id = pda.project_id)                      project       ---  REVIEW AND RETAIN OR EXCLUDE BASED ON PROJECT EXISITENCE 
						,(SELECT pt.task_number
										FROM pa_tasks@{0} pt
									WHERE pt.task_id = pda.task_id)                             task                   ---  REVIEW AND RETAIN OR EXCLUDE BASED ON PROJECT TASK EXISITENCE 
						,pda.expenditure_item_date                                     pjc_expenditure_item_date ---  REVIEW AND RETAIN OR EXCLUDE BASED ON PROJECT EXISITENCE 
						,pda.expenditure_type                                          expenditure               ---  REVIEW AND RETAIN OR EXCLUDE BASED ON PROJECT EXISITENCE 
						,pda.expenditure_organization_id                               expenditure_organization  ---  REVIEW AND RETAIN OR EXCLUDE BASED ON PROJECT EXISITENCE   
						,NULL                                                          pjc_billable_flag
						,NULL                                                          pjc_capitalizable_flag
						,NULL                                                          pjc_work_type
						,NULL                                                          pjc_reserved_attribute1
						,NULL                                                          pjc_reserved_attribute2
						,NULL                                                          pjc_reserved_attribute3
						,NULL                                                          pjc_reserved_attribute4
						,NULL                                                          pjc_reserved_attribute5
						,NULL                                                          pjc_reserved_attribute6
						,NULL                                                          pjc_reserved_attribute7
						,NULL                                                          pjc_reserved_attribute8
						,NULL                                                          pjc_reserved_attribute9
						,NULL                                                          pjc_reserved_attribute10
						,NULL                                                          pjc_user_def_attribute1
						,NULL                                                          pjc_user_def_attribute2
						,NULL                                                          pjc_user_def_attribute3
						,NULL                                                          pjc_user_def_attribute4
						,NULL                                                          pjc_user_def_attribute5
						,NULL                                                          pjc_user_def_attribute6
						,NULL                                                          pjc_user_def_attribute7
						,NULL                                                          pjc_user_def_attribute8
						,NULL                                                          pjc_user_def_attribute9
						,NULL                                                          pjc_user_def_attribute10
						,pda.rate                                                      rate
						,pda.rate_date                                                 rate_date
						,pda.attribute_category                                        attribute_category
						,pda.attribute1                                                attribute1
						,pda.attribute2                                                attribute2
						,pda.attribute3                                                attribute3
						,pda.attribute4                                                attribute4
						,pda.attribute5                                                attribute5
						,pda.attribute6                                                attribute6
						,pda.attribute7                                                attribute7
						,pda.attribute8                                                attribute8
						,pda.attribute9                                                attribute9
						,pda.attribute10                                               attribute10
						,pda.attribute11                                               attribute11
						,pda.attribute12                                               attribute12
						,pda.attribute13                                               attribute13
						,pda.attribute14                                               attribute14
						,pda.attribute15                                               attribute15
						,NULL                                                          attribute16
						,NULL                                                          attribute17
						,NULL                                                          attribute18
						,NULL                                                          attribute19
						,NULL                                                          attribute20
						,NULL                                                          attribute_date1
						,NULL                                                          attribute_date2
						,NULL                                                          attribute_date3
						,NULL                                                          attribute_date4
						,NULL                                                          attribute_date5
						,NULL                                                          attribute_date6
						,NULL                                                          attribute_date7
						,NULL                                                          attribute_date8
						,NULL                                                          attribute_date9
						,NULL                                                          attribute_date10
						,NULL                                                          attribute_number1
						,NULL                                                          attribute_number2
						,NULL                                                          attribute_number3
						,NULL                                                          attribute_number4
						,NULL                                                          attribute_number5
						,NULL                                                          attribute_number6
						,NULL                                                          attribute_number7
						,NULL                                                          attribute_number8
						,NULL                                                          attribute_number9
						,NULL                                                          attribute_number10
						,NULL                                                          attribute_timestamp1
						,NULL                                                          attribute_timestamp2
						,NULL                                                          attribute_timestamp3
						,NULL                                                          attribute_timestamp4
						,NULL                                                          attribute_timestamp5
						,NULL                                                          attribute_timestamp6
						,NULL                                                          attribute_timestamp7
						,NULL                                                          attribute_timestamp8
						,NULL                                                          attribute_timestamp9
						,NULL                                                          attribute_timestamp10
						,(SELECT papf.email_address
										FROM per_all_people_f@{0} papf
									WHERE papf.person_id = pda.deliver_to_person_id
											AND TRUNC(sysdate) BETWEEN NVL(TRUNC(papf.effective_start_date)
											                              ,TRUNC(sysdate) - 1) 
																																		AND NVL(TRUNC(papf.effective_end_date)
																																		       ,TRUNC(sysdate) + 1))       deliver_to_person_email_addr
						,decode(pda.project_id,NULL,NULL,TRUNC(sysdate) )              budget_date
						,NULL                                                          pjc_contract_number
						,NULL                                                          pjc_funding_source
		FROM apps.po_headers_all@{0}              pha
						,apps.po_lines_all@{0}                pla
						,apps.po_line_locations_all@{0}       plla
						,apps.po_distributions_all@{0}        pda
						,apps.gl_code_combinations@{0}        glcc
	WHERE 1                                = 1
	  -- AND pha.po_header_id              = :po_header_id
			AND pha.type_lookup_code             = 'STANDARD'
			AND NVL(pha.closed_code,'OPEN')      = 'OPEN'              -- STATUS OF PO OPEN IN HEADER
			AND NVL(pla.closed_code,'OPEN')      = 'OPEN'              -- STATUS OF PO OPEN IN LINE
			AND NVL(plla.closed_code,'OPEN')     = 'OPEN'              -- STATUS OF PO OPEN IN LINE LOCATION
			AND NVL(pha.cancel_flag,'#')         != 'Y'                -- CANCEL FLAG <> Y
			AND NVL(pla.cancel_flag,'#')         != 'Y'                -- CANCEL FLAG <> Y
			AND NVL(plla.cancel_flag,'#')        != 'Y'                -- CANCEL FLAG <> Y
			AND pha.po_header_id                 = pla.po_header_id
			AND pha.org_id                       = pla.org_id
			AND pla.po_header_id                 = plla.po_header_id
			AND pla.po_line_id                   = plla.po_line_id
			AND pla.org_id                       = plla.org_id
			AND plla.po_header_id                = pda.po_header_id
			AND plla.po_line_id                  = pda.po_line_id
			AND plla.org_id                      = pda.org_id
			AND plla.line_location_id            = pda.line_location_id
			AND glcc.code_combination_id         = pda.code_combination_id