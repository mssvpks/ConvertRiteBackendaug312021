SELECT NULL                                 feeder_import_batch_id
      ,iepa.ext_payee_id                    temp_ext_payee_id
						,hou.name                             business_unit
						,aps.segment1                         vendor_code
						,assa.vendor_site_code                vendor_site_code
						,iepa.exclusive_payment_flag          exclusive_payment_flag
						,iepa.default_payment_method_code     default_payment_method_code
						,iepa.delivery_channel_code           delivery_channel_code
						,iepa.settlement_priority             settlement_priority
						,iepa.remit_advice_delivery_method    remit_advice_delivery_method
						,iepa.remit_advice_email              remit_advice_email
						,iepa.remit_advice_fax                remit_advice_fax
						,iepa.bank_instruction1_code          bank_instruction1_code
						,iepa.bank_instruction2_code          bank_instruction2_code
						,iepa.bank_instruction_details        bank_instruction_details
						,iepa.payment_reason_code             payment_reason_code
						,iepa.payment_reason_comments         payment_reason_comments
						,iepa.payment_text_message1           payment_text_message1
						,iepa.payment_text_message2           payment_text_message2
						,iepa.payment_text_message3           payment_text_message3
						,iepa.bank_charge_bearer              bank_charge_bearer
		FROM iby_external_payees_all@{0}              iepa
		    ,ap_suppliers@{0}                         aps
						,ap_supplier_sites_all@{0}                assa
      ,hr_operating_units@{0}                   hou
	WHERE 1                                  = 1
	  -- AND aps.segment1                    = :vendor_num
   AND assa.vendor_id                     = aps.vendor_id
   AND iepa.payee_party_id                = aps.party_id
   AND iepa.party_site_id                 = assa.party_site_id
   AND iepa.supplier_site_id              = assa.vendor_site_id
   AND assa.org_id                        = hou.organization_id
   AND iepa.org_id                        = hou.organization_id