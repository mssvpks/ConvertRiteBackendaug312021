SELECT NULL feeder_import_batch_id
      ,ipiua.ext_pmt_party_id              temp_ext_party_id
						,ipiua.instrument_id                 temp_instrument_id
						,ipiua.instrument_payment_use_id     temp_pmt_instr_use_id
						,NULL                                primary_flag
      ,ipiua.start_date                    start_date
						,ipiua.end_date                      end_date
	 FROM iby_external_payees_all@{0}             iepa
						,iby_pmt_instr_uses_all@{0}              ipiua
	WHERE 1 = 1
	  -- AND iepa.ext_payee_id              = :ext_payee_id
	  AND ipiua.ext_pmt_party_id(+)         = iepa.ext_payee_id