SELECT aia.invoice_id                                                                 invoice_id       
						,hou.name                                                                       business_unit     
						,aia.source                                                                     source            
						,aia.invoice_num                                                                invoice_number   
						,aia.invoice_amount                                                             invoice_amount
						,aia.invoice_date                                                               invoice_date     
						,asp.vendor_name                                                                vendor_name    
						,asp.segment1                                                                   vendor_num  
						,ass.vendor_site_code                                                           vendor_site_code    
						,aia.invoice_currency_code                                                      invoice_currency_code 
						,aia.payment_currency_code                                                      payment_currency_code 
						,aia.description                                                                description      
						,NULL                                                                           group_id
						,aia.invoice_type_lookup_code                                                   invoice_type_lookup_code  
						,(SELECT xep.name                                                               
								 	FROM xle_entity_profiles@{0} xep                                                
									WHERE xep.legal_entity_id = aia.legal_entity_id)                             legal_entity_name                             
						,aia.cust_registration_number                                                   cust_registration_number
						,aia.cust_registration_code                                                     cust_registration_code
						,NULL                                                                           first_party_registration_num   
						,NULL                                                                           third_party_registration_num					
						,(SELECT att.name                                                               
									FROM ap_terms@{0} att                                                        
								WHERE att.term_id = aia.terms_id)                                             terms_name           
						,aia.terms_date                                                                 terms_date                    
						,aia.goods_received_date                                                        goods_received_date      
						,aia.invoice_received_date                                                      invoice_received_date    
      ,aia.gl_date                                                                    gl_date
      ,aia.payment_method_lookup_code                                                 payment_method_code        
      ,aia.pay_group_lookup_code                                                      pay_group_lookup_code                
      ,aia.exclusive_payment_flag                                                     exclusive_payment_flag                
      ,aia.amount_applicable_to_discount                                              amount_applicable_to_discount
						,NULL                                                                           prepay_num            
						,NULL                                                                           prepay_line_num       
						,NULL                                                                           prepay_apply_amount
						,NULL                                                                           prepay_gl_date     
						,aia.prepay_flag                                                                invoice_includes_prepay_flag  
						,aia.exchange_rate_type                                                         exchange_rate_type
						,aia.exchange_date                                                              exchange_date              
						,aia.exchange_rate                                                              exchange_rate              
						,(SELECT concatenated_segments 
										FROM gl_code_combinations_kfv@{0} glcc
									WHERE aia.accts_pay_code_combination_id = glcc.code_combination_id)          accts_pay_code_concatenated       
						,aia.doc_category_code                                                          doc_category_code   
						,aia.doc_sequence_value                                                         voucher_num   
						,(SELECT per.first_name
										FROM per_all_people_f@{0}  per
									WHERE aia.requester_id  = per.person_id
											AND TRUNC(aia.invoice_date) BETWEEN 
															nvl(TRUNC(per.effective_start_date),TRUNC(sysdate))
															AND nvl(TRUNC(per.effective_end_date),TRUNC(sysdate)))                 requester_first_name
						,(SELECT per.last_name
										FROM per_all_people_f@{0}  per
									WHERE aia.requester_id  = per.person_id
											AND TRUNC(aia.invoice_date) BETWEEN 
															nvl(TRUNC(per.effective_start_date),TRUNC(sysdate))
															AND nvl(TRUNC(per.effective_end_date),TRUNC(sysdate)))                 requester_last_name
						,(SELECT per.employee_number
										FROM per_all_people_f@{0}  per
									WHERE aia.requester_id  = per.person_id
											AND TRUNC(aia.invoice_date) BETWEEN 
															nvl(TRUNC(per.effective_start_date),TRUNC(sysdate))
															AND nvl(TRUNC(per.effective_end_date),TRUNC(sysdate)))                 requester_employee_num
						,aia.delivery_channel_code                                                      delivery_channel_code    
						,aia.bank_charge_bearer                                                         bank_charge_bearer       
						,aia.remit_to_supplier_name                                                     remit_to_supplier_name
						,(SELECT apsr.segment1
											FROM ap_suppliers@{0}  apsr
										WHERE apsr.vendor_id   = aia.remit_to_supplier_id
												AND apsr.enabled_flag = 'Y'
												AND TRUNC(sysdate) BETWEEN
																nvl(TRUNC(apsr.start_date_active),TRUNC(sysdate)-1)
																AND nvl(TRUNC(apsr.end_date_active) ,TRUNC(sysdate)+1) )              remit_to_supplier_num
						,aia.remit_to_supplier_site                                                     remit_to_address_name    
						,NULL                                                                           payment_priority       
						,aia.settlement_priority                                                        settlement_priority      
						,aia.unique_remittance_identifier                                               unique_remittance_identifier
						,aia.uri_check_digit                                                            uri_check_digit              
						,aia.payment_reason_code                                                        payment_reason_code          
						,aia.payment_reason_comments                                                    payment_reason_comments      
						,aia.remittance_message1                                                        remittance_message1         
						,aia.remittance_message2                                                        remittance_message2         
						,aia.remittance_message3                                                        remittance_message3         
						,(SELECT aag.name
										FROM ap_awt_groups@{0} aag
									WHERE aag.group_id = aia.awt_group_id
											AND aag.inactive_date IS NULL)                                             awt_group_name          
						,NULL                                                                           ship_to_location             
						,aia.taxation_country                                                           taxation_country             
						,aia.document_sub_type                                                          document_sub_type            
						,aia.tax_invoice_internal_seq                                                   tax_invoice_internal_seq 
						,aia.supplier_tax_invoice_number                                                supplier_tax_invoice_number  
						,aia.tax_invoice_recording_date                                                 tax_invoice_recording_date
						,aia.supplier_tax_invoice_date                                                  supplier_tax_invoice_date
						,aia.supplier_tax_exchange_rate                                                 supplier_tax_exchange_rate
						,aia.port_of_entry_code                                                         port_of_entry_code                    
						,NULL                                                                           correction_year              
						,NULL                                                                           correction_period            
						,NULL                                                                           import_document_number       
						,NULL                                                                           import_document_date       
						,aia.control_amount                                                             control_amount           
						,NULL                                                                           calc_tax_during_import_flag -- Need to Verify based on customer
						,NULL                                                                           add_tax_to_inv_amt_flag  
						,aia.attribute_category                                                         attribute_category           
						,aia.attribute1                                                                 attribute1                  
						,aia.attribute2                                                                 attribute2                  
						,aia.attribute3                                                                 attribute3                  
						,aia.attribute4                                                                 attribute4                  
						,aia.attribute5                                                                 attribute5                  
						,aia.attribute6                                                                 attribute6                  
						,aia.attribute7                                                                 attribute7                  
						,aia.attribute8                                                                 attribute8                  
						,aia.attribute9                                                                 attribute9                  
						,aia.attribute10                                                                attribute10                 
						,aia.attribute11                                                                attribute11                 
						,aia.attribute12                                                                attribute12                 
						,aia.attribute13                                                                attribute13                 
						,aia.attribute14                                                                attribute14                 
						,aia.attribute15                                                                attribute15                 
						,NULL                                                                           attribute_number1          
						,NULL                                                                           attribute_number2          
						,NULL                                                                           attribute_number3          
						,NULL                                                                           attribute_number4          
						,NULL                                                                           attribute_number5          
						,NULL                                                                           attribute_date1            
						,NULL                                                                           attribute_date2            
						,NULL                                                                           attribute_date3            
						,NULL                                                                           attribute_date4            
						,NULL                                                                           attribute_date5         
						,aia.global_attribute_category                                                  global_attribute_category   
						,aia.global_attribute1                                                          global_attribute1          
						,aia.global_attribute2                                                          global_attribute2          
						,aia.global_attribute3                                                          global_attribute3          
						,aia.global_attribute4                                                          global_attribute4          
						,aia.global_attribute5                                                          global_attribute5          
						,aia.global_attribute6                                                          global_attribute6          
						,aia.global_attribute7                                                          global_attribute7          
						,aia.global_attribute8                                                          global_attribute8          
						,aia.global_attribute9                                                          global_attribute9          
						,aia.global_attribute10                                                         global_attribute10         
						,aia.global_attribute11                                                         global_attribute11         
						,aia.global_attribute12                                                         global_attribute12         
						,aia.global_attribute13                                                         global_attribute13         
						,aia.global_attribute14                                                         global_attribute14         
						,aia.global_attribute15                                                         global_attribute15         
						,aia.global_attribute16                                                         global_attribute16         
						,aia.global_attribute17                                                         global_attribute17         
						,aia.global_attribute18                                                         global_attribute18         
						,aia.global_attribute19                                                         global_attribute19         
						,aia.global_attribute20                                                         global_attribute20         
						,NULL                                                                           global_attribute_number1   
						,NULL                                                                           global_attribute_number2   
						,NULL                                                                           global_attribute_number3   
						,NULL                                                                           global_attribute_number4   
						,NULL                                                                           global_attribute_number5   
						,NULL                                                                           global_attribute_date1     
						,NULL                                                                           global_attribute_date2     
						,NULL                                                                           global_attribute_date3     
						,NULL                                                                           global_attribute_date4     
						,NULL                                                                           global_attribute_date5
						,NULL                                                                           image_document_uri
						,(SELECT ieba.bank_account_num
						    FROM iby_ext_bank_accounts@{0} ieba
									WHERE ieba.ext_bank_account_id = aia.external_bank_account_id)               external_bank_account_number
						,(SELECT ieba.iban
						    FROM iby_ext_bank_accounts@{0} ieba
									WHERE ieba.ext_bank_account_id = aia.external_bank_account_id)               ext_bank_account_iban_number
						,(SELECT per.email_address
										FROM per_all_people_f@{0}  per
									WHERE aia.requester_id  = per.person_id
											AND TRUNC(aia.invoice_date) BETWEEN 
															nvl(TRUNC(per.effective_start_date),TRUNC(sysdate))
															AND nvl(TRUNC(per.effective_end_date),TRUNC(sysdate)))                 requester_email_address
  FROM ap_invoices_all@{0}           aia  
      ,ap_suppliers@{0}              asp         
      ,ap_supplier_sites_all@{0}     ass
      ,hr_operating_units@{0}        hou
 WHERE 1                         = 1
   -- AND aia.invoice_id         =  :invoice_id
	  AND aia.vendor_id             =  asp.vendor_id
   AND aia.payment_status_flag   IN ('N','P')  -- Verify with Business    
   AND aia.cancelled_date        IS NULL   
   AND asp.enabled_flag          = 'Y'
   AND TRUNC(sysdate) BETWEEN nvl(asp.start_date_active,TRUNC(sysdate)-1)
                          AND nvl(asp.end_date_active ,TRUNC(sysdate)+1)
   AND asp.vendor_id             = ass.vendor_id       
   AND aia.vendor_site_id        = ass.vendor_site_id
   AND ass.org_id                = hou.organization_id
   -- AND aia.invoice_type_lookup_code <> 'AWT'                                                      -- Verify with Business
   AND aia.invoice_amount        <> 0
			AND aia.SOURCE                <> 'ERS'  