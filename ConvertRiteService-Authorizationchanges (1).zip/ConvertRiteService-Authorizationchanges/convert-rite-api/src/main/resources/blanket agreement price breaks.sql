SELECT plla.line_location_id                                        interface_line_location_key 
						,plla.po_line_id                                              interface_line_key 
						,plla.shipment_num                                            shipment_num 
						,(SELECT hl.location_code
								FROM hr_locations@{0} hl
								WHERE hl.location_id = plla.ship_to_location_id)            ship_to_location 
						,(SELECT hou.NAME
								FROM hr_operating_units@{0} hou
								WHERE hou.organization_id = plla.ship_to_organization_id)   ship_to_organization_code
						,plla.quantity                                                quantity
						,plla.price_override                                          price_override
						,plla.price_discount                                          price_discount
						,plla.start_date                                              start_date
						,plla.end_date                                                end_date
						,plla.attribute_category                                      attribute_category
						,plla.attribute1                                              attribute1
						,plla.attribute2                                              attribute2
						,plla.attribute3                                              attribute3
						,plla.attribute4                                              attribute4
						,plla.attribute5                                              attribute5
						,plla.attribute6                                              attribute6
						,plla.attribute7                                              attribute7
						,plla.attribute8                                              attribute8
						,plla.attribute9                                              attribute9
						,plla.attribute10                                             attribute10
						,plla.attribute11                                             attribute11
						,plla.attribute12                                             attribute12
						,plla.attribute13                                             attribute13
						,plla.attribute14                                             attribute14
						,plla.attribute15                                             attribute15
						,NULL                                                         attribute16
						,NULL                                                         attribute17
						,NULL                                                         attribute18
						,NULL                                                         attribute19
						,NULL                                                         attribute20
						,NULL                                                         attribute_date1
						,NULL                                                         attribute_date2
						,NULL                                                         attribute_date3
						,NULL                                                         attribute_date4
						,NULL                                                         attribute_date5
						,NULL                                                         attribute_date6
						,NULL                                                         attribute_date7
						,NULL                                                         attribute_date8
						,NULL                                                         attribute_date9
						,NULL                                                         attribute_date10
						,NULL                                                         attribute_number1
						,NULL                                                         attribute_number2
						,NULL                                                         attribute_number3
						,NULL                                                         attribute_number4
						,NULL                                                         attribute_number5
						,NULL                                                         attribute_number6
						,NULL                                                         attribute_number7
						,NULL                                                         attribute_number8
						,NULL                                                         attribute_number9
						,NULL                                                         attribute_number10
						,NULL                                                         attribute_timestamp1
						,NULL                                                         attribute_timestamp2
						,NULL                                                         attribute_timestamp3
						,NULL                                                         attribute_timestamp4
						,NULL                                                         attribute_timestamp5
						,NULL                                                         attribute_timestamp6
						,NULL                                                         attribute_timestamp7
						,NULL                                                         attribute_timestamp8
						,NULL                                                         attribute_timestamp9
						,NULL                                                         attribute_timestamp10
		FROM apps.po_headers_all@{0}              pha
						,apps.po_lines_all@{0}                pla
						,apps.po_line_locations_all@{0}       plla
	WHERE 1                                = 1
			-- AND PHA.PO_HEADER_ID              = :PO_HEADER_ID
			AND pha.type_lookup_code             = 'BLANKET'
			AND nvl(pha.closed_code, 'OPEN')     = 'OPEN'             -- STATUS OF PO OPEN IN HEADER
			AND nvl(pla.closed_code,'OPEN')      = 'OPEN'             -- STATUS OF PO OPEN IN LINE
			AND nvl(plla.closed_code,'OPEN')     = 'OPEN'             -- STATUS OF PO OPEN IN LINE LOCATION
			AND nvl(pha.cancel_flag,'#')         != 'Y'               -- CANCEL FLAG <> Y
			AND nvl(pla.cancel_flag,'#')         != 'Y'               -- CANCEL FLAG <> Y
			AND nvl(plla.cancel_flag,'#')        != 'Y'               -- CANCEL FLAG <> Y
			AND pha.po_header_id                 = pla.po_header_id
			AND pha.org_id                       = pla.org_id
			AND pla.po_header_id                 = plla.po_header_id
			AND pla.po_line_id                   = plla.po_line_id
			AND pla.org_id                       = plla.org_id