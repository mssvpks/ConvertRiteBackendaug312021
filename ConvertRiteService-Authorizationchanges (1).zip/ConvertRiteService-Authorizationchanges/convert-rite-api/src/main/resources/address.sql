SELECT HPS.PARTY_SITE_ID                      														"PARTY_SITE_ID"
      ,HPS.PARTY_SITE_NUMBER                  														"PARTY_SITE_NUM"
      ,HPS.PARTY_SITE_NAME                    														"PARTY_SITE_NAME"
      ,APS.VENDOR_ID                          														"VENDOR_ID"
      ,APS.SEGMENT1                           														"VENDOR_NUM"      
      ,APS.VENDOR_NAME                        														"VENDOR_NAME"
      ,HZL.COUNTRY                            														"COUNTRY"
      ,HZL.ADDRESS1                           														"ADDRESS_LINE1"
      ,HZL.ADDRESS2                           														"ADDRESS_LINE2"
      ,HZL.ADDRESS3                           														"ADDRESS_LINE3"
      ,HZL.ADDRESS4                           														"ADDRESS_LINE4"
						,HZL.ADDRESS_LINES_PHONETIC                           "ADDRESS_LINES_PHONETIC"
      ,HZL.BUILDING                           														"BUILDING"
      ,HZL.FLOOR                              														"FLOOR_NUMBER"
      ,HZL.CITY                               														"CITY"
      ,HZL.STATE                              														"STATE"
      ,HZL.PROVINCE                           														"PROVINCE"
      ,HZL.COUNTY                             														"COUNTY"
      ,HZL.POSTAL_CODE                        														"POSTAL_CODE"
      ,HZL.POSTAL_PLUS4_CODE                  														"POSTAL_PLUS4_CODE"
      ,HPS.ADDRESSEE                          														"ADDRESSEE"
      ,HPS.GLOBAL_LOCATION_NUMBER             														"GLOBAL_LOCATION_NUMBER"
      ,HPS.LANGUAGE                           														"PARTY_SITE_LANGUAGE"
      ,HPS.END_DATE_ACTIVE                    														"INACTIVE_DATE"
      ,HCP_PHONE.PHONE_COUNTRY_CODE           														"PHONE_COUNTRY_CODE"
      ,HCP_PHONE.PHONE_AREA_CODE              														"PHONE_AREA_CODE"
      ,HCP_PHONE.PHONE_NUMBER                 														"PHONE"
      ,HCP_PHONE.PHONE_EXTENSION              														"PHONE_EXTENSION"
      ,HCP_FAX.PHONE_COUNTRY_CODE             														"FAX_COUNTRY_CODE"
      ,HCP_FAX.PHONE_AREA_CODE                														"FAX_AREA_CODE"
      ,HCP_FAX.PHONE_NUMBER                   														"FAX"
      ,HCP_EMAIL.EMAIL_ADDRESS                														"EMAIL_ADDRESS"
      ,DECODE(HPSU_PUR.SITE_USE_TYPE, NULL, 'N', 'Y')       "ORDERING_PURPOSE_FLAG"    
      ,DECODE(HPSU_RFQ.SITE_USE_TYPE, NULL, 'N', 'Y')       "RFQ_OR_BIDDING_PURPOSE_FLAG"  
      ,DECODE(HPSU_PAY.SITE_USE_TYPE, NULL, 'N', 'Y')       "REMIT_TO_PURPOSE_FLAG"
      ,IEPA.DELIVERY_CHANNEL_CODE             														"DELIVERY_CHANNEL_CODE"
      ,IEPA.BANK_INSTRUCTION1_CODE            														"BANK_INSTRUCTION1_CODE"
      ,IEPA.BANK_INSTRUCTION2_CODE            														"BANK_INSTRUCTION2_CODE"
      ,IEPA.BANK_INSTRUCTION_DETAILS          														"BANK_INSTRUCTION_DETAILS"
						,IEPA.SETTLEMENT_PRIORITY               														"SETTLEMENT_PRIORITY"
      ,IEPA.PAYMENT_TEXT_MESSAGE1             														"PAYMENT_TEXT_MESSAGE1"
      ,IEPA.PAYMENT_TEXT_MESSAGE2             														"PAYMENT_TEXT_MESSAGE2"
      ,IEPA.PAYMENT_TEXT_MESSAGE3             														"PAYMENT_TEXT_MESSAGE3"
      ,IEPA.EXCLUSIVE_PAYMENT_FLAG                          "EXCLUSIVE_PAYMENT_FLAG"						
						,IEPA.BANK_CHARGE_BEARER                              "IBY_BANK_CHARGE_BEARER"
						,IEPA.PAYMENT_REASON_CODE               														"PAYMENT_REASON_CODE"
      ,IEPA.PAYMENT_REASON_COMMENTS           														"PAYMENT_REASON_COMMENTS"						
      ,IEPA.REMIT_ADVICE_DELIVERY_METHOD      														"REMIT_ADVICE_DELIVERY_METHOD"
      ,IEPA.REMIT_ADVICE_EMAIL                														"REMIT_ADVICE_EMAIL"
      ,IEPA.REMIT_ADVICE_FAX                  														"REMIT_ADVICE_FAX"	
						,ASSA.ATTRIBUTE_CATEGORY                  												"ATTRIBUTE_CATEGORY"
						,ASSA.ATTRIBUTE1                        														"ATTRIBUTE1"
						,ASSA.ATTRIBUTE2                        														"ATTRIBUTE2"
						,ASSA.ATTRIBUTE3                        														"ATTRIBUTE3"
						,ASSA.ATTRIBUTE4                        														"ATTRIBUTE4"
						,ASSA.ATTRIBUTE5                        														"ATTRIBUTE5"
						,ASSA.ATTRIBUTE6                        														"ATTRIBUTE6"
						,ASSA.ATTRIBUTE7                        														"ATTRIBUTE7"
						,ASSA.ATTRIBUTE8                        														"ATTRIBUTE8"
						,ASSA.ATTRIBUTE9                        														"ATTRIBUTE9"
						,ASSA.ATTRIBUTE10                       														"ATTRIBUTE10"
						,ASSA.ATTRIBUTE11                       														"ATTRIBUTE11"
						,ASSA.ATTRIBUTE12                       														"ATTRIBUTE12"
						,ASSA.ATTRIBUTE13                       														"ATTRIBUTE13"
						,ASSA.ATTRIBUTE14                       														"ATTRIBUTE14"
						,ASSA.ATTRIBUTE15                       														"ATTRIBUTE15"
						,ASSA.GLOBAL_ATTRIBUTE_CATEGORY         														"GLOBAL_ATTRIBUTE_CATEGORY"
						,ASSA.GLOBAL_ATTRIBUTE1                 														"GLOBAL_ATTRIBUTE1"
						,ASSA.GLOBAL_ATTRIBUTE2                 														"GLOBAL_ATTRIBUTE2"
						,ASSA.GLOBAL_ATTRIBUTE3                 														"GLOBAL_ATTRIBUTE3"
						,ASSA.GLOBAL_ATTRIBUTE4                 														"GLOBAL_ATTRIBUTE4"
						,ASSA.GLOBAL_ATTRIBUTE5                 														"GLOBAL_ATTRIBUTE5"
						,ASSA.GLOBAL_ATTRIBUTE6                 														"GLOBAL_ATTRIBUTE6"
						,ASSA.GLOBAL_ATTRIBUTE7                 														"GLOBAL_ATTRIBUTE7"
						,ASSA.GLOBAL_ATTRIBUTE8                 														"GLOBAL_ATTRIBUTE8"
						,ASSA.GLOBAL_ATTRIBUTE9                 														"GLOBAL_ATTRIBUTE9"
						,ASSA.GLOBAL_ATTRIBUTE10                														"GLOBAL_ATTRIBUTE10"
 		FROM AP_SUPPLIERS@{0} APS
       ,AP_SUPPLIER_SITES_ALL@{0} ASSA
       ,HZ_PARTY_SITES@{0} HPS
       ,HZ_LOCATIONS@{0} HZL
       ,HZ_CONTACT_POINTS@{0} HCP_PHONE
       ,HZ_CONTACT_POINTS@{0} HCP_FAX
       ,HZ_CONTACT_POINTS@{0} HCP_EMAIL
       ,HZ_PARTY_SITE_USES@{0} HPSU_PAY
       ,HZ_PARTY_SITE_USES@{0} HPSU_PUR
       ,HZ_PARTY_SITE_USES@{0} HPSU_RFQ
							,IBY_EXTERNAL_PAYEES_ALL@{0} IEPA
  WHERE 1 = 1
		  --AND APS.SEGMENT1= '5033'
		  AND APS.VENDOR_ID = ASSA.VENDOR_ID
    AND ASSA.PARTY_SITE_ID = HPS.PARTY_SITE_ID
    AND HPS.LOCATION_ID = HZL.LOCATION_ID
    AND HCP_PHONE.OWNER_TABLE_ID(+) = HPS.PARTY_SITE_ID 
    AND HCP_PHONE.OWNER_TABLE_NAME(+) = 'HZ_PARTY_SITES' 
    AND HCP_PHONE.CONTACT_POINT_TYPE(+) = 'PHONE' 
    AND HCP_PHONE.PHONE_LINE_TYPE (+) = 'GEN'
    AND HCP_FAX.OWNER_TABLE_ID(+) = HPS.PARTY_SITE_ID 
    AND HCP_FAX.OWNER_TABLE_NAME(+) = 'HZ_PARTY_SITES' 
    AND HCP_FAX.CONTACT_POINT_TYPE(+) = 'PHONE' 
    AND HCP_FAX.PHONE_LINE_TYPE (+) = 'FAX'
    AND HCP_EMAIL.OWNER_TABLE_ID(+) = HPS.PARTY_SITE_ID 
    AND HCP_EMAIL.OWNER_TABLE_NAME(+) = 'HZ_PARTY_SITES' 
    AND HCP_EMAIL.CONTACT_POINT_TYPE(+) = 'EMAIL'
    AND HPSU_PAY.PARTY_SITE_ID (+) = HPS.PARTY_SITE_ID
    AND HPSU_PUR.PARTY_SITE_ID (+) = HPS.PARTY_SITE_ID
    AND HPSU_RFQ.PARTY_SITE_ID (+) = HPS.PARTY_SITE_ID
    AND HPSU_PAY.SITE_USE_TYPE (+) = 'PAY'
    AND HPSU_PUR.SITE_USE_TYPE (+) = 'PURCHASING'
    AND HPSU_RFQ.SITE_USE_TYPE (+) = 'RFQ'
				AND HPS.PARTY_SITE_ID = IEPA.PARTY_SITE_ID
    AND ASSA.VENDOR_SITE_ID = IEPA.SUPPLIER_SITE_ID