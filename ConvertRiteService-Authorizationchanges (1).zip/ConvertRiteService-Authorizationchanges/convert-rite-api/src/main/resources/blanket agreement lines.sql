SELECT pol.po_line_id                                           interface_line_key
							,poh.po_header_id                                         interface_header_key
							,NULL                                                     action
							,pol.line_num                                             line_num
							,(SELECT plt.line_type
										FROM po_line_types@{0} plt
									WHERE plt.line_type_id = pol.line_type_id)              line_type
							,(SELECT msib.segment1
											FROM mtl_system_items_b@{0} msib
										WHERE  msib.inventory_item_id = pol.item_id
												AND ROWNUM = 1)                                      item
							,REGEXP_REPLACE(to_char(pol.item_description),CHR(9)
																																													||'|'||CHR(10)
																																													||'|'||CHR(13), '') item_description
							,pol.item_revision                                        item_revision
							,(SELECT category_concat_segs
											FROM mtl_categories_v@{0} mcb
										WHERE mcb.category_id = pol.category_id)               category
							,pol.committed_amount                                     committed_amount
							,pol.unit_meas_lookup_code                                unit_of_measure
							,pol.unit_price                                           unit_price
							,pol.allow_price_override_flag                            allow_price_override_flag
							,pol.not_to_exceed_price                                  not_to_exceed_price
							,pol.vendor_product_num                                   vendor_product_num
							,pol.negotiated_by_preparer_flag                          negotiated_by_preparer_flag
							,pol.note_to_vendor                                       note_to_vendor
							,NULL                                                     note_to_receiver
							,pol.min_release_amount                                   min_release_amount
							,pol.expiration_date                                      expiration_date
							,pol.supplier_part_auxid                                  supplier_part_auxid
							,pol.supplier_ref_number                                  supplier_ref_number
							,NULL                                                     line_attribute_category_lines
							,pol.attribute1                                           line_attribute1
							,pol.attribute2                                           line_attribute2
							,pol.attribute3                                           line_attribute3
							,pol.attribute4                                           line_attribute4
							,pol.attribute5                                           line_attribute5
							,pol.attribute6                                           line_attribute6
							,pol.attribute7                                           line_attribute7
							,pol.attribute8                                           line_attribute8
							,pol.attribute9                                           line_attribute9
							,pol.attribute10                                          line_attribute10
							,pol.attribute11                                          line_attribute11
							,pol.attribute12                                          line_attribute12
							,pol.attribute13                                          line_attribute13
							,pol.attribute14                                          line_attribute14
							,pol.attribute15                                          line_attribute15
							,NULL                                                     attribute16
							,NULL                                                     attribute17
							,NULL                                                     attribute18
							,NULL                                                     attribute19
							,NULL                                                     attribute20
							,NULL                                                     attribute_date1
							,NULL                                                     attribute_date2
							,NULL                                                     attribute_date3
							,NULL                                                     attribute_date4
							,NULL                                                     attribute_date5
							,NULL                                                     attribute_date6
							,NULL                                                     attribute_date7
							,NULL                                                     attribute_date8
							,NULL                                                     attribute_date9
							,NULL                                                     attribute_date10
							,NULL                                                     attribute_number1
							,NULL                                                     attribute_number2
							,NULL                                                     attribute_number3
							,NULL                                                     attribute_number4
							,NULL                                                     attribute_number5
							,NULL                                                     attribute_number6
							,NULL                                                     attribute_number7
							,NULL                                                     attribute_number8
							,NULL                                                     attribute_number9
							,NULL                                                     attribute_number10
							,NULL                                                     attribute_timestamp1
							,NULL                                                     attribute_timestamp2
							,NULL                                                     attribute_timestamp3
							,NULL                                                     attribute_timestamp4
							,NULL                                                     attribute_timestamp5
							,NULL                                                     attribute_timestamp6
							,NULL                                                     attribute_timestamp7
							,NULL                                                     attribute_timestamp8
							,NULL                                                     attribute_timestamp9
							,NULL                                                     attribute_timestamp10
							,NULL                                                     aging_period_days
							,NULL                                                     consignment_line_flag																
							,NULL                                                     unit_weight
							,NULL                                                     weight_uom_code
							,NULL                                                     weight_unit_of_measure
							,NULL                                                     unit_volume
							,NULL                                                     volume_uom_code
							,NULL                                                     volume_unit_of_measure
							,NULL                                                     template_name				
							,NULL                                                     item_attribute_category
							,NULL                                                     item_attribute1
							,NULL                                                     item_attribute2
							,NULL                                                     item_attribute3
							,NULL                                                     item_attribute4
							,NULL                                                     item_attribute5
							,NULL                                                     item_attribute6
							,NULL                                                     item_attribute7
							,NULL                                                     item_attribute8
							,NULL                                                     item_attribute9
							,NULL                                                     item_attribute10
							,NULL                                                     item_attribute11
							,NULL                                                     item_attribute12
							,NULL                                                     item_attribute13
							,NULL                                                     item_attribute14
							,NULL                                                     item_attribute15
							,NULL                                                     parent_item
							,NULL                                                     top_model
							,NULL                                                     supplier_parent_item
							,NULL                                                     supplier_top_model
							,pol.amount                                               amount
							,pol.price_break_lookup_code                              price_break_lookup_code
							,pol.quantity_committed                                   quantity_committed
							,NULL                                                     allow_description_update_flag
			FROM apps.po_headers_all@{0}               poh
							,apps.po_lines_all@{0}                 pol
		WHERE 1                                 = 1
		  -- AND poh.po_header_id               = :po_header_id
				AND poh.type_lookup_code              = 'BLANKET'
				AND NVL(poh.closed_code,'OPEN')       = 'OPEN'              -- STATUS OF PO OPEN IN HEADER
				AND NVL(pol.closed_code,'OPEN')       = 'OPEN'              -- STATUS OF PO OPEN IN LINE
				AND poh.po_header_id                  = pol.po_header_id
				AND poh.org_id                        = pol.org_id
				AND NVL(poh.cancel_flag,'#')          != 'Y'                --  CANCEL FLAG <> Y
				AND NVL(pol.cancel_flag,'#')          != 'Y'                --  CANCEL FLAG <> Y
				AND EXISTS 
						( SELECT 'X'
									FROM po_line_locations_all@{0}       pll
								WHERE pol.po_header_id            = pll.po_header_id
										AND pol.org_id                  = pll.org_id
										AND NVL(pll.closed_code,'OPEN') = 'OPEN'              -- STATUS OF PO OPEN IN LINE LOCATION
										AND NVL(pll.cancel_flag,'#')    != 'Y'                --  CANCEL FLAG <> Y
						)		