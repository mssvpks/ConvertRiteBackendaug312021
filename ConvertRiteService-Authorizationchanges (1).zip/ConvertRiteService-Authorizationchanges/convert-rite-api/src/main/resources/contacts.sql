SELECT DISTINCT HPC.PARTY_ID                                    "PER_PARTY_ID"
               ,APS.VENDOR_ID                                   "VENDOR_ID"
               ,APS.SEGMENT1                                    "VENDOR_NUM"
															,APS.VENDOR_NAME                                 "VENDOR_NAME"
															,HPC.PERSON_PRE_NAME_ADJUNCT                     "PREFIX"
															,HPC.PERSON_FIRST_NAME                           "FIRST_NAME"
															,HPC.PERSON_MIDDLE_NAME                          "MIDDLE_NAME"
															,HPC.PERSON_LAST_NAME                            "LAST_NAME"
															,HOC.JOB_TITLE                                   "TITLE"
															,HOC.CONTACT_KEY                                 "PRIMARY_ADMIN_CONTACT"
               ,HCP_EMAIL.EMAIL_ADDRESS                									"EMAIL_ADDRESS"
               --,HCP.EMAIL_ADDRESS                               "EMAIL ADDRESS"
  													--,ASCO.INACTIVE_DATE                              "INACTIVE_DATE"
               --,HCP.PHONE_COUNTRY_CODE                          "PHONE COUNTRY CODE"
               --,HCP.PHONE_AREA_CODE                             "AREA CODE"
               --,HCP.PHONE_NUMBER                                "PHONE"
               --,HCP.PHONE_EXTENSION                             "PHONE_EXTENSION"
               ,HCP_PHONE.PHONE_COUNTRY_CODE           									"PHONE_COUNTRY_CODE"
               ,HCP_PHONE.PHONE_AREA_CODE              									"PHONE_AREA_CODE"
               ,HCP_PHONE.PHONE_NUMBER                 									"PHONE"
               ,HCP_PHONE.PHONE_EXTENSION              									"PHONE_EXTENSION"
               ,HCP_FAX.PHONE_COUNTRY_CODE             									"FAX_COUNTRY_CODE"
               ,HCP_FAX.PHONE_AREA_CODE                									"FAX_AREA_CODE"
               ,HCP_FAX.PHONE_NUMBER                   									"FAX"
															,HPR.ATTRIBUTE_CATEGORY                          "ATTRIBUTE_CATEGORY"
															,HPR.ATTRIBUTE1                                  "ATTRIBUTE1"
															,HPR.ATTRIBUTE2                                  "ATTRIBUTE2"
															,HPR.ATTRIBUTE3                                  "ATTRIBUTE3"
															,HPR.ATTRIBUTE4                                  "ATTRIBUTE4"
															,HPR.ATTRIBUTE5                                  "ATTRIBUTE5"
															,HPR.ATTRIBUTE6                                  "ATTRIBUTE6"
															,HPR.ATTRIBUTE7                                  "ATTRIBUTE7"
															,HPR.ATTRIBUTE8                                  "ATTRIBUTE8"
															,HPR.ATTRIBUTE9                                  "ATTRIBUTE9"
															,HPR.ATTRIBUTE10                                 "ATTRIBUTE10"
															,HPR.ATTRIBUTE11                                 "ATTRIBUTE11"
															,HPR.ATTRIBUTE12                                 "ATTRIBUTE12"
															,HPR.ATTRIBUTE13                                 "ATTRIBUTE13"
															,HPR.ATTRIBUTE14                                 "ATTRIBUTE14"
															,HPR.ATTRIBUTE15                                 "ATTRIBUTE15"
															,HPR.GLOBAL_ATTRIBUTE_CATEGORY                   "GLOBAL_ATTRIBUTE_CATEGORY"
															,HPR.GLOBAL_ATTRIBUTE1                           "GLOBAL_ATTRIBUTE1"
															,HPR.GLOBAL_ATTRIBUTE2                           "GLOBAL_ATTRIBUTE2"
															,HPR.GLOBAL_ATTRIBUTE3                           "GLOBAL_ATTRIBUTE3"
															,HPR.GLOBAL_ATTRIBUTE4                           "GLOBAL_ATTRIBUTE4"
															,HPR.GLOBAL_ATTRIBUTE5                           "GLOBAL_ATTRIBUTE5"
															,HPR.GLOBAL_ATTRIBUTE6                           "GLOBAL_ATTRIBUTE6"
															,HPR.GLOBAL_ATTRIBUTE7                           "GLOBAL_ATTRIBUTE7"
															,HPR.GLOBAL_ATTRIBUTE8                           "GLOBAL_ATTRIBUTE8"
															,HPR.GLOBAL_ATTRIBUTE9                           "GLOBAL_ATTRIBUTE9"
															,HPR.GLOBAL_ATTRIBUTE10                          "GLOBAL_ATTRIBUTE10"
           FROM HZ_RELATIONSHIPS@{0} HR
															,AP_SUPPLIERS@{0} APS
															--,AP_SUPPLIER_SITES_ALL ASSA
															,HZ_ORG_CONTACTS@{0} HOC
															,HZ_PARTIES@{0} HPC
															,HZ_PARTIES@{0} HPR
               ,HZ_CONTACT_POINTS@{0} HCP_PHONE
               ,HZ_CONTACT_POINTS@{0} HCP_FAX
               ,HZ_CONTACT_POINTS@{0} HCP_EMAIL
          WHERE 1 = 1
            AND APS.SEGMENT1= '5033'
            AND HOC.PARTY_RELATIONSHIP_ID = HR.RELATIONSHIP_ID
            AND HR.SUBJECT_ID = APS.PARTY_ID
            AND HR.RELATIONSHIP_CODE = 'CONTACT'
            AND HR.OBJECT_TABLE_NAME = 'HZ_PARTIES'
            --AND APS.VENDOR_ID = ASSA.VENDOR_ID
            AND HR.OBJECT_ID = HPC.PARTY_ID
            AND HR.PARTY_ID = HPR.PARTY_ID
            AND HPR.PARTY_TYPE='PARTY_RELATIONSHIP'
            AND HPR.PARTY_ID = HCP_PHONE.OWNER_TABLE_ID(+)
            AND HCP_PHONE.OWNER_TABLE_NAME(+) = 'HZ_PARTIES' 
            AND HCP_PHONE.CONTACT_POINT_TYPE(+) = 'PHONE' 
            AND HCP_PHONE.PHONE_LINE_TYPE (+) = 'GEN'
            AND HCP_FAX.OWNER_TABLE_ID(+) = HPR.PARTY_ID 
            AND HCP_FAX.OWNER_TABLE_NAME(+) = 'HZ_PARTIES' 
            AND HCP_FAX.CONTACT_POINT_TYPE(+) = 'PHONE' 
            AND HCP_FAX.PHONE_LINE_TYPE (+) = 'FAX'
            AND HCP_EMAIL.OWNER_TABLE_ID(+) = HPR.PARTY_ID 
            AND HCP_EMAIL.OWNER_TABLE_NAME(+) = 'HZ_PARTIES' 
            AND HCP_EMAIL.CONTACT_POINT_TYPE(+) = 'EMAIL'				
				
