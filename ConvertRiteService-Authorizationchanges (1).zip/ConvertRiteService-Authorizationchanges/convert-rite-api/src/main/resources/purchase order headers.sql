SELECT poh.po_header_id                                                         interface_header_key
							,NULL                                                                     action
							,NULL                                                                     batch_id
							,poh.interface_source_code                                                interface_source_code
							,decode(poh.authorization_status,'REQUIRES REAPPROVAL','NONE','BYPASS')   approval_action           --None,ByPass,Submit
							,poh.segment1                                                             document_num
							,'PO'                                                                     document_type_code
							,NULL                                                                     style_display_name
							,(SELECT bill_hou.name
											FROM hr_operating_units@{0} bill_hou
										WHERE bill_hou.organization_id = poh.org_id)                           prc_bu_name
							,NULL                                                                     req_bu_name
							,(SELECT bill_hou.name
											FROM hr_operating_units@{0} bill_hou
										WHERE bill_hou.organization_id = poh.org_id)                           bill_to_bu_name
							,(SELECT DISTINCT hle.name
											FROM hr_legal_entities@{0} hle
										WHERE hle.organization_id = poh.org_id)                                soldto_le_name
							,(SELECT papf.last_name|| ', ' || papf.first_name
											FROM per_all_people_f@{0} papf
										WHERE papf.person_id = poh.agent_id
												AND NVL(TRUNC(papf.effective_end_date), 
												        TRUNC(sysdate)) >= TRUNC(sysdate)) agent_name
							,poh.currency_code                                                        currency_code
							,poh.rate                                                                 rate
							,poh.rate_type                                                            rate_type
							,poh.rate_date                                                            rate_date
							,poh.comments                                                             comments
							,(SELECT hla.location_code
											FROM hr_locations_all@{0} hla
										WHERE hla.location_id = poh.bill_to_location_id)                       bill_to_location
							,(SELECT hla.location_code
											FROM hr_locations_all@{0} hla
										WHERE hla.location_id = poh.ship_to_location_id)                       ship_to_location
							,pv.vendor_name                                                           vendor_name
							,NULL                                                                     vendor_num
							,pvs.vendor_site_code                                                     vendor_site_code
							,(SELECT (hp.person_first_name||' '||
							          hp.person_middle_name||' '||
																	hp.person_last_name)
											FROM hz_parties@{0} hp
										WHERE hp.party_id = pvc.per_party_id)                                  vendor_contact
							,pv.segment1                                                              vendor_doc_num
							,poh.fob_lookup_code                                                      fob
							,NULL                                                                     freight_carrier
							,poh.freight_terms_lookup_code                                            freight_terms
							,poh.pay_on_code                                                          pay_on_code
							,att.name                                                                 payment_terms
							,'Buyer'                                                                  originator_role
							,NULL                                                                     change_order_desc
							,poh.acceptance_required_flag                                             acceptance_required_flag
							,(TRUNC(poh.acceptance_due_date) - TRUNC(poh.approved_date))              acceptance_within_days          --Need to re-verify
							,poh.supplier_notif_method                                                supplier_notif_method
							,poh.fax                                                                  fax
							,poh.email_address                                                        email_address
							,poh.confirming_order_flag                                                confirming_order_flag
							,poh.note_to_vendor                                                       note_to_vendor
							,poh.note_to_receiver                                                     note_to_receiver
							,NULL                                                                     default_taxation_country
							,NULL                                                                     tax_document_subtype
							,poh.attribute_category                                                   attribute_category
							,poh.attribute1                                                           attribute1
							,poh.attribute2                                                           attribute2
							,poh.attribute3                                                           attribute3
							,poh.attribute4                                                           attribute4
							,poh.attribute5                                                           attribute5
							,poh.attribute6                                                           attribute6
							,poh.attribute7                                                           attribute7
							,poh.attribute8                                                           attribute8
							,poh.attribute9                                                           attribute9
							,poh.attribute10                                                          attribute10
							,poh.attribute11                                                          attribute11
							,poh.attribute12                                                          attribute12
							,poh.attribute13                                                          attribute13
							,poh.attribute14                                                          attribute14
							,poh.attribute15                                                          attribute15
							,NULL                                                                     attribute16
							,NULL                                                                     attribute17
							,NULL                                                                     attribute18
							,NULL                                                                     attribute19
							,NULL                                                                     attribute20
							,NULL                                                                     attribute_number1
							,NULL                                                                     attribute_number2
							,NULL                                                                     attribute_number3
							,NULL                                                                     attribute_number4
							,NULL                                                                     attribute_number5
							,NULL                                                                     attribute_number6
							,NULL                                                                     attribute_number7
							,NULL                                                                     attribute_number8
							,NULL                                                                     attribute_number9
							,NULL                                                                     attribute_number10
							,NULL                                                                     attribute_date1
							,NULL                                                                     attribute_date2
							,NULL                                                                     attribute_date3
							,NULL                                                                     attribute_date4
							,NULL                                                                     attribute_date5
							,NULL                                                                     attribute_date6
							,NULL                                                                     attribute_date7
							,NULL                                                                     attribute_date8
							,NULL                                                                     attribute_date9
							,NULL                                                                     attribute_date10
							,NULL                                                                     attribute_timestamp1
							,NULL                                                                     attribute_timestamp2
							,NULL                                                                     attribute_timestamp3
							,NULL                                                                     attribute_timestamp4
							,NULL                                                                     attribute_timestamp5
							,NULL                                                                     attribute_timestamp6
							,NULL                                                                     attribute_timestamp7
							,NULL                                                                     attribute_timestamp8
							,NULL                                                                     attribute_timestamp9
							,NULL                                                                     attribute_timestamp10
							,(SELECT papf.email_address
											FROM per_all_people_f@{0} papf
										WHERE papf.person_id = poh.agent_id
												AND current_employee_flag = 'Y'
												AND NVL(TRUNC(papf.effective_end_date), 
												        TRUNC(sysdate)) >= TRUNC(sysdate)) agent_email_address
						,NULL                                                                      mode_of_transport
						,NULL                                                                      service_level
						,NULL                                                                      first_pty_reg_num
						,NULL                                                                      third_pty_reg_num																
						,NULL                                                                      buyer_managed_transport_flag
						,NULL                                                                      master_contract_number
						,NULL                                                                      master_contract_type
						,NULL                                                                      cc_email_address
						,NULL                                                                      bcc_email_address
		FROM apps.po_headers_all@{0}                   poh
						,apps.po_vendors@{0}                       pv
						,apps.po_vendor_sites_all@{0}              pvs
						,apps.po_vendor_contacts@{0}               pvc
						,apps.ap_terms_tl@{0}                      att
	WHERE 1                                     = 1
	  -- AND poh.po_header_id                   = :po_header_id
			AND poh.vendor_id                         = pv.vendor_id
			AND poh.vendor_site_id                    = pvs.vendor_site_id
			AND poh.vendor_contact_id                 = pvc.vendor_contact_id(+)
			AND pv.vendor_id                          = pvs.vendor_id
			AND pvs.vendor_site_id                    = pvc.vendor_site_id
			AND poh.type_lookup_code                  = 'STANDARD'
			--AND poh.authorization_status            in ('APPROVED','REQUIRES REAPPROVAL')
			AND NVL(poh.closed_code, 'OPEN')          = 'OPEN'
			AND poh.terms_id                          = att.term_id (+)
			AND EXISTS 
						( SELECT 'X'
										FROM po_lines_all@{0}                  pla
									WHERE poh.po_header_id              =  pla.po_header_id
											AND poh.org_id                    =  pla.org_id
											AND NVL(pla.closed_code,'OPEN')   = 'OPEN'                  -- STATUS OF PO OPEN IN LINE LOCATION
											AND NVL(pla.cancel_flag,'#')      != 'Y'                    --  CANCEL FLAG <> Y
						)