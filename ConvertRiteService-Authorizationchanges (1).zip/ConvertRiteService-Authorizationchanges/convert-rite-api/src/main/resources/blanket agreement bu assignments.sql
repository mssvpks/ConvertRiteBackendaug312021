SELECT pgoa.org_assignment_id                             interface_bu_assignment_key
	      ,pgoa.po_header_id                                  interface_header_key
							,NULL                                               req_bu_name
							,NULL                                               ordered_locally_flag
							,(SELECT pvs.vendor_site_code
							    FROM po_vendor_sites@{0} pvs
										WHERE pvs.vendor_site_id = pgoa.vendor_site_id)  vendor_site_code
							,(SELECT hla.location_code
											FROM hr_locations_all@{0} hla
										WHERE hla.location_id = pha.ship_to_location_id) ship_to_location
							,(SELECT bill_hou.NAME
											FROM hr_operating_units@{0} bill_hou
										WHERE bill_hou.organization_id = pha.org_id)     bill_to_bu_name
							,(SELECT hla.location_code
											FROM hr_locations_all@{0} hla
										WHERE hla.location_id = pha.bill_to_location_id) bill_to_location
							,pgoa.enabled_flag                                  enabled_flag
		FROM apps.po_ga_org_assignments@{0}                          pgoa
		    ,apps.po_headers_all@{0}                                 pha
	WHERE 1                                                   = 1
	  -- AND PGOA.po_header_id                                = :po_header_id
	  AND pgoa.po_header_id                                   = pha.po_header_id