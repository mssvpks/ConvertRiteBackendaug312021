SELECT ASSA.VENDOR_SITE_ID                                                      "VENDOR_SITE_ID"
      ,APS.VENDOR_ID                                                            "VENDOR_ID"
						,APS.VENDOR_NAME                                                        "VENDOR_NAME"
						,APS.SEGMENT1                                                           "VENDOR_NUM"
						,ASSA.VENDOR_SITE_CODE                                                  "VENDOR_SITE_CODE"
						,HOU.ORGANIZATION_ID                                                    "PRC_BU_ID"
						,HOU.NAME                                                               "PROCUREMENT_BUSINESS_UNIT_NAME"
						,HOU.ORGANIZATION_ID                                                    "BU_ID"
						,HOU.NAME                                                               "BUSINESS_UNIT_NAME"
						,BILL_LOC.INVENTORY_ORGANIZATION_ID                                     "BILL_TO_BU_ID"
						,(SELECT HOU.NAME
										FROM HR_OPERATING_UNITS@{0} BILL_HOU
									WHERE BILL_HOU.ORGANIZATION_ID = HOU.ORGANIZATION_ID)                "BILL_TO_BU_NAME"
						,SHIP_LOC.LOCATION_ID                                                   "SHIP_TO_LOCATION_ID"
						,SHIP_LOC.LOCATION_CODE                                                 "SHIP_TO_LOCATION_CODE"
						,BILL_LOC.LOCATION_ID                                                   "BILL_TO_LOCATION_ID"
						,BILL_LOC.LOCATION_CODE                                                 "BILL_TO_LOCATION_CODE"
						,ASSA.DISTRIBUTION_SET_ID                                               "DISTRIBUTION_SET_ID"
						,(SELECT DISTRIBUTION_SET_NAME
										FROM AP_DISTRIBUTION_SETS_ALL@{0} ADSA
									WHERE ADSA.DISTRIBUTION_SET_ID = ASSA.DISTRIBUTION_SET_ID)           "DISTRIBUTION_SET_NAME"
						,ASSA.ACCTS_PAY_CODE_COMBINATION_ID                                     "ACCTS_PAY_CODE_COMBINATION_ID"
						,(SELECT GCCK.CONCATENATED_SEGMENTS
										FROM GL_CODE_COMBINATIONS_KFV@{0} GCCK
									WHERE GCCK.CODE_COMBINATION_ID = ASSA.ACCTS_PAY_CODE_COMBINATION_ID) "ACCTS_PAY_CONCAT_SEGMENTS"											
						,ASSA.PREPAY_CODE_COMBINATION_ID                                        "PREPAY_CODE_COMBINATION_ID"
						,(SELECT GCCK.CONCATENATED_SEGMENTS
										FROM GL_CODE_COMBINATIONS_KFV@{0} GCCK
									WHERE GCCK.CODE_COMBINATION_ID = ASSA.PREPAY_CODE_COMBINATION_ID)    "PREPAY_CONCAT_SEGMENTS"											
						,ASSA.FUTURE_DATED_PAYMENT_CCID                                         "FUTURE_DATED_PAYMENT_CCID"
						,(SELECT GCCK.CONCATENATED_SEGMENTS
										FROM GL_CODE_COMBINATIONS_KFV@{0} GCCK
									WHERE GCCK.CODE_COMBINATION_ID = ASSA.FUTURE_DATED_PAYMENT_CCID)     "FUTURE_DATED_CONCAT_SEGMENTS"
						,ASSA.ALLOW_AWT_FLAG                                                    "ALLOW_AWT_FLAG"
						,ASSA.AWT_GROUP_ID                                                      "AWT_GROUP_ID"
						,(SELECT AAG.NAME
										FROM AP_AWT_GROUPS@{0} AAG
									WHERE AAG.GROUP_ID = ASSA.AWT_GROUP_ID
											AND AAG.INACTIVE_DATE IS NULL)                                     "AWT_GROUP_NAME"
						,ASSA.INACTIVE_DATE                                                     "INACTIVE_DATE"
						,ASSA.ATTRIBUTE_CATEGORY                   																						       "ATTRIBUTE_CATEGORY"
						,ASSA.ATTRIBUTE1                                  																						"ATTRIBUTE1"
						,ASSA.ATTRIBUTE2                                  																						"ATTRIBUTE2"
						,ASSA.ATTRIBUTE3                                  																						"ATTRIBUTE3"
						,ASSA.ATTRIBUTE4                                  																						"ATTRIBUTE4"
						,ASSA.ATTRIBUTE5                                  																						"ATTRIBUTE5"
						,ASSA.ATTRIBUTE6                                  																						"ATTRIBUTE6"
						,ASSA.ATTRIBUTE7                                  																						"ATTRIBUTE7"
						,ASSA.ATTRIBUTE8                                  																						"ATTRIBUTE8"
						,ASSA.ATTRIBUTE9                                  																						"ATTRIBUTE9"
						,ASSA.ATTRIBUTE10                                 																						"ATTRIBUTE10"
						,ASSA.ATTRIBUTE11                                 																						"ATTRIBUTE11"
						,ASSA.ATTRIBUTE12                                 																						"ATTRIBUTE12"
						,ASSA.ATTRIBUTE13                                 																						"ATTRIBUTE13"
						,ASSA.ATTRIBUTE14                                 																						"ATTRIBUTE14"
						,ASSA.ATTRIBUTE15                                 																						"ATTRIBUTE15"
						,ASSA.GLOBAL_ATTRIBUTE_CATEGORY                   																						"GLOBAL_ATTRIBUTE_CATEGORY"
						,ASSA.GLOBAL_ATTRIBUTE1                           																						"GLOBAL_ATTRIBUTE1"
						,ASSA.GLOBAL_ATTRIBUTE2                           																						"GLOBAL_ATTRIBUTE2"
						,ASSA.GLOBAL_ATTRIBUTE3                           																						"GLOBAL_ATTRIBUTE3"
						,ASSA.GLOBAL_ATTRIBUTE4                           																						"GLOBAL_ATTRIBUTE4"
						,ASSA.GLOBAL_ATTRIBUTE5                           																						"GLOBAL_ATTRIBUTE5"
						,ASSA.GLOBAL_ATTRIBUTE6                           																						"GLOBAL_ATTRIBUTE6"
						,ASSA.GLOBAL_ATTRIBUTE7                           																						"GLOBAL_ATTRIBUTE7"
						,ASSA.GLOBAL_ATTRIBUTE8                           																						"GLOBAL_ATTRIBUTE8"
						,ASSA.GLOBAL_ATTRIBUTE9                           																						"GLOBAL_ATTRIBUTE9"
						,ASSA.GLOBAL_ATTRIBUTE10                          																						"GLOBAL_ATTRIBUTE10"
	FROM AP_SUPPLIERS@{0} APS
						,AP_SUPPLIER_SITES_ALL@{0} ASSA
						,HZ_PARTY_SITES@{0} HPS
						,HR_LOCATIONS_ALL@{0} SHIP_LOC
						,HR_LOCATIONS_ALL@{0} BILL_LOC
						,HR_OPERATING_UNITS@{0} HOU
WHERE 1 = 1
		--AND APS.SEGMENT1 = '5033'
		AND APS.VENDOR_ID = ASSA.VENDOR_ID
		AND ASSA.PARTY_SITE_ID = HPS.PARTY_SITE_ID
		AND ASSA.ORG_ID = HOU.ORGANIZATION_ID
		AND ASSA.SHIP_TO_LOCATION_ID = SHIP_LOC.LOCATION_ID (+)
		AND SHIP_LOC.SHIP_TO_SITE_FLAG = 'Y'    
		AND ASSA.BILL_TO_LOCATION_ID = BILL_LOC.LOCATION_ID (+)
		AND BILL_LOC.BILL_TO_SITE_FLAG = 'Y'