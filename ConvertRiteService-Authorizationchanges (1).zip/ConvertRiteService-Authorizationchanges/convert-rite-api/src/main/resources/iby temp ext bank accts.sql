SELECT NULL feeder_import_batch_id
      ,ipiua.ext_pmt_party_id             temp_ext_party_id
						,ieba.ext_bank_account_id           temp_ext_bank_acct_id
						,cbv.bank_name                      bank_name
      ,cbbv.bank_branch_name              branch_name
						,ieba.country_code                  country_code
						,ieba.bank_account_name             bank_account_name
						,ieba.bank_account_num              bank_account_num
						,ieba.currency_code                 currency_code
						,ieba.foreign_payment_use_flag      foreign_payment_use_flag
						,ieba.start_date                    start_date
						,ieba.end_date                      end_date
						,ieba.iban                          iban
						,ieba.check_digits                  check_digits         
						,ieba.bank_account_name_alt         bank_account_name_alt   
						,ieba.bank_account_type             bank_account_type        
						,ieba.account_suffix                account_suffix
						,ieba.DESCRIPTION                   DESCRIPTION
						,ieba.agency_location_code          agency_location_code
						,ieba.exchange_rate_agreement_num   exchange_rate_agreement_num
						,ieba.exchange_rate_agreement_type  exchange_rate_agreement_type
						,ieba.exchange_rate                 exchange_rate
						,ieba.secondary_account_reference   secondary_account_reference
						,ieba.attribute_category            attribute_category
						,ieba.attribute1                    attribute1
						,ieba.attribute2                    attribute2
						,ieba.attribute3                    attribute3
						,ieba.attribute4                    attribute4
						,ieba.attribute5                    attribute5
						,ieba.attribute6                    attribute6
						,ieba.attribute7                    attribute7
						,ieba.attribute8                    attribute8
						,ieba.attribute9                    attribute9
						,ieba.attribute10                   attribute10
						,ieba.attribute11                   attribute11
						,ieba.attribute12                   attribute12
						,ieba.attribute13                   attribute13
						,ieba.attribute14                   attribute14
						,ieba.attribute15                   attribute15
	 FROM iby_ext_bank_accounts@{0}              ieba
		    ,iby_external_payees_all@{0}            iepa
						,iby_pmt_instr_uses_all@{0}             ipiua
						,ce_banks_v@{0}                         cbv
						,ce_bank_branches_v@{0}                 cbbv
	WHERE 1 = 1
	  -- AND ieba.ext_bank_account_id      = :ext_bank_account_id
	  AND ipiua.ext_pmt_party_id(+)        = iepa.ext_payee_id
   AND ieba.ext_bank_account_id(+)      = ipiua.instrument_id
   AND ieba.bank_id                     = cbv.bank_party_id(+)
   AND ieba.branch_id                   = cbbv.branch_party_id(+)