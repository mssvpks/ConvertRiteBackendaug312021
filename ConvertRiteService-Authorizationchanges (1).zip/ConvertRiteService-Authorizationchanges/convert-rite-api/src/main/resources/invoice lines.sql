SELECT aia.invoice_id                                                         invoice_id
									,NULL                                                                   invoice_line_id
									,aila.line_number                                                       line_number
									,aila.line_type_lookup_code                                             line_type_lookup_code
									,aila.amount                                                            amount
									,aila.quantity_invoiced                                                 quantity_invoiced
									,aila.unit_price                                                        unit_price
									,aila.unit_meas_lookup_code                                             unit_of_meas_lookup_code
									,aila.description                                                       description
									,(SELECT poa.segment1
													FROM po_headers_all@{0} poa
												WHERE poa.po_header_id = aila.po_header_id)                          po_number
									--  CHECK AND MAP IT TO APPROPRIATE DFF OR DESCRIPTION COLUMN AS WE DON'T MIGRATE CLOSED PO
									,(SELECT pla.line_num
													FROM po_lines_all@{0} pla
												WHERE pla.po_header_id = aila.po_header_id
														AND pla.po_line_id = aila.po_line_id)                              po_line_number
									--  CHECK AND MAP IT TO APPROPRIATE DFF OR DESCRIPTION COLUMN AS WE DON'T MIGRATE CLOSED PO 
									,(SELECT pll.shipment_num
													FROM po_line_locations@{0} pll
												WHERE pll.po_header_id = aila.po_header_id
														AND pll.po_line_id = aila.po_line_id
														AND pll.line_location_id = aila.po_line_location_id)               po_shipment_num
									--  CHECK AND MAP IT TO APPROPRIATE DFF OR DESCRIPTION COLUMN AS WE DON'T MIGRATE CLOSED PO 
									,(SELECT pda.distribution_num
													FROM po_distributions_all@{0} pda
												WHERE pda.po_header_id = aila.po_header_id
														AND pda.po_line_id = aila.po_line_id
														AND pda.line_location_id = aila.po_line_location_id
														AND pda.po_distribution_id = aila.po_distribution_id)              po_distribution_num
									--  CHECK AND MAP IT TO APPROPRIATE DFF OR DESCRIPTION COLUMN AS WE DON'T MIGRATE CLOSED PO 
									,aila.item_description                                                  item_description
									,(SELECT pra.release_num
													FROM po_releases_all@{0} pra
												WHERE pra.po_header_id = aila.po_header_id
														AND pra.po_release_id = aila.po_release_id)                        release_num
									--  CHECK AND MAP IT TO APPROPRIATE DFF OR DESCRIPTION COLUMN AS WE DON'T MIGRATE CLOSED PO 
									,(SELECT category_concat_segs
													FROM mtl_categories_v@{0} mcb
												WHERE category_id = aila.purchasing_category_id)                     purchasing_category
									,NULL                                                                   receipt_number
									,NULL                                                                   receipt_line_number
									,NULL                                                                   consumption_advice_number
									,NULL                                                                   consumption_advice_line_number
									,NULL                                                                   packing_slip
									,aila.final_match_flag                                                  final_match_flag
									,gcc.concatenated_segments                                              dist_code_concatenated
									--,(SELECT gcc.concatenated_segments
									--				FROM ap_invoice_distributions_all@{0} aida
									--								,gl_code_combinations_kfv gcc
									--			WHERE 1=1
									--			  AND aila.invoice_id = aida.invoice_id
									--					AND aila.line_number = aida.invoice_line_number
									--					AND aila.org_id = aida.org_id
									--					AND aida.dist_code_combination_id = gcc.code_combination_id
         --     AND rownum=1)                                                      dist_code_concatenated
									,(SELECT adsa.distribution_set_name
													FROM ap_distribution_sets_all@{0} adsa
												WHERE adsa.distribution_set_id = aila.distribution_set_id)           distribution_set_name
									,aila.accounting_date                                                   accounting_date
									,aila.account_segment                                                   account_segment
									,aila.balancing_segment                                                 balancing_segment
									,aila.cost_center_segment                                               cost_center_segment
									,aila.tax_classification_code                                           tax_classification_code
									,NULL                                                                   ship_to_location_code
									,NULL                                                                   ship_from_location
									,NULL                                                                   final_discharge_location_code
									,aila.trx_business_category                                             trx_business_category
									,aila.product_fisc_classification                                       product_fisc_classification
									,aila.primary_intended_use                                              primary_intended_use
									,aila.user_defined_fisc_class                                           user_defined_fisc_class
									,aila.product_type                                                      product_type
									,aila.assessable_value                                                  assessable_value
									,aila.product_category                                                  product_category
									,aila.control_amount                                                    control_amount
									,aila.tax_regime_code                                                   tax_regime_code
									,aila.tax                                                               tax
									,aila.tax_status_code                                                   tax_status_code
									,aila.tax_jurisdiction_code                                             tax_jurisdiction_code
									,aila.tax_rate_code                                                     tax_rate_code
									,aila.tax_rate                                                          tax_rate
									,(SELECT aag.name
													FROM ap_awt_groups@{0} aag
												WHERE aag.group_id = aila.awt_group_id
														AND TRUNC(aia.invoice_date) <= nvl(TRUNC(aag.inactive_date),TRUNC(sysdate) + 1))        awt_group_name
									,aila.type_1099                                                         type_1099
									,aila.income_tax_region                                                 income_tax_region
									,NULL                                                                   prorate_across_flag
									,aila.line_group_number                                                 line_group_number
									,ppet.name                                                              cost_factor_name
  							,aila.stat_amount                                                       stat_amount
									,aila.assets_tracking_flag                                              assets_tracking_flag
									,aila.asset_book_type_code                                              asset_book_type_code
									,aila.asset_category_id                                                 asset_category_id
									,aila.serial_number                                                     serial_number
									,aila.manufacturer                                                      manufacturer
									,aila.model_number                                                      model_number
									,aila.warranty_number                                                   warranty_number
									,NULL                                                                   price_correction_flag
									,NULL                                                                   price_correction_inv_num
									,NULL                                                                   price_correct_inv_line_num
									,(SELECT per.first_name
													FROM per_all_people_f@{0}  per
												WHERE aila.requester_id  = per.person_id
														AND TRUNC(aia.invoice_date) BETWEEN 
																		nvl(TRUNC(per.effective_start_date),TRUNC(sysdate))
																		AND nvl(TRUNC(per.effective_end_date),TRUNC(sysdate)))         requester_first_name
									,(SELECT per.last_name
													FROM per_all_people_f@{0}  per
												WHERE aila.requester_id  = per.person_id
														AND TRUNC(aia.invoice_date) BETWEEN 
																		nvl(TRUNC(per.effective_start_date),TRUNC(sysdate))
																		AND nvl(TRUNC(per.effective_end_date),TRUNC(sysdate)))         requester_last_name
									,(SELECT per.employee_number
													FROM per_all_people_f@{0}  per
												WHERE aila.requester_id  = per.person_id
														AND TRUNC(aia.invoice_date) BETWEEN 
																		nvl(TRUNC(per.effective_start_date),TRUNC(sysdate))
																		AND nvl(TRUNC(per.effective_end_date),TRUNC(sysdate)))         requester_employee_num
									,aila.attribute_category                                                attribute_category
									,aila.attribute1                                                        attribute1
									,aila.attribute2                                                        attribute2
									,aila.attribute3                                                        attribute3
									,aila.attribute4                                                        attribute4
									,aila.attribute5                                                        attribute5
									,aila.attribute6                                                        attribute6
									,aila.attribute7                                                        attribute7
									,aila.attribute8                                                        attribute8
									,aila.attribute9                                                        attribute9
									,aila.attribute10                                                       attribute10
									,aila.attribute11                                                       attribute11
									,aila.attribute12                                                       attribute12
									,aila.attribute13                                                       attribute13
									,aila.attribute14                                                       attribute14
									,aila.attribute15                                                       attribute15
									,NULL                                                                   attribute_number1
									,NULL                                                                   attribute_number2
									,NULL                                                                   attribute_number3
									,NULL                                                                   attribute_number4
									,NULL                                                                   attribute_number5
									,NULL                                                                   attribute_date1
									,NULL                                                                   attribute_date2
									,NULL                                                                   attribute_date3
									,NULL                                                                   attribute_date4
									,NULL                                                                   attribute_date5
									,aila.global_attribute_category                                         global_attribute_category
									,aila.global_attribute1                                                 global_attribute1
									,aila.global_attribute2                                                 global_attribute2
									,aila.global_attribute3                                                 global_attribute3
									,aila.global_attribute4                                                 global_attribute4
									,aila.global_attribute5                                                 global_attribute5
									,aila.global_attribute6                                                 global_attribute6
									,aila.global_attribute7                                                 global_attribute7
									,aila.global_attribute8                                                 global_attribute8
									,aila.global_attribute9                                                 global_attribute9
									,aila.global_attribute10                                                global_attribute10
									,aila.global_attribute11                                                global_attribute11
									,aila.global_attribute12                                                global_attribute12
									,aila.global_attribute13                                                global_attribute13
									,aila.global_attribute14                                                global_attribute14
									,aila.global_attribute15                                                global_attribute15
									,aila.global_attribute16                                                global_attribute16
									,aila.global_attribute17                                                global_attribute17
									,aila.global_attribute18                                                global_attribute18
									,aila.global_attribute19                                                global_attribute19
									,aila.global_attribute20                                                global_attribute20
									,NULL                                                                   global_attribute_number1
									,NULL                                                                   global_attribute_number2
									,NULL                                                                   global_attribute_number3
									,NULL                                                                   global_attribute_number4
									,NULL                                                                   global_attribute_number5
									,NULL                                                                   global_attribute_date1
									,NULL                                                                   global_attribute_date2
									,NULL                                                                   global_attribute_date3
									,NULL                                                                   global_attribute_date4
									,NULL                                                                   global_attribute_date5
									,NULL                                                                   pjc_project_id
									,NULL                                                                   pjc_task_id
									,NULL                                                                   pjc_expenditure_type_id
									,aila.expenditure_item_date                                             pjc_expenditure_item_date
									,NULL                                                                   pjc_organization_id
									,(SELECT ppa.segment1
													FROM pa_projects_all@{0} ppa
												WHERE ppa.project_id = aila.project_id)                              pjc_project_number
									--  CHECK AND MAP IT TO APPROPRIATE DFF OR DESCRIPTION COLUMN AS WE DON'T MIGRATE CLOSED PROJECTS
									,(SELECT pt.task_number
													FROM pa_tasks@{0} pt
												WHERE pt.project_id = aila.project_id
														AND pt.task_id = aila.task_id)                                     pjc_task_number
									--  CHECK AND MAP IT TO APPROPRIATE DFF OR DESCRIPTION COLUMN AS WE DON'T MIGRATE CLOSED PROJECTS    
									,aila.expenditure_type                                                  pjc_expenditure_type_name
									--  CHECK AND MAP IT TO APPROPRIATE DFF OR DESCRIPTION COLUMN AS THIS COLUMN SHOULD NOT BE MIGRATE CLOSED PROJECTS
									,(SELECT haou.name
												FROM   hr_all_organization_units@{0} haou
												WHERE  haou.organization_id = aila.expenditure_organization_id)      pjc_organization_name
									,NULL                                                                   pjc_reserved_attribute1
									,NULL                                                                   pjc_reserved_attribute2
									,NULL                                                                   pjc_reserved_attribute3
									,NULL                                                                   pjc_reserved_attribute4
									,NULL                                                                   pjc_reserved_attribute5
									,NULL                                                                   pjc_reserved_attribute6
									,NULL                                                                   pjc_reserved_attribute7
									,NULL                                                                   pjc_reserved_attribute8
									,NULL                                                                   pjc_reserved_attribute9
									,NULL                                                                   pjc_reserved_attribute10
									,NULL                                                                   pjc_user_defined_attribute1
									,NULL                                                                   pjc_user_defined_attribute2
									,NULL                                                                   pjc_user_defined_attribute3
									,NULL                                                                   pjc_user_defined_attribute4
									,NULL                                                                   pjc_user_defined_attribute5
									,NULL                                                                   pjc_user_defined_attribute6
									,NULL                                                                   pjc_user_defined_attribute7
									,NULL                                                                   pjc_user_defined_attribute8
									,NULL                                                                   pjc_user_defined_attribute9
									,NULL                                                                   pjc_user_defined_attribute10
									,NULL                                                                   fiscal_charge_type
									,NULL                                                                   def_acctg_start_date
									,NULL                                                                   def_acctg_end_date
									,NULL                                                                   def_accrual_code_concatenated
									,(SELECT ppa.name
													FROM pa_projects_all@{0} ppa
												WHERE ppa.project_id = aila.project_id)                              pjc_project_name
									--  CHECK AND MAP IT TO APPROPRIATE DFF OR DESCRIPTION COLUMN AS WE DON'T MIGRATE CLOSED PROJECTS
									,(SELECT pt.task_name
													FROM pa_tasks@{0} pt
												WHERE pt.project_id = aila.project_id
														AND pt.task_id = aila.task_id)                                     pjc_task_name
									,NULL                                                                   pjc_work_type
									,NULL                                                                   pjc_contract_name
									,NULL                                                                   pjc_contract_number
									,NULL                                                                   pjc_funding_source_name
									,NULL                                                                   pjc_funding_source_number
									,(SELECT per.email_address
													FROM per_all_people_f@{0}  per
												WHERE aila.requester_id  = per.person_id
														AND TRUNC(aia.invoice_date) BETWEEN 
																		nvl(TRUNC(per.effective_start_date),TRUNC(sysdate))
																		AND nvl(TRUNC(per.effective_end_date),TRUNC(sysdate)))         requester_email_address
                  ,aila.requester_id
					FROM ap_invoices_all@{0}               aia
									,ap_suppliers@{0}                  asp     --  PICK INVOICE OF ACTIVE SUPPLIERS 
									,ap_invoice_lines_all@{0}          aila
									,ap_invoice_distributions_all@{0}  aida
									,gl_code_combinations_kfv@{0}      gcc
									,pon_price_element_types_vl@{0}    ppet
				WHERE 1                             = 1
      -- AND aia.invoice_id             = :invoice_id
				  AND aia.invoice_id                = aila.invoice_id
						AND aia.vendor_id                 = asp.vendor_id
						AND asp.enabled_flag              = 'Y'
						AND TRUNC(sysdate) BETWEEN nvl(TRUNC(asp.start_date_active),TRUNC(sysdate) - 1) 
						                       AND nvl(TRUNC(asp.end_date_active),TRUNC(sysdate) + 1)
						AND aia.org_id                    = aila.org_id
						AND aia.cancelled_date            IS NULL
						-- AND aia.payment_status_flag in ( 'N','P' )
						-- AND aia.invoice_type_lookup_code <> 'AWT'
						-- AND aila.line_type_lookup_code <> 'AWT' -- awt lines should not be migrated as they same would have been converted as invoice already
						AND aia.invoice_amount            <> 0
						-- AND aila.line_type_lookup_code <> 'PREPAY'
						-- AND nvl(aila.discarded_flag,'N') = 'N'
						AND aila.cost_factor_id           = ppet.price_element_type_id(+)
						-- AND decode(ap_invoices_pkg.get_approval_status(aia.invoice_id,aia.invoice_amount,aia.payment_status_flag,
						-- aia.invoice_type_lookup_code),'NEVER APPROVED',
						--    'NEVER VALIDATED',
						--    'NEEDS --REAPPROVAL',
						--    'NEEDS REVALIDATION',
						--    'CANCELLED','CANCELLED',
						--    'VALIDATED') --= 'validated'
						--  this would pick only invoices which are validated
						AND aia.invoice_id                = aida.invoice_id
						AND aila.line_number              = aida.invoice_line_number
						AND aila.org_id                   = aida.org_id
						AND aida.dist_code_combination_id = gcc.code_combination_id
 ORDER BY aia.invoice_id
         ,aila.line_number