SELECT plla.line_location_id                                        interface_line_location_key 
						,plla.po_line_id                                              interface_line_key 
						,plla.shipment_num                                            shipment_num 
						,(SELECT hl.location_code
								  FROM hr_locations@{0} hl
								 WHERE hl.location_id = plla.ship_to_location_id)           ship_to_location 
						,(SELECT hou.name
								  FROM hr_operating_units@{0} hou
								 WHERE hou.organization_id = plla.ship_to_organization_id)  ship_to_organization_code
						,plla.amount                                                  amount
						,plla.quantity                                                quantity
						,plla.need_by_date                                            need_by_date
						,plla.promised_date                                           promised_date
						,NULL                                                         secondary_quantity
						,NULL                                                         secondary_unit_of_measure
						,NULL                                                         destination_type_code                         -- NEED TO VERIFY
						,plla.accrue_on_receipt_flag                                  accrue_on_receipt_flag
						,plla.allow_substitute_receipts_flag                          allow_substitute_receipts_flag
						,NULL                                                         assessable_value
						,plla.days_early_receipt_allowed                              days_early_receipt_allowed
						,plla.days_late_receipt_allowed                               days_late_receipt_allowed
						,plla.enforce_ship_to_location_code                           enforce_ship_to_location_code
						,plla.inspection_required_flag                                inspection_required_flag
						,plla.receipt_required_flag                                   receipt_required_flag
						,plla.invoice_close_tolerance                                 invoice_close_tolerance
						,plla.receive_close_tolerance                                 receive_close_tolerance
						,plla.qty_rcv_tolerance                                       qty_rcv_tolerance
						,plla.qty_rcv_exception_code                                  qty_rcv_exception_code
						,plla.receipt_days_exception_code                             receipt_days_exception_code
						,NULL                                                         receiving_routing
						,plla.note_to_receiver                                        note_to_receiver
						,NULL                                                         input_tax_classification_code
						,NULL                                                         line_intended_use
						,NULL                                                         product_category
						,NULL                                                         product_fisc_classification
						,NULL                                                         product_type
						,NULL                                                         trx_business_category
						,NULL                                                         user_defined_fisc_class
						,plla.attribute_category                                      attribute_category
						,plla.attribute1                                              attribute1
						,plla.attribute2                                              attribute2
						,plla.attribute3                                              attribute3
						,plla.attribute4                                              attribute4
						,plla.attribute5                                              attribute5
						,plla.attribute6                                              attribute6
						,plla.attribute7                                              attribute7
						,plla.attribute8                                              attribute8
						,plla.attribute9                                              attribute9
						,plla.attribute10                                             attribute10
						,plla.attribute11                                             attribute11
						,plla.attribute12                                             attribute12
						,plla.attribute13                                             attribute13
						,plla.attribute14                                             attribute14
						,plla.attribute15                                             attribute15
						,NULL                                                         attribute16
						,NULL                                                         attribute17
						,NULL                                                         attribute18
						,NULL                                                         attribute19
						,NULL                                                         attribute20
						,NULL                                                         attribute_date1
						,NULL                                                         attribute_date2
						,NULL                                                         attribute_date3
						,NULL                                                         attribute_date4
						,NULL                                                         attribute_date5
						,NULL                                                         attribute_date6
						,NULL                                                         attribute_date7
						,NULL                                                         attribute_date8
						,NULL                                                         attribute_date9
						,NULL                                                         attribute_date10
						,NULL                                                         attribute_number1
						,NULL                                                         attribute_number2
						,NULL                                                         attribute_number3
						,NULL                                                         attribute_number4
						,NULL                                                         attribute_number5
						,NULL                                                         attribute_number6
						,NULL                                                         attribute_number7
						,NULL                                                         attribute_number8
						,NULL                                                         attribute_number9
						,NULL                                                         attribute_number10
						,NULL                                                         attribute_timestamp1
						,NULL                                                         attribute_timestamp2
						,NULL                                                         attribute_timestamp3
						,NULL                                                         attribute_timestamp4
						,NULL                                                         attribute_timestamp5
						,NULL                                                         attribute_timestamp6
						,NULL                                                         attribute_timestamp7
						,NULL                                                         attribute_timestamp8
						,NULL                                                         attribute_timestamp9
						,NULL                                                         attribute_timestamp10
						,NULL                                                         freight_carrier
						,NULL                                                         mode_of_transport
						,NULL                                                         service_level
						,NULL                                                         final_discharge_location_code
						,NULL                                                         requested_ship_date
						,NULL                                                         promised_ship_date
						,NULL                                                         requested_delivery_date 
						,NULL                                                         promised_delivery_date      -- NEED TO VERIFY
						,NULL                                                         retainage_rate              -- NEED TO VERIFY
		FROM apps.po_headers_all@{0}             pha
						,apps.po_lines_all@{0}               pla
						,apps.po_line_locations_all@{0}      plla
	WHERE 1                               = 1
			-- AND pha.po_header_id             = :po_header_id
			AND pha.type_lookup_code            = 'STANDARD'
			AND NVL(pha.closed_code, 'OPEN')    = 'OPEN'            -- STATUS OF PO OPEN IN HEADER
			AND NVL(pla.closed_code,'OPEN')     = 'OPEN'            -- STATUS OF PO OPEN IN LINE
			AND NVL(plla.closed_code,'OPEN')    = 'OPEN'            -- STATUS OF PO OPEN IN LINE LOCATION
			AND NVL(pha.cancel_flag,'#')        != 'Y'              -- CANCEL FLAG <> Y
			AND NVL(pla.cancel_flag,'#')        != 'Y'              -- CANCEL FLAG <> Y
			AND NVL(plla.cancel_flag,'#')       != 'Y'              -- CANCEL FLAG <> Y
			AND pha.po_header_id                = pla.po_header_id
			AND pha.org_id                      = pla.org_id
			AND pla.po_header_id                = plla.po_header_id
			AND pla.po_line_id                  = plla.po_line_id
			AND pla.org_id                      = plla.org_id
			AND EXISTS 
							( SELECT 'X'
									FROM po_distributions_all@{0}     pda
								WHERE plla.po_header_id        = pda.po_header_id
										AND plla.po_line_id          = pda.po_line_id
										AND plla.line_location_id    = pda.line_location_id
										AND plla.org_id              = pda.org_id
							)