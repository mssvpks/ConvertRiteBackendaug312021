SELECT pavt.attribute_values_tlp_id     interface_attribute_tlp_key
      ,pla.po_line_id                   interface_line_key
						,pavt.description                 description
						,pavt.manufacturer                manufacturer
						,pavt.alias                       alias
						,pavt.comments                    comments
						,pavt.long_description            long_description
						,pavt.language                    language
	 FROM apps.po_attribute_values_tlp@{0}     pavt
		    ,apps.po_headers_all@{0}              pha
						,apps.po_lines_all@{0}                pla
	WHERE 1                                = 1
	  AND pha.po_header_id                 = pla.po_header_id
			AND pla.po_line_id                   = pavt.po_line_id