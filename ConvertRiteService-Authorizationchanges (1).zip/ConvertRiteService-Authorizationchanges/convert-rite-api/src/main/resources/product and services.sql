SELECT PSPS.CLASSIFICATION_ID                         "CLASSIFICATION_ID"
      ,APS.VENDOR_ID                                  "VENDOR_ID"
      ,APS.SEGMENT1                                   "VENDOR_NUM"
						,APS.VENDOR_NAME                                "VENDOR_NAME"
						,FFVV1.FLEX_VALUE||'.'||FFVV2.FLEX_VALUE        "CATEGORY_CODE"
						,FFVV1.DESCRIPTION||'.'||FFVV2.DESCRIPTION      "CATEGORY_NAME"
      ,APS.ATTRIBUTE_CATEGORY              				       "ATTRIBUTE_CATEGORY"
						,APS.ATTRIBUTE1                             				"ATTRIBUTE1"
						,APS.ATTRIBUTE2                             				"ATTRIBUTE2"
						,APS.ATTRIBUTE3                             				"ATTRIBUTE3"
						,APS.ATTRIBUTE4                             				"ATTRIBUTE4"
						,APS.ATTRIBUTE5                             				"ATTRIBUTE5"
						,APS.ATTRIBUTE6                             				"ATTRIBUTE6"
						,APS.ATTRIBUTE7                             				"ATTRIBUTE7"
						,APS.ATTRIBUTE8                             				"ATTRIBUTE8"
						,APS.ATTRIBUTE9                             				"ATTRIBUTE9"
						,APS.ATTRIBUTE10                            				"ATTRIBUTE10"
						,APS.ATTRIBUTE11                            				"ATTRIBUTE11"
						,APS.ATTRIBUTE12                            				"ATTRIBUTE12"
						,APS.ATTRIBUTE13                            				"ATTRIBUTE13"
						,APS.ATTRIBUTE14                            				"ATTRIBUTE14"
						,APS.ATTRIBUTE15                            				"ATTRIBUTE15"
						,APS.GLOBAL_ATTRIBUTE_CATEGORY              				"GLOBAL_ATTRIBUTE_CATEGORY"
						,APS.GLOBAL_ATTRIBUTE1                 	     			"GLOBAL_ATTRIBUTE1"
						,APS.GLOBAL_ATTRIBUTE2                      				"GLOBAL_ATTRIBUTE2"
						,APS.GLOBAL_ATTRIBUTE3                      				"GLOBAL_ATTRIBUTE3"
						,APS.GLOBAL_ATTRIBUTE4                      				"GLOBAL_ATTRIBUTE4"
						,APS.GLOBAL_ATTRIBUTE5                      				"GLOBAL_ATTRIBUTE5"
						,APS.GLOBAL_ATTRIBUTE6                      				"GLOBAL_ATTRIBUTE6"
						,APS.GLOBAL_ATTRIBUTE7                      				"GLOBAL_ATTRIBUTE7"
						,APS.GLOBAL_ATTRIBUTE8                      				"GLOBAL_ATTRIBUTE8"
						,APS.GLOBAL_ATTRIBUTE9                      				"GLOBAL_ATTRIBUTE9"
						,APS.GLOBAL_ATTRIBUTE10                				     "GLOBAL_ATTRIBUTE10"
		FROM AP_SUPPLIERS@{0} APS
						,POS_SUP_PRODUCTS_SERVICES@{0} PSPS
						,FND_FLEX_VALUES_VL@{0} FFVV1
						,FND_FLEX_VALUES_VL@{0} FFVV2
	WHERE 1 = 1
   --AND APS.SEGMENT1=5033
   AND APS.VENDOR_ID = PSPS.VENDOR_ID
			AND FFVV1.FLEX_VALUE_SET_ID = 1014101
			AND FFVV2.FLEX_VALUE_SET_ID = 1014102
			AND FFVV1.FLEX_VALUE = PSPS.SEGMENT1
			AND FFVV2.FLEX_VALUE = PSPS.SEGMENT2
   AND FFVV2.PARENT_FLEX_VALUE_LOW = PSPS.SEGMENT1	
			