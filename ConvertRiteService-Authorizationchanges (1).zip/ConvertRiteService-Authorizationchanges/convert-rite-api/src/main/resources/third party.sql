SELECT APS_INV.VENDOR_ID                                  "VENDOR_ID"
      ,APS_INV.SEGMENT1                                   "VENDOR_NUM"
      ,APS_INV.VENDOR_NAME                                "VENDOR_NAME"
      ,ASSA_INV.ORG_ID                                    "PRC_BU_ID"
						,(SELECT NAME
										FROM HR_OPERATING_UNITS@{0} HOU
									WHERE HOU.ORGANIZATION_ID = ASSA_INV.ORG_ID)     "PROCUREMENT_BUSINESS_UNIT_NAME"
      ,ASSA_INV.VENDOR_SITE_ID                            "VENDOR_SITE_ID"
						,ASSA_INV.VENDOR_SITE_CODE                          "VENDOR_SITE_CODE"
      ,APS_RMT.VENDOR_ID                                  "REMIT_TO_SUPPLIER_ID"
						,APS_RMT.VENDOR_NAME                                "REMIT_TO_SUPPLIER"
      ,ASSA_RMT.VENDOR_SITE_ID                            "REMIT_ADDRESS_ID"
						,ASSA_RMT.VENDOR_SITE_CODE                          "REMIT_TO_ADDRESS"
						,IEPR.FROM_DATE                                     "FROM_DATE"
						,IEPR.TO_DATE                                       "TO_DATE"
						,IEPR.ADDITIONAL_INFORMATION                        "DESCRIPTION"
						,IEPR.ATTRIBUTE_CATEGORY                            "ATTRIBUTE_CATEGORY"
						,IEPR.ATTRIBUTE1                             							"ATTRIBUTE1"
						,IEPR.ATTRIBUTE2                             							"ATTRIBUTE2"
						,IEPR.ATTRIBUTE3                             							"ATTRIBUTE3"
						,IEPR.ATTRIBUTE4                             							"ATTRIBUTE4"
						,IEPR.ATTRIBUTE5                             							"ATTRIBUTE5"
						,IEPR.ATTRIBUTE6                             							"ATTRIBUTE6"
						,IEPR.ATTRIBUTE7                             							"ATTRIBUTE7"
						,IEPR.ATTRIBUTE8                             							"ATTRIBUTE8"
						,IEPR.ATTRIBUTE9                             							"ATTRIBUTE9"
						,IEPR.ATTRIBUTE10                            							"ATTRIBUTE10"
						,IEPR.ATTRIBUTE11                            							"ATTRIBUTE11"
						,IEPR.ATTRIBUTE12                            							"ATTRIBUTE12"
						,IEPR.ATTRIBUTE13                            							"ATTRIBUTE13"
						,IEPR.ATTRIBUTE14                            							"ATTRIBUTE14"
						,IEPR.ATTRIBUTE15                            							"ATTRIBUTE15"
		FROM AP_SUPPLIERS@{0} APS_INV
		    ,AP_SUPPLIERS@{0} APS_RMT
						,AP_SUPPLIER_SITES_ALL@{0} ASSA_INV
						,AP_SUPPLIER_SITES_ALL@{0} ASSA_RMT
						,IBY_EXT_PAYEE_RELATIONSHIPS@{0} IEPR
	WHERE 1 = 1
   --AND APS_INV.SEGMENT1 = '8045'
   AND APS_INV.VENDOR_ID = ASSA_INV.VENDOR_ID
	  AND IEPR.PARTY_ID = APS_INV.PARTY_ID
			AND IEPR.REMIT_PARTY_ID = APS_RMT.PARTY_ID
			AND IEPR.SUPPLIER_SITE_ID = ASSA_INV.VENDOR_SITE_ID
			AND IEPR.REMIT_SUPPLIER_SITE_ID = ASSA_RMT.VENDOR_SITE_ID