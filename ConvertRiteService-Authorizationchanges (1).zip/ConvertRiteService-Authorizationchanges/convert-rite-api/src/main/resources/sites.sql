SELECT IEPA.REMIT_ADVICE_FAX         																																"REMITTANCE_FAX"											
      ,ASSA.VENDOR_SITE_ID                         																		"VENDOR_SITE_ID"										
      ,HPS.PARTY_SITE_ID                           																		"PARTY_SITE_ID"										
      ,HPS.PARTY_SITE_NAME                         																		"PARTY_SITE_NAME"										
      ,APS.SEGMENT1                                																		"VENDOR_NUM"										
						,APS.VENDOR_NAME                             																		"VENDOR_NAME"										
						,ASSA.VENDOR_SITE_CODE                       																		"VENDOR_SITE_CODE"										
      ,HOU.ORGANIZATION_ID                         																		"PRC_BU_ID"										
						,HOU.NAME                                    																		"PROCUREMENT_BUSINESS_UNIT_NAME"										
						,ASSA.PURCHASING_SITE_FLAG                   																		"PURCHASING_SITE_FLAG"										
      ,ASSA.RFQ_ONLY_SITE_FLAG                     																		"RFQ_ONLY_SITE_FLAG"										
      ,ASSA.PAY_SITE_FLAG                          																		"PAY_SITE_FLAG"										
						,ASSA.ATTENTION_AR_FLAG                      																		"ATTENTION_AR_FLAG"										
      --,ASSA.ADDRESS_LINE1                        																		"ADDRESS_LINE1"										
      --,ASSA.ADDRESS_LINES_ALT																																						"ADDRESS_LINES ALT"										
      --,ASSA.ADDRESS_LINE2											 																														"ADDRESS_LINE2"										
      --,ASSA.ADDRESS_LINE3																							 																		"ADDRESS_LINE3"										
      --,ASSA.ADDRESS_LINE4																							 																		"ADDRESS_LINE4"										
      --,ASSA.CITY																							          																		"CITY"										
      --,ASSA.STATE																							         																		"STATE"										
      --,ASSA.ZIP																							           																		"ZIP"										
      --,ASSA.PROVINCE																							      																		"PROVINCE"										
      --,ASSA.COUNTRY																							       																		"COUNTRY"										
      --,ASSA.COUNTY																							        																		"COUNTY"										
						,ASSA.AREA_CODE																							       																		"AREA_CODE"										
						,ASSA.PHONE																							           																		"PHONE"										
						,ASSA.CUSTOMER_NUM																							    																		"CUSTOMER_NUM"										
						,ASSA.FREIGHT_TERMS_LOOKUP_CODE              																		"FREIGHT_TERMS_LOOKUP_CODE"										
						,ASSA.FOB_LOOKUP_CODE                        																		"FOB_LOOKUP_CODE"										
						,ASSA.FAX                                    																		"FAX"										
						,ASSA.FAX_AREA_CODE                          																		"FAX_AREA_CODE"										
						,ASSA.TERMS_DATE_BASIS                       																		"TERMS_DATE_BASIS"										
						,ASSA.PAY_GROUP_LOOKUP_CODE                  																		"PAY_GROUP_LOOKUP_CODE"										
						,ASSA.PAYMENT_PRIORITY                       																		"PAYMENT_PRIORITY"										
      ,ASSA.TERMS_ID                               																		"TERMS_ID"										
      ,(SELECT ATT.NAME 																												                 
          FROM AP_TERMS_TL@{0} ATT																												           
         WHERE ATT.TERM_ID = ASSA.TERMS_ID)        																		"TERMS_NAME"										
						,ASSA.INVOICE_AMOUNT_LIMIT                   																		"INVOICE_AMOUNT_LIMIT"										
						,ASSA.PAY_DATE_BASIS_LOOKUP_CODE             																		"PAY_DATE_BASIS_LOOKUP_CODE"										
						,ASSA.ALWAYS_TAKE_DISC_FLAG                  																		"ALWAYS_TAKE_DISC_FLAG"										
						,ASSA.INVOICE_CURRENCY_CODE                  																		"INVOICE_CURRENCY_CODE"										
						,ASSA.PAYMENT_CURRENCY_CODE                  																		"PAYMENT_CURRENCY_CODE"										
						,ASSA.HOLD_ALL_PAYMENTS_FLAG                 																		"HOLD_ALL_PAYMENTS_FLAG"										
						,ASSA.HOLD_FUTURE_PAYMENTS_FLAG              																		"HOLD_FUTURE_PAYMENTS_FLAG"										
						,ASSA.HOLD_REASON                            																		"HOLD_REASON"										
						,ASSA.HOLD_UNMATCHED_INVOICES_FLAG           																		"HOLD_UNMATCHED_INVOICES_FLAG"										
						,ASSA.TAX_REPORTING_SITE_FLAG                																		"TAX_REPORTING_SITE_FLAG"										
						,ASSA.EXCLUDE_FREIGHT_FROM_DISCOUNT          																		"EXCLUDE_FREIGHT_FROM_DISCOUNT"										
						,ASSA.PAY_ON_CODE                            																		"PAY_ON_CODE"										
      ,ASSA.DEFAULT_PAY_SITE_ID                    																		"DEFAULT_PAY_SITE_ID"										
						,(SELECT ASSA1.VENDOR_SITE_CODE
						   FROM AP_SUPPLIER_SITES_ALL@{0} ASSA1
								WHERE ASSA1.DEFAULT_PAY_SITE_ID = ASSA.VENDOR_SITE_ID)       "DEFAULT_PAY_SITE_CODE"
						,ASSA.PAY_ON_RECEIPT_SUMMARY_CODE            																		"PAY_ON_RECEIPT_SUMMARY_CODE"
						,ASSA.PCARD_SITE_FLAG                        																		"PCARD_SITE_FLAG"
						,ASSA.MATCH_OPTION                           																		"MATCH_OPTION"
						,ASSA.COUNTRY_OF_ORIGIN_CODE                 																		"COUNTRY_OF_ORIGIN_CODE"
						,ASSA.CREATE_DEBIT_MEMO_FLAG                 																		"CREATE_DEBIT_MEMO_FLAG"
						,ASSA.SUPPLIER_NOTIF_METHOD                  																		"SUPPLIER_NOTIF_METHOD"
						,ASSA.EMAIL_ADDRESS                          																		"EMAIL_ADDRESS"
						,ASSA.PRIMARY_PAY_SITE_FLAG                  																		"PRIMARY_PAY_SITE_FLAG"
						,ASSA.SHIPPING_CONTROL                       																		"SHIPPING_CONTROL"
      ,ASSA.TOLERANCE_ID                           																		"TOLERANCE_ID"
						,(SELECT APT.TOLERANCE_NAME
						   FROM AP_TOLERANCES@{0} APT
								WHERE APT.TOLERANCE_ID = ASSA.TOLERANCE_ID)																		"TOLERANCE_NAME"			
						,ASSA.GAPLESS_INV_NUM_FLAG                   																		"GAPLESS_INV_NUM_FLAG"			
						,ASSA.SELLING_COMPANY_IDENTIFIER             																		"SELLING_COMPANY_IDENTIFIER"			
						,ASSA.EXCLUSIVE_PAYMENT_FLAG                 																		"EXCLUSIVE_PAYMENT_FLAG"			
						,ASSA.BANK_CHARGE_BEARER                     																		"IBY_BANK_CHARGE_BEARER"    			  
      ,IEPA.BANK_INSTRUCTION1_CODE            																							"BANK_INSTRUCTION1_CODE"
      ,IEPA.BANK_INSTRUCTION2_CODE            																							"BANK_INSTRUCTION2_CODE"
      ,IEPA.BANK_INSTRUCTION_DETAILS          																							"BANK_INSTRUCTION_DETAILS"
						,IEPA.PAYMENT_REASON_CODE               																							"PAYMENT_REASON_CODE"
      ,IEPA.PAYMENT_REASON_COMMENTS           																							"PAYMENT_REASON_COMMENTS"		
      ,IEPA.DELIVERY_CHANNEL_CODE             																							"DELIVERY_CHANNEL_CODE"
      ,IEPA.PAYMENT_FORMAT_CODE                             									"PAYMENT_FORMAT_CODE"      
						,IEPA.SETTLEMENT_PRIORITY               																							"SETTLEMENT_PRIORITY"
      ,IEPA.PAYMENT_TEXT_MESSAGE1             																							"PAYMENT_TEXT_MESSAGE1"
      ,IEPA.PAYMENT_TEXT_MESSAGE2             																							"PAYMENT_TEXT_MESSAGE2"
      ,IEPA.PAYMENT_TEXT_MESSAGE3             																							"PAYMENT_TEXT_MESSAGE3"
						,ASSA.PAYMENT_METHOD_LOOKUP_CODE                      									"PAYMENT_METHOD_LOOKUP_CODE"
      ,APS.ALLOW_SUBSTITUTE_RECEIPTS_FLAG                   									"ALLOW_SUBSTITUTE_RECEIPTS_FLAG"
      ,APS.ALLOW_UNORDERED_RECEIPTS_FLAG                    									"ALLOW_UNORDERED_RECEIPTS_FLAG"
      ,APS.ENFORCE_SHIP_TO_LOCATION_CODE                    									"ENFORCE_SHIP_TO_LOCATION_CODE"
      ,APS.QTY_RCV_EXCEPTION_CODE                           									"QTY_RCV_EXCEPTION_CODE"
      ,APS.RECEIPT_DAYS_EXCEPTION_CODE                      									"RECEIPT_DAYS_EXCEPTION_CODE"
      ,APS.INSPECTION_REQUIRED_FLAG                         									"INSPECTION_REQUIRED_FLAG"
      ,APS.RECEIPT_REQUIRED_FLAG                            									"RECEIPT_REQUIRED_FLAG"
      ,APS.QTY_RCV_TOLERANCE                                									"QTY_RCV_TOLERANCE"
      ,APS.DAYS_EARLY_RECEIPT_ALLOWED                       									"DAYS_EARLY_RECEIPT_ALLOWED"
      ,APS.RECEIVING_ROUTING_ID                             									"RECEIVING_ROUTING_ID"
      ,HCP_PHONE.PHONE_COUNTRY_CODE           																							"PHONE_COUNTRY_CODE"
      ,HCP_PHONE.PHONE_EXTENSION        	      																						"PHONE_EXTENSION"
      ,HCP_FAX.PHONE_COUNTRY_CODE             																							"FAX_COUNTRY_CODE"
						,ASSA.INACTIVE_DATE                                   									"INACTIVE_DATE"
      ,APS.DAYS_LATE_RECEIPT_ALLOWED                        									"DAYS_LATE_RECEIPT_ALLOWED"
						,ASSA.VAT_CODE                                        									"VAT_CODE"
      ,ASSA.VAT_REGISTRATION_NUM                            									"VAT_REGISTRATION_NUM"
      ,ASSA.SHIP_VIA_LOOKUP_CODE                            									"SHIP_VIA_LOOKUP_CODE"
      ,ASSA.REMITTANCE_EMAIL                                									"REMITTANCE_EMAIL"
      ,ASSA.SERVICES_TOLERANCE_ID                           									"SERVICES_TOLERANCE_ID"
      ,(SELECT APT.TOLERANCE_NAME
					 	   FROM AP_TOLERANCES@{0} APT
						 		WHERE APT.TOLERANCE_ID = ASSA.SERVICES_TOLERANCE_ID)        "SERVICES_TOLERANCE"
						,(SELECT HRL.LOCATION_CODE
						   FROM HR_LOCATIONS@{0} HRL
        WHERE HRL.LOCATION_ID = ASSA.BILL_TO_LOCATION_ID)            "BILL_TO_LOCATION_CODE"
						,(SELECT HRL.LOCATION_CODE
						   FROM HR_LOCATIONS@{0} HRL         
        WHERE HRL.LOCATION_ID = ASSA.SHIP_TO_LOCATION_ID)            "SHIP_TO_LOCATION_CODE"
						,ASSA.ATTRIBUTE_CATEGORY                  																					"ATTRIBUTE_CATEGORY"
						,ASSA.ATTRIBUTE1                        		  																			"ATTRIBUTE1"
						,ASSA.ATTRIBUTE2                         																						"ATTRIBUTE2"
						,ASSA.ATTRIBUTE3                         																						"ATTRIBUTE3"
						,ASSA.ATTRIBUTE4                         																						"ATTRIBUTE4"
						,ASSA.ATTRIBUTE5                         																						"ATTRIBUTE5"
						,ASSA.ATTRIBUTE6                         																						"ATTRIBUTE6"
						,ASSA.ATTRIBUTE7                         																						"ATTRIBUTE7"
						,ASSA.ATTRIBUTE8                         																						"ATTRIBUTE8"
						,ASSA.ATTRIBUTE9                       	  																					"ATTRIBUTE9"
						,ASSA.ATTRIBUTE10                      			  																			"ATTRIBUTE10"
						,ASSA.ATTRIBUTE11                        																						"ATTRIBUTE11"
						,ASSA.ATTRIBUTE12                        																						"ATTRIBUTE12"
						,ASSA.ATTRIBUTE13                        																						"ATTRIBUTE13"
						,ASSA.ATTRIBUTE14                        																						"ATTRIBUTE14"
						,ASSA.ATTRIBUTE15                        																						"ATTRIBUTE15"
						,ASSA.GLOBAL_ATTRIBUTE_CATEGORY        	  																					"GLOBAL_ATTRIBUTE_CATEGORY"
						,ASSA.GLOBAL_ATTRIBUTE1                			  																			"GLOBAL_ATTRIBUTE1"
						,ASSA.GLOBAL_ATTRIBUTE2                  																						"GLOBAL_ATTRIBUTE2"
						,ASSA.GLOBAL_ATTRIBUTE3                  																						"GLOBAL_ATTRIBUTE3"
						,ASSA.GLOBAL_ATTRIBUTE4                  																						"GLOBAL_ATTRIBUTE4"
						,ASSA.GLOBAL_ATTRIBUTE5                  																						"GLOBAL_ATTRIBUTE5"
						,ASSA.GLOBAL_ATTRIBUTE6                  																						"GLOBAL_ATTRIBUTE6"
						,ASSA.GLOBAL_ATTRIBUTE7                  																						"GLOBAL_ATTRIBUTE7"
						,ASSA.GLOBAL_ATTRIBUTE8                  																						"GLOBAL_ATTRIBUTE8"
						,ASSA.GLOBAL_ATTRIBUTE9                  																						"GLOBAL_ATTRIBUTE9"
						,ASSA.GLOBAL_ATTRIBUTE10                 																						"GLOBAL_ATTRIBUTE10"
		FROM AP_SUPPLIERS@{0} APS
		    ,AP_SUPPLIER_SITES_ALL@{0} ASSA
		    ,HZ_PARTY_SITES@{0} HPS
						,HR_OPERATING_UNITS@{0} HOU
      ,HZ_CONTACT_POINTS@{0} HCP_PHONE
      ,HZ_CONTACT_POINTS@{0} HCP_FAX
      ,IBY_EXTERNAL_PAYEES_ALL@{0} IEPA
		WHERE 1 = 1
    --AND APS.SEGMENT1 = '5033'
    AND APS.VENDOR_ID = ASSA.VENDOR_ID
		  AND ASSA.PARTY_SITE_ID = HPS.PARTY_SITE_ID
				AND ASSA.ORG_ID = HOU.ORGANIZATION_ID
    AND HCP_PHONE.OWNER_TABLE_ID(+) = HPS.PARTY_SITE_ID 
    AND HCP_PHONE.OWNER_TABLE_NAME(+) = 'HZ_PARTY_SITES' 
    AND HCP_PHONE.CONTACT_POINT_TYPE(+) = 'PHONE' 
    AND HCP_PHONE.PHONE_LINE_TYPE (+) = 'GEN'
    AND HCP_FAX.OWNER_TABLE_ID(+) = HPS.PARTY_SITE_ID 
    AND HCP_FAX.OWNER_TABLE_NAME(+) = 'HZ_PARTY_SITES' 
    AND HCP_FAX.CONTACT_POINT_TYPE(+) = 'PHONE' 
    AND HCP_FAX.PHONE_LINE_TYPE (+) = 'FAX'
    -- AND APS.PARTY_ID = IEPA.PAYEE_PARTY_ID
    AND HPS.PARTY_SITE_ID = IEPA.PARTY_SITE_ID
    AND ASSA.VENDOR_SITE_ID = IEPA.SUPPLIER_SITE_ID
    