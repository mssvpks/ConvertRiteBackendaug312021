SELECT DISTINCT APS.VENDOR_ID                                   "VENDOR_ID"
               ,APS.SEGMENT1                                    "VENDOR_NUM"
															,APS.VENDOR_NAME                                 "VENDOR_NAME"
               ,HP.PARTY_ID                                     "PER_PARTY_ID"
															,HP.PERSON_FIRST_NAME                            "FIRST_NAME"
               ,HP.PERSON_LAST_NAME                             "LAST_NAME"
               ,HP_EMAIL.EMAIL_ADDRESS                          "EMAIL_ADDRESS"
               ,HPS.PARTY_SITE_ID                               "PARTY_SITE_ID"
               ,HPS.PARTY_SITE_NAME                             "PARTY_SITE_NAME"
               --,HP_EMAIL.PRIMARY_PHONE_AREA_CODE||' '||HP_EMAIL.PRIMARY_PHONE_NUMBER   "PHONE_NUMBER"
						         --,ASSA.VENDOR_SITE_CODE                               "VENDOR_SITE_CODE"
               --,RTRIM(TRIM(ASSA.ADDRESS_LINE1||' '||ASSA.CITY||','||ASSA.STATE||' '||ASSA.ZIP),',')
               --,FU.USER_NAME
															,APS.ATTRIBUTE_CATEGORY                          "ATTRIBUTE_CATEGORY"
															,APS.ATTRIBUTE1                                  "ATTRIBUTE1"
															,APS.ATTRIBUTE2                                  "ATTRIBUTE2"
															,APS.ATTRIBUTE3                                  "ATTRIBUTE3"
															,APS.ATTRIBUTE4                                  "ATTRIBUTE4"
															,APS.ATTRIBUTE5                                  "ATTRIBUTE5"
															,APS.ATTRIBUTE6                                  "ATTRIBUTE6"
															,APS.ATTRIBUTE7                                  "ATTRIBUTE7"
															,APS.ATTRIBUTE8                                  "ATTRIBUTE8"
															,APS.ATTRIBUTE9                                  "ATTRIBUTE9"
															,APS.ATTRIBUTE10                                 "ATTRIBUTE10"
															,APS.ATTRIBUTE11                                 "ATTRIBUTE11"
															,APS.ATTRIBUTE12                                 "ATTRIBUTE12"
															,APS.ATTRIBUTE13                                 "ATTRIBUTE13"
															,APS.ATTRIBUTE14                                 "ATTRIBUTE14"
															,APS.ATTRIBUTE15                                 "ATTRIBUTE15"
															,APS.GLOBAL_ATTRIBUTE_CATEGORY                   "GLOBAL_ATTRIBUTE_CATEGORY"
															,APS.GLOBAL_ATTRIBUTE1                           "GLOBAL_ATTRIBUTE1"
															,APS.GLOBAL_ATTRIBUTE2                           "GLOBAL_ATTRIBUTE2"
															,APS.GLOBAL_ATTRIBUTE3                           "GLOBAL_ATTRIBUTE3"
															,APS.GLOBAL_ATTRIBUTE4                           "GLOBAL_ATTRIBUTE4"
															,APS.GLOBAL_ATTRIBUTE5                           "GLOBAL_ATTRIBUTE5"
															,APS.GLOBAL_ATTRIBUTE6                           "GLOBAL_ATTRIBUTE6"
															,APS.GLOBAL_ATTRIBUTE7                           "GLOBAL_ATTRIBUTE7"
															,APS.GLOBAL_ATTRIBUTE8                           "GLOBAL_ATTRIBUTE8"
															,APS.GLOBAL_ATTRIBUTE9                           "GLOBAL_ATTRIBUTE9"
															,APS.GLOBAL_ATTRIBUTE10                          "GLOBAL_ATTRIBUTE10"
											FROM AP_SUPPLIERS@{0} APS
															,AP_SUPPLIER_SITES_ALL@{0} ASSA
               ,HZ_PARTY_SITES@{0} HPS
															,HZ_PARTIES@{0} HP_EMAIL
															,HZ_RELATIONSHIPS@{0} HR
															,HZ_PARTIES@{0} HP
															--,FND_USER FU
										WHERE 1=1
            AND APS.SEGMENT1 = '5033'
												AND ASSA.VENDOR_ID = APS.VENDOR_ID
            AND APS.PARTY_ID = HPS.PARTY_ID
												AND HR.SUBJECT_ID = APS.PARTY_ID
												AND HR.PARTY_ID = HP_EMAIL.PARTY_ID
												AND HR.OBJECT_ID = HP.PARTY_ID
												AND HR.RELATIONSHIP_CODE = 'CONTACT'
												AND HR.OBJECT_TABLE_NAME = 'HZ_PARTIES'
												--AND FU.PERSON_PARTY_ID(+)=HR.SUBJECT_ID
            AND ASSA.PARTY_SITE_ID = HPS.PARTY_SITE_ID
           
												
												
