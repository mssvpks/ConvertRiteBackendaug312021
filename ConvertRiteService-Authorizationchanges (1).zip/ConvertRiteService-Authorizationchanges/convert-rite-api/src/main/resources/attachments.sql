SELECT DISTINCT FAD.ATTACHED_DOCUMENT_ID                       "ATTACHED_DOCUMENT_ID"
															,FD.DOCUMENT_ID                                 "DOCUMENT_ID"
															,APS.VENDOR_ID                                  "VENDOR_ID"
															,APS.VENDOR_NAME                                "VENDOR_NAME"
															--,ASSA.VENDOR_SITE_ID                            "VENDOR_SITE_ID"
															--,ASSA.VENDOR_SITE_CODE                          "VENDOR_SITE_CODE"
															--,ASSA.ORG_ID                                    "PRC_BU_ID"
															--,(SELECT NAME
															--				FROM HR_OPERATING_UNITS HOU
															--			WHERE HOU.ORGANIZATION_ID = ASSA.ORG_ID)     "PROCUREMENT_BUSINESS_UNIT_NAME"
															--,PBCA.CLASSIFICATION_ID                         "CLASSIFICATION_ID"
															--,PBCA.LOOKUP_CODE                               "CLASSIFICATION_LOOKUP_CODE"
															--,PBCA.CERTIFYING_AGENCY                         "CERTIFYING_AGENCY_NAME"
															--,PBCA.CERTIFICATE_NUMBER                        "CERTIFICATE_NUMBER"
															,FDCT.NAME                                      "ATTACHMENT_CATEGORY"
															,FDCT.USER_NAME                                 "USER_ATTACHMENT_CATEGORY"
															,DECODE(FDD.NAME,'WEB_PAGE','URL',FDD.NAME)     "ATTACHMENT_TYPE"
															,DECODE(FDD.NAME, 'WEB_PAGE', FD.URL, 'URL',FD.URL,'FILE',FL.FILE_NAME,FDD.NAME)   "FILE_TEXT_URL"
															,FDT.TITLE                                      "ATTACHMENT_TITLE"
															,FDT.DESCRIPTION                                "ATTACHMENT_DESCRIPTION"
															,APS.ATTRIBUTE_CATEGORY                         "ATTRIBUTE_CATEGORY"
															,APS.ATTRIBUTE1                             				"ATTRIBUTE1"
															,APS.ATTRIBUTE2                             				"ATTRIBUTE2"
															,APS.ATTRIBUTE3                             				"ATTRIBUTE3"
															,APS.ATTRIBUTE4                             				"ATTRIBUTE4"
															,APS.ATTRIBUTE5                             				"ATTRIBUTE5"
															,APS.ATTRIBUTE6                             				"ATTRIBUTE6"
															,APS.ATTRIBUTE7                             				"ATTRIBUTE7"
															,APS.ATTRIBUTE8                             				"ATTRIBUTE8"
															,APS.ATTRIBUTE9                             				"ATTRIBUTE9"
															,APS.ATTRIBUTE10                            				"ATTRIBUTE10"
															,APS.ATTRIBUTE11                            				"ATTRIBUTE11"
															,APS.ATTRIBUTE12                            				"ATTRIBUTE12"
															,APS.ATTRIBUTE13                            				"ATTRIBUTE13"
															,APS.ATTRIBUTE14                            				"ATTRIBUTE14"
															,APS.ATTRIBUTE15                            				"ATTRIBUTE15"
															,APS.GLOBAL_ATTRIBUTE_CATEGORY              				"GLOBAL_ATTRIBUTE_CATEGORY"
															,APS.GLOBAL_ATTRIBUTE1                 	     			"GLOBAL_ATTRIBUTE1"
															,APS.GLOBAL_ATTRIBUTE2                      				"GLOBAL_ATTRIBUTE2"
															,APS.GLOBAL_ATTRIBUTE3                      				"GLOBAL_ATTRIBUTE3"
															,APS.GLOBAL_ATTRIBUTE4                      				"GLOBAL_ATTRIBUTE4"
															,APS.GLOBAL_ATTRIBUTE5                      				"GLOBAL_ATTRIBUTE5"
															,APS.GLOBAL_ATTRIBUTE6                      				"GLOBAL_ATTRIBUTE6"
															,APS.GLOBAL_ATTRIBUTE7                      				"GLOBAL_ATTRIBUTE7"
															,APS.GLOBAL_ATTRIBUTE8                      				"GLOBAL_ATTRIBUTE8"
															,APS.GLOBAL_ATTRIBUTE9                      				"GLOBAL_ATTRIBUTE9"
															,APS.GLOBAL_ATTRIBUTE10                				     "GLOBAL_ATTRIBUTE10"
											FROM AP_SUPPLIERS@{0} APS
															,AP_SUPPLIER_SITES_ALL@{0} ASSA
															,POS_BUS_CLASS_ATTR@{0} PBCA
															,FND_ATTACHED_DOCUMENTS@{0} FAD
															,FND_DOCUMENT_CATEGORIES_TL@{0} FDCT
															,FND_DOCUMENTS_TL@{0} FDT
															,FND_DOCUMENTS@{0} FD
															,FND_DOCUMENT_DATATYPES@{0} FDD
															,FND_LOBS@{0} FL
										WHERE 1=1
												--AND APS.SEGMENT1 = '5023'
												AND APS.VENDOR_ID = ASSA.VENDOR_ID
												AND PBCA.VENDOR_ID (+) = APS.VENDOR_ID
												AND FAD.ENTITY_NAME = 'PO_VENDORS' 
												AND TO_CHAR(APS.VENDOR_ID) = FAD.PK1_VALUE
												AND FAD.CATEGORY_ID = FDCT.CATEGORY_ID (+)
												AND FDT.DOCUMENT_ID = FD.DOCUMENT_ID
												AND FD.DOCUMENT_ID = FAD.DOCUMENT_ID
												AND FD.DATATYPE_ID = FDD.DATATYPE_ID
												AND FD.MEDIA_ID = FL.FILE_ID (+)
						