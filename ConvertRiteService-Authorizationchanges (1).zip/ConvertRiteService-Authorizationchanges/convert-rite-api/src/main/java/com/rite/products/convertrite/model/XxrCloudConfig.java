package com.rite.products.convertrite.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "XXR_CLOUD_CONFIG")
public class XxrCloudConfig {
	@Id
	@Column(name = "OBJECT_CODE")
	private String objectCode;
	@Column(name = "XLSM_FILE_NAME")
	private String xlsmFileName;
	@Column(name = "SHEET_NAME")
	private String sheetName;
	@Column(name = "CTL_FILE_NAME")
	private String ctlFileName;
	@Column(name = "INTERFACE_TABLE_NAME")
	private String interfaceTableName;

	public String getObjectCode() {
		return objectCode;
	}

	public void setObjectCode(String objectCode) {
		this.objectCode = objectCode;
	}

	public String getXlsmFileName() {
		return xlsmFileName;
	}

	public void setXlsmFileName(String xlsmFileName) {
		this.xlsmFileName = xlsmFileName;
	}

	public String getSheetName() {
		return sheetName;
	}

	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}

	public String getCtlFileName() {
		return ctlFileName;
	}

	public void setCtlFileName(String ctlFileName) {
		this.ctlFileName = ctlFileName;
	}

	public String getInterfaceTableName() {
		return interfaceTableName;
	}

	public void setInterfaceTableName(String interfaceTableName) {
		this.interfaceTableName = interfaceTableName;
	}

}
