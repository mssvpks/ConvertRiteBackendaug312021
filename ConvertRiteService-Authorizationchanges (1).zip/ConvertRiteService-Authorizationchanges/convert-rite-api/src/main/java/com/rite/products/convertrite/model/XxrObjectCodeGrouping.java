package com.rite.products.convertrite.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "XXR_OBJECT_CODE_GROUPING")
public class XxrObjectCodeGrouping {

	@Id
	@Column(name = "GROUP_ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "objectcode_grouping_generator")
	@SequenceGenerator(name = "objectcode_grouping_generator", sequenceName = "xxr_object_code_grouping_id_s", allocationSize = 1)
	private Long groupId;
	@Column(name = "GROUP_NAME")
	private String groupName;
	@Column(name = "CTL_FILE")
	private String ctlFile;
	@Column(name = "VERSION")
	private String version;

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getCtlFile() {
		return ctlFile;
	}

	public void setCtlFile(String ctlFile) {
		this.ctlFile = ctlFile;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

}
