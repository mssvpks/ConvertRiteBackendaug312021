package com.rite.products.convertrite.service;

import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.servlet.http.HttpServletResponse;

import org.apache.axiom.attachments.ByteArrayDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.opencsv.CSVWriter;
import com.rite.products.convertrite.Validations.Validations;
import com.rite.products.convertrite.exception.ValidationException;
import com.rite.products.convertrite.model.XxrCloudTemplateHeader;
import com.rite.products.convertrite.model.XxrErpIntegration;
import com.rite.products.convertrite.model.XxrTemplateRelation;
import com.rite.products.convertrite.po.LoadImportJobStatusResPo;
import com.rite.products.convertrite.po.LoadandImportDataReqPo;
import com.rite.products.convertrite.po.LoadandImportDataResPo;
import com.rite.products.convertrite.respository.XxrCloudConfigRepository;
import com.rite.products.convertrite.respository.XxrCloudTableRepository;
import com.rite.products.convertrite.respository.XxrCloudTemplateHeadersRepository;
import com.rite.products.convertrite.respository.XxrErpIntegrationRepository;
import com.rite.products.convertrite.respository.XxrLookUpValuesRepository;
import com.rite.products.convertrite.respository.XxrObjectCodeGroupingLinesRepository;
import com.rite.products.convertrite.respository.XxrTemplateRelationRepository;
import com.rite.products.convertrite.stubs.erp.ErpIntegrationServiceStub;
import com.rite.products.convertrite.stubs.erp.ErpIntegrationServiceStub.Base64BinaryDataHandler;
import com.rite.products.convertrite.stubs.erp.ErpIntegrationServiceStub.DocumentDetails;
import com.rite.products.convertrite.stubs.erp.ErpIntegrationServiceStub.DownloadExportOutput;
import com.rite.products.convertrite.stubs.erp.ErpIntegrationServiceStub.DownloadExportOutputResponse;
import com.rite.products.convertrite.stubs.erp.ErpIntegrationServiceStub.EssJob;
import com.rite.products.convertrite.stubs.erp.ErpIntegrationServiceStub.ExportBulkData;
import com.rite.products.convertrite.stubs.erp.ErpIntegrationServiceStub.ExportBulkDataResponse;
import com.rite.products.convertrite.stubs.erp.ErpIntegrationServiceStub.GetESSExecutionDetails;
import com.rite.products.convertrite.stubs.erp.ErpIntegrationServiceStub.GetESSExecutionDetailsResponse;
import com.rite.products.convertrite.stubs.erp.ErpIntegrationServiceStub.LoadAndImportData;
import com.rite.products.convertrite.stubs.erp.ErpIntegrationServiceStub.LoadAndImportDataResponse;
import com.rite.products.convertrite.stubs.erp.ErpIntegrationServiceStub.UploadFileToUcm;
import com.rite.products.convertrite.stubs.erp.ErpIntegrationServiceStub.UploadFileToUcmResponse;
import com.rite.products.convertrite.utils.DataSourceUtil;
import com.rite.products.convertrite.utils.Utils;

@Service
public class ErpIntegrationServiceImpl implements ErpIntegrationService {

	private static final Logger log = LoggerFactory.getLogger(ErpIntegrationServiceImpl.class);

	@Autowired
	XxrCloudTemplateHeadersRepository xxrCloudTemplateHeadersRepository;
	@Autowired
	XxrCloudTableRepository xxrCloudTableRepository;
	@Autowired
	DataSourceUtil dataSourceUtil;
	@Autowired
	Utils util;
	@Autowired
	XxrErpIntegrationRepository xxrErpIntegrationRepository;
	@Autowired
	XxrObjectCodeGroupingLinesRepository xxrObjectCodeGroupingLinesRepository;
	@Autowired
	XxrTemplateRelationRepository xxrTemplateRelationRepository;
	@Autowired
	XxrLookUpValuesRepository xxrLookUpValuesRepository;
	@Autowired
	XxrCloudConfigRepository xxrCloudConfigRepository;

	@Value("${erp_url}")
	private String erpurl;

	@Override
	public LoadandImportDataResPo loadAndImportData(LoadandImportDataReqPo loadandImportDataReqPo) throws Exception {
		log.info("Start of  loadAndImportData Method#####");

		Path target = null;
		List<XxrCloudTemplateHeader> cloudTemplateHeaderList = new ArrayList<>();
		Long metaDataTableId = null;
		String metaDataTableName = "";
		Long cloudTemplateId = null;
		String clobString = "";
		Long objectId = null;
		Long parentObjectId = null;
		Long groupId = null;
		LoadandImportDataResPo loadImportDataRes = new LoadandImportDataResPo();
		String csvName = "";
		Long resultId = null;
		try {
			cloudTemplateId = loadandImportDataReqPo.getCloudTemplateId();
			cloudTemplateHeaderList = xxrCloudTemplateHeadersRepository.getCloudTemplateById(cloudTemplateId);
			XxrCloudTemplateHeader xxrCloudTemplateHeader = cloudTemplateHeaderList.get(0);
			objectId = xxrCloudTemplateHeader.getObjectId();
			parentObjectId = xxrCloudTemplateHeader.getParentObjectId();
			String objecCode = xxrLookUpValuesRepository.getValueById(objectId);
			String parentObjectCode = xxrLookUpValuesRepository.getValueById(parentObjectId);
			csvName = util.getCtlFileName(objecCode);
			if (xxrCloudTemplateHeader != null)
				metaDataTableId = xxrCloudTemplateHeader.getMetaDataTableId();
			if (metaDataTableId != null) {
				metaDataTableName = xxrCloudTableRepository.getMetaDataTableName(metaDataTableId);
			}
			// Create csv from clob in temp directory
			target = Files.createTempDirectory("");
			System.out.println("target:::::" + target);
			groupId = xxrObjectCodeGroupingLinesRepository.getGroupIdbyObjectId(objectId);
			XxrTemplateRelation xxrTemplateRelation = null;
			String zipfilePath = "";
			if (groupId != null) {
				// create csv files and zip them
				zipfilePath = target + File.separator + util.getCtlFileName(objecCode) + ".zip";
				xxrTemplateRelation = creatingCsvFilesAndZip(loadandImportDataReqPo, target, groupId);
			} else {
				writingToCsv(cloudTemplateId, target.toString(), csvName);
				zipfilePath = target + File.separator + metaDataTableName + ".zip";
				// zip csv file
				Utils.zipFile(target.toString(), metaDataTableName, csvName + ".csv");
			}
			// String url =
			// "https://ucf3-ztzb-fa-ext.oracledemos.com:443/fscmService/ErpIntegrationService";

			String soapUrl = util.getCloudUrl() + erpurl;
			ErpIntegrationServiceStub erpIntegrationServiceStub = new ErpIntegrationServiceStub(soapUrl);
			// BasicAuthentication for soap service
			util.basicAuthentication(erpIntegrationServiceStub._getServiceClient());

			if ("Customer".equalsIgnoreCase(parentObjectCode)) {
				//Independent soap service call for uploadFileToUcm, ExportBulkData Application Tables
				resultId = loadAndImportIndependentService(erpIntegrationServiceStub, loadandImportDataReqPo, zipfilePath);
			} else {
				// soapservice call for loadAndImportData
				resultId = loadAndImportService(erpIntegrationServiceStub, loadandImportDataReqPo, zipfilePath);
			}
			// save details into ERPINEGRATION table
			saveErpIntegrationDetails(loadandImportDataReqPo, resultId);

			if (xxrTemplateRelation != null) {
				xxrTemplateRelation.setIsZipped("Y");
				xxrTemplateRelationRepository.save(xxrTemplateRelation);
			}
			loadImportDataRes.setResultId(resultId);
			loadImportDataRes.setMessage("Sucessfully load and import submitted");

		} catch (ValidationException e) {
			// e.printStackTrace();
			log.error(e.getMessage());
			throw new ValidationException(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
		// TODO Auto-generated method stub
		return loadImportDataRes;
	}

	private XxrTemplateRelation creatingCsvFilesAndZip(LoadandImportDataReqPo loadandImportDataReqPo, Path target,
			Long groupId) throws Exception {
		String clobString = "";
		Long objectId = null;
		XxrTemplateRelation xxrTemplateRelation = null;
		try {
			Predicate<XxrTemplateRelation> filterTemplateGrouping = x -> {
				String[] strArr = x.getTemplateIds().split(",");
				Long cldTemplateId = loadandImportDataReqPo.getCloudTemplateId();
				boolean flag = false;
				for (String s : strArr) {
					long templateId = Long.parseLong(s);
					if (templateId == cldTemplateId) {
						flag = true;
						break;
					}
				}
				return flag;
			};
			List<XxrTemplateRelation> xxrTemplateRelationLi = xxrTemplateRelationRepository
					.getTemplatRelations(groupId);
			if (xxrTemplateRelationLi.stream().filter(filterTemplateGrouping).count() <= 0)
				throw new ValidationException(
						"This Template is not part of template grouping,Please add into template grouping");
			xxrTemplateRelation = xxrTemplateRelationLi.stream().filter(filterTemplateGrouping).findFirst().get();
			if (xxrTemplateRelation != null) {
				String templateArr[] = xxrTemplateRelation.getTemplateIds().split(",");
				List<String> listOfCsvContents = new ArrayList<>();
				List<String> fileNames = new ArrayList<>();
				for (String tempId : templateArr) {
					long templateId = Long.parseLong(tempId);
					List<XxrCloudTemplateHeader> cloudTemplateHeaderLi = xxrCloudTemplateHeadersRepository
							.getCloudTemplateById(templateId);
					XxrCloudTemplateHeader cloudTemplateHeader = cloudTemplateHeaderLi.get(0);
					objectId = cloudTemplateHeader.getObjectId();
					String objectCode = xxrLookUpValuesRepository.getValueById(objectId);
					// util.getFileName(objectCode);
					String sql = "select xxr_conversion_utils_pkg.fbdi_filegen(" + templateId + ") from dual";
					clobString = util.getClobString(sql);
					// System.out.println(clobString+"clobString##########");
					listOfCsvContents.add(clobString);
					// fileNames.add(util.getFileName(objectCode));
					fileNames.add(util.getCtlFileName(objectCode));
				}
				Utils.zipMultipleFiles(listOfCsvContents, target.toString(), fileNames);
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return xxrTemplateRelation;
	}

	private void writingToCsv(Long cloudTemplateId, String target, String csvName) throws Exception {
		String clobString = "";
		String sql = "select xxr_conversion_utils_pkg.fbdi_filegen(" + cloudTemplateId + ") from dual";
		clobString = util.getClobString(sql);
		String filePath = target + File.separator + csvName + ".csv";
		File file = new File(filePath);
		FileWriter outputfile = new FileWriter(file);
		// create CSVWriter with ',' as separator
		CSVWriter writerObj = new CSVWriter(outputfile, CSVWriter.DEFAULT_SEPARATOR, CSVWriter.NO_QUOTE_CHARACTER,
				CSVWriter.NO_ESCAPE_CHARACTER, CSVWriter.DEFAULT_LINE_END);
		if (!Validations.isNullOrEmpty(clobString))
			writerObj.writeNext(clobString.split(","));
		writerObj.flush();
		writerObj.close();
	}

	private Long loadAndImportIndependentService(ErpIntegrationServiceStub erpIntegrationServiceStub,
			LoadandImportDataReqPo loadImportDataReq, String zipfilePath) throws Exception {
		log.info("Start of loadAndImportService Method######");
		Long result = null;
		try {
			DataSource source = new ByteArrayDataSource(Files.readAllBytes(Paths.get(zipfilePath)),
					"text/plain;charset=UTF-8");
			DataHandler dataHandler = new DataHandler(source);
			Base64BinaryDataHandler base64BinaryDataHandler = new Base64BinaryDataHandler();
			base64BinaryDataHandler.setBase64BinaryDataHandler(dataHandler);

			// Creating DocumentDetails
			DocumentDetails documentDetails = new DocumentDetails();
			documentDetails.setContentType(loadImportDataReq.getContentType());
			documentDetails.setContent(base64BinaryDataHandler);
			documentDetails.setDocumentAccount(loadImportDataReq.getDocumentAccount());
			documentDetails.setDocumentAuthor(loadImportDataReq.getDocumentAuthor());
			documentDetails.setDocumentSecurityGroup(loadImportDataReq.getDocumentSecurityGroup());
			documentDetails.setDocumentTitle(loadImportDataReq.getDocumentTitle());
			documentDetails.setFileName(loadImportDataReq.getFileName());

			UploadFileToUcm uploadFileToUcm0 = new UploadFileToUcm();
			uploadFileToUcm0.setDocument(documentDetails);
			// upload File to UCM service call
			UploadFileToUcmResponse uploadFileRes = erpIntegrationServiceStub.uploadFileToUcm(uploadFileToUcm0);
			String documentId = uploadFileRes.getResult();
			String parameterList = loadImportDataReq.getParameterList();
			if (parameterList.contains("{0}")) {
				parameterList = parameterList.replace("{0}", documentId);
				log.info(parameterList);
			}
			ExportBulkData exportBulkData = new ExportBulkData();
			exportBulkData.setJobName(loadImportDataReq.getJobName());
			exportBulkData.setCallbackURL("#NULL");
			exportBulkData.setParameterList(parameterList);
			exportBulkData.setNotificationCode("30");
			ExportBulkDataResponse exportBulkRes = erpIntegrationServiceStub.exportBulkData(exportBulkData);
			result = exportBulkRes.getResult();

		} catch (Exception e) {
			// e.printStackTrace();
			throw new Exception(e.getMessage());
		}
		return result;
	}

	private Long loadAndImportService(ErpIntegrationServiceStub erpIntegrationServiceStub,
			LoadandImportDataReqPo loadImportDataReq, String zipfilePath) throws Exception {
		log.info("Start of loadAndImportService Method######");
		Long result = null;
		try {

			DataSource source = new ByteArrayDataSource(Files.readAllBytes(Paths.get(zipfilePath)),
					"text/plain;charset=UTF-8");
			DataHandler dataHandler = new DataHandler(source);
			Base64BinaryDataHandler base64BinaryDataHandler = new Base64BinaryDataHandler();
			base64BinaryDataHandler.setBase64BinaryDataHandler(dataHandler);

			// Creating DocumentDetails
			DocumentDetails documentDetails = new DocumentDetails();
			documentDetails.setContentType(loadImportDataReq.getContentType());
			documentDetails.setContent(base64BinaryDataHandler);
			documentDetails.setDocumentAccount(loadImportDataReq.getDocumentAccount());
			documentDetails.setDocumentAuthor(loadImportDataReq.getDocumentAuthor());
			documentDetails.setDocumentSecurityGroup(loadImportDataReq.getDocumentSecurityGroup());
			documentDetails.setDocumentTitle(loadImportDataReq.getDocumentTitle());
			documentDetails.setFileName(loadImportDataReq.getFileName());

			// creating job details
			EssJob[] essJob = new EssJob[1];

			EssJob job = new EssJob();
			job.setJobName(loadImportDataReq.getJobName());
			job.setParameterList(loadImportDataReq.getParameterList());
			essJob[0] = job;

			LoadAndImportData loadAndImportData = new LoadAndImportData();
			loadAndImportData.setDocument(documentDetails);
			loadAndImportData.setInterfaceDetails(loadImportDataReq.getInterfaceDetails());
			loadAndImportData.setJobList(essJob);
			loadAndImportData.setCallbackURL("#NULL");
			LoadAndImportDataResponse resp = erpIntegrationServiceStub.loadAndImportData(loadAndImportData);
			result = resp.getResult();

		} catch (Exception e) {
			// e.printStackTrace();
			throw new Exception(e.getMessage());
		}
		return result;
	}

	private void saveErpIntegrationDetails(LoadandImportDataReqPo loadImportDataReq, Long result) throws Exception {
		XxrErpIntegration erpIntegration = new XxrErpIntegration();
		try {
			erpIntegration.setContentType(loadImportDataReq.getContentType());
			erpIntegration.setCloudTemplateId(loadImportDataReq.getCloudTemplateId());
			erpIntegration.setDocumentAccount(loadImportDataReq.getDocumentAccount());
			erpIntegration.setDocumentAuthor(loadImportDataReq.getDocumentAuthor());
			erpIntegration.setDocumentSecurityGroup(loadImportDataReq.getDocumentSecurityGroup());
			erpIntegration.setDocumentTitle(loadImportDataReq.getDocumentTitle());
			erpIntegration.setFileName(loadImportDataReq.getFileName());
			erpIntegration.setInterfaceDetails(loadImportDataReq.getInterfaceDetails());
			erpIntegration.setJobName(loadImportDataReq.getJobName());
			erpIntegration.setParameterList(loadImportDataReq.getParameterList());
			erpIntegration.setResult(result);
			xxrErpIntegrationRepository.save(erpIntegration);
		} catch (Exception e) {
			// e.printStackTrace();
			throw new Exception(e.getMessage());
		}
	}

	@Override
	public LoadImportJobStatusResPo getJobStatus(Long resultId) throws Exception {
		// TODO Auto-generated method stub
		log.info("Start of getJobStatus Method######");
		LoadImportJobStatusResPo loadImportJobStatusRes = new LoadImportJobStatusResPo();
		try {
			// String url =
			// "https://ucf3-ztzb-fa-ext.oracledemos.com:443/fscmService/ErpIntegrationService";
			String soapUrl = util.getCloudUrl() + erpurl;
			ErpIntegrationServiceStub erpIntegrationServiceStub = new ErpIntegrationServiceStub(soapUrl);

			// BasicAuthentication for soap service
			util.basicAuthentication(erpIntegrationServiceStub._getServiceClient());
			// Execution details
			GetESSExecutionDetails executionDetails = new GetESSExecutionDetails();
			executionDetails.setRequestId(resultId);

			GetESSExecutionDetailsResponse response = erpIntegrationServiceStub
					.getESSExecutionDetails(executionDetails);
			loadImportJobStatusRes.setResult(response.getResult());
			loadImportJobStatusRes.setMessage("Retrieved Job Status successfully");
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return loadImportJobStatusRes;
	}

	@Override
	public List<XxrErpIntegration> getErpIntegrationDetails() throws Exception {
		log.info("Start of getErpIntegrationDetails Method#####");
		// TODO Auto-generated method stub
		List<XxrErpIntegration> erpIntegrationLi = new ArrayList<>();
		try {
			erpIntegrationLi = xxrErpIntegrationRepository.findAll();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return erpIntegrationLi;
	}

	@Override
	public byte[] downloadExportOutput(String requestId, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		log.info("Start of downloadExportOutput Method#####");
		// ResponseBuilder response = null ;

		response.setContentType("application/zip");
		response.setStatus(HttpServletResponse.SC_OK);
		response.addHeader("Content-Disposition", "attachment; filename=" + requestId + ".zip");
		// Response resp=null;
		// ByteArrayOutputStream baos = new ByteArrayOutputStream();
		byte[] buf = null;
		try {
			DownloadExportOutput downloadExportOutput = new DownloadExportOutput();
			downloadExportOutput.setRequestId(requestId);
			// String url =
			// "https://ucf3-ztzb-fa-ext.oracledemos.com:443/fscmService/ErpIntegrationService";
			String soapUrl = util.getCloudUrl() + erpurl;
			ErpIntegrationServiceStub erpIntegrationServiceStub = new ErpIntegrationServiceStub(soapUrl);

			// BasicAuthentication for soap service
			util.basicAuthentication(erpIntegrationServiceStub._getServiceClient());

			DownloadExportOutputResponse downloadExportOutputResponse = erpIntegrationServiceStub
					.downloadExportOutput(downloadExportOutput);
			// System.out.println(DownloadExportOutputResponse.MY_QNAME+"##########MY_QNAME");
			// QName qName=new QName("ns0:","Content");

			DocumentDetails[] documentDetails = downloadExportOutputResponse.getResult();

			DocumentDetails details = documentDetails[0];

			DataHandler dataHandler = details.getContent().getBase64BinaryDataHandler();
			System.out.println("dataHandler::::" + dataHandler);
			buf = dataHandler.getDataSource().getInputStream().readAllBytes();
			/*
			 * OMElement omEle= downloadExportOutputResponse.getOMElement(new
			 * QName("Content"), org.apache.axiom.om.OMAbstractFactory.getOMFactory());
			 * System.out.println(omEle+"###########omEle");
			 * 
			 * System.out.println(omEle.getAttribute(new
			 * QName("ns0:Content"))+"contegentTag");
			 * 
			 * OMElement child = (OMElement) omEle.getFirstOMChild();
			 * System.out.println(child+"###########child"); OMAttribute attr =
			 * child.getAttribute(new QName("href"));
			 * 
			 * //Content ID processing String contentID = attr.getAttributeValue();
			 * contentID = contentID.trim(); if (contentID.substring(0,
			 * 3).equalsIgnoreCase("cid")) { contentID = contentID.substring(4); }
			 * 
			 * MessageContext msgCtx = MessageContext.getCurrentMessageContext();
			 * Attachments attachment = msgCtx.getAttachmentMap(); DataHandler dataHandler =
			 * attachment.getDataHandler(contentID);
			 */
			/*
			 * ZipOutputStream zos = new ZipOutputStream(baos); ZipEntry entry = new
			 * ZipEntry(requestId+".zip"); entry.setSize(buf.length);
			 * zos.putNextEntry(entry); zos.write(buf); zos.closeEntry(); zos.close();
			 */
			/*
			 * java.io.FileOutputStream out_zip_file = new
			 * java.io.FileOutputStream(requestId+".zip");
			 * out_zip_file.write(baos.toByteArray()); response= Response.ok((Object)
			 * out_zip_file); response.header("Content-Disposition",
			 * "attachment; filename="+requestId+".zip"); //
			 * response.setContentType("application/zip"); resp=response.build();
			 * out_zip_file.flush(); out_zip_file.close();
			 */

		} catch (Exception e) {
			// e.printStackTrace();
			throw new Exception(e.getMessage());
		}

		return buf;
	}

}
