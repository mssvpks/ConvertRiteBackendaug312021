package com.rite.products.convertrite.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.multipart.MultipartFile;

import com.rite.products.convertrite.model.XxrSrcSystemSqlClob;
import com.rite.products.convertrite.po.LoadDataFromEbsReqPo;
import com.rite.products.convertrite.po.LoadDataFromEbsResPo;
import com.rite.products.convertrite.po.LoadMetaDataFromEbsReqPo;
import com.rite.products.convertrite.po.LoadMetaDataFromEbsRes;
import com.rite.products.convertrite.po.SaveEbsIntegrationDetailsPo;
import com.rite.products.convertrite.po.SaveEbsIntegrationResponsePo;
import com.rite.products.convertrite.po.XxrEbsIntegrationDbDetailsResPo;

public interface EbsIntegrationService {

	SaveEbsIntegrationResponsePo saveEbsIntegrationDetails(SaveEbsIntegrationDetailsPo ebsIntegartionDetailsPo) throws Exception;

	List<XxrEbsIntegrationDbDetailsResPo> getEbsIntegrationDetails() throws Exception;

	LoadDataFromEbsResPo loadDataFromEbs(LoadDataFromEbsReqPo loadDataFromEbsReqPo,HttpServletRequest request)throws Exception;

	String getDbLink(Long podId, Long projectId, Long parentObjectId, Long objectId)throws Exception;

	LoadMetaDataFromEbsRes loadMetaDataFromEbs(LoadMetaDataFromEbsReqPo loadMetaDataFromEbsReqPo)throws Exception;

	XxrSrcSystemSqlClob uploadSqlFile(MultipartFile file, String sourceSystem, String objectCode, String version)throws Exception;

}
