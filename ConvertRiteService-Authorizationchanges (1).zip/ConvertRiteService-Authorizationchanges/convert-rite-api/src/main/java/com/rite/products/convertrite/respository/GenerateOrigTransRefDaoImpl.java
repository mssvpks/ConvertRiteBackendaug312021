package com.rite.products.convertrite.respository;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;
import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

@Repository
public class GenerateOrigTransRefDaoImpl {

	@PersistenceContext
	private EntityManager entityManager;
	
	private static final Logger log = LoggerFactory.getLogger(GenerateOrigTransRefDaoImpl.class);

	@Transactional
	public void generateOrigTranRef(long templateId, String tableName,HttpServletRequest request) {
		log.info("Start of generateOrigTranRef Method in DaoImpl### ");
		StoredProcedureQuery generateOrigTransRef = entityManager
				.createStoredProcedureQuery("xxr_insertion_utils_pkg.populate_orig_trans_id")	
				.registerStoredProcedureParameter("p_template_id", Long.class, ParameterMode.IN)
				.registerStoredProcedureParameter("p_table_name", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("p_user_id", String.class, ParameterMode.IN)
				.setParameter("p_table_name", tableName)
				.setParameter("p_template_id", templateId)
				.setParameter("p_user_id", request.getHeader("userId"));
		generateOrigTransRef.execute();
		entityManager.clear();
		entityManager.close();	
	}

}

