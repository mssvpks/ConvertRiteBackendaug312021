package com.rite.products.convertrite.po;

public class SaveObjectCodeGroupingLinesPo {

	private Long groupId;
	private Long objectId;

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public Long getObjectId() {
		return objectId;
	}

	public void setObjectId(Long objectId) {
		this.objectId = objectId;
	}

}
