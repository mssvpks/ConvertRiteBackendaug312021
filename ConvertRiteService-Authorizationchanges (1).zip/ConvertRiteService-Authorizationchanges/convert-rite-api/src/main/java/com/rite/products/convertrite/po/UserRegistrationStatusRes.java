package com.rite.products.convertrite.po;

public class UserRegistrationStatusRes {

	private String userRegStatus;

	public String getUserRegStatus() {
		return userRegStatus;
	}

	public void setUserRegStatus(String userRegStatus) {
		this.userRegStatus = userRegStatus;
	}
	
	
}
