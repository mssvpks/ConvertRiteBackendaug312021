package com.rite.products.convertrite.respository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.rite.products.convertrite.model.XxrRoleObjectLinks;
import com.rite.products.convertrite.model.XxrRoleObjectLinksId;
import com.rite.products.convertrite.po.TaskOwnerLov;

@Repository
public interface XxrRoleObjectLinksRepository extends JpaRepository<XxrRoleObjectLinks, XxrRoleObjectLinksId> {

	List<XxrRoleObjectLinks> findByRoleId(long roleId);

	/*
	 * @Query("select x from XxrRoleObjectLinks x,XxrRoles y where x.roleId=y.id and y.roleName =:roleName"
	 * ) List<XxrRoleObjectLinks> getByrole(@Param("roleName") String roleName);
	 */

	@Query("select x from XxrRoleObjectLinks x,XxrRoles y where x.roleId=y.id and y.roleName =:roleName and x.podId=:podId and x.projectId=:projectId")
	List<XxrRoleObjectLinks> getByrole(String roleName, Long podId, Long projectId);

	@Query("select x from XxrRoleObjectLinks x,XxrRoles y where x.roleId=y.id and y.roleName =:role")
	List<XxrRoleObjectLinks> getPodsByRole(String role);

	@Query("select x from XxrRoleObjectLinks x,XxrRoles y where x.roleId=y.id and y.roleName =:role and x.podId=:podId")
	List<XxrRoleObjectLinks> getProjectsByRole(String role, Long podId);

	//@Query("select new com.rite.products.convertrite.po.TaskOwnerLov(u.id,u.name) from XxrRoleObjectLinks x,XxrRoles y,XxrUserRoles z,XxrUsers u where x.roleId=y.id  and z.roleId=y.id and  z.userId=u.id and x.projectId=:projectId")
	@Query("select new com.rite.products.convertrite.po.TaskOwnerLov(u.id,u.name) from XxrRoleObjectLinks x,XxrUserRoles z,XxrUsers u where  z.roleId=x.roleId and  z.userId=u.id and x.projectId=:projectId")
	List<TaskOwnerLov> getTaskOwnerLov(@Param("projectId") Long projectId);
}
