package com.rite.products.convertrite.po;

public class ColumnPo {

	private long columnId;
	private String columnName;
	private String nullAllowedFlag;
	private String columnType;
	private String description;

	public ColumnPo(long columnId, String columnName, String nullAllowedFlag, String columnType) {
		super();
		this.columnId = columnId;
		this.columnName = columnName;
		this.nullAllowedFlag = nullAllowedFlag;
		this.columnType = columnType;
	}

	public ColumnPo(long columnId, String columnName, String nullAllowedFlag, String columnType, String description) {
		super();
		this.columnId = columnId;
		this.columnName = columnName;
		this.nullAllowedFlag = nullAllowedFlag;
		this.columnType = columnType;
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public long getColumnId() {
		return columnId;
	}

	public void setColumnId(long columnId) {
		this.columnId = columnId;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getNullAllowedFlag() {
		return nullAllowedFlag;
	}

	public void setNullAllowedFlag(String nullAllowedFlag) {
		this.nullAllowedFlag = nullAllowedFlag;
	}

	public String getColumnType() {
		return columnType;
	}

	public void setColumnType(String columnType) {
		this.columnType = columnType;
	}

}
