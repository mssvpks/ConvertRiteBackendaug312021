package com.rite.products.convertrite.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rite.products.convertrite.Validations.Validations;
import com.rite.products.convertrite.exception.BadRequestException;
import com.rite.products.convertrite.model.XxrActivities;
import com.rite.products.convertrite.model.XxrProjectWbs;
import com.rite.products.convertrite.model.XxrProjects;
import com.rite.products.convertrite.po.ActivitiesPo;
import com.rite.products.convertrite.po.ActivitiesResPo;
import com.rite.products.convertrite.po.CopyProjectRequestPo;
import com.rite.products.convertrite.po.DataResPo;
import com.rite.products.convertrite.po.ProjectWbsPo;
import com.rite.products.convertrite.po.ProjectsPo;
import com.rite.products.convertrite.po.SaveProjectHeaderResponsePo;
import com.rite.products.convertrite.po.SaveProjectHeadersPo;
import com.rite.products.convertrite.po.TaskBreakDownPo;
import com.rite.products.convertrite.po.TaskOwnerLov;
import com.rite.products.convertrite.po.XxrActivitiesResPo;
import com.rite.products.convertrite.po.XxrProjectWbsResPo;
import com.rite.products.convertrite.po.XxrProjectsResPo;
import com.rite.products.convertrite.respository.ProjectEntryDaoImpl;
import com.rite.products.convertrite.respository.SaveProjectActivitiesDaoImpl;
import com.rite.products.convertrite.respository.SaveProjectHeaderDaoImpl;
import com.rite.products.convertrite.respository.XxrActivitiesRepository;
import com.rite.products.convertrite.respository.XxrLookUpValuesRepository;
import com.rite.products.convertrite.respository.XxrProjectWbsTabRepository;
import com.rite.products.convertrite.respository.XxrProjectsRepository;
import com.rite.products.convertrite.respository.XxrRoleObjectLinksRepository;
import com.rite.products.convertrite.utils.Utils;

@Service
public class ProjectServiceImpl implements ProjectService {

	@Autowired
	ProjectEntryDaoImpl projectEntryDaoImpl;
	@Autowired
	XxrProjectWbsTabRepository xxrProjectWbsTabRepository;
	@Autowired
	XxrProjectsRepository xxrProjectsRepository;
	@Autowired
	XxrActivitiesRepository xxrActivitiesRepository;
	@Autowired
	XxrLookUpValuesRepository xxrLookUpValuesRepository;
	@Autowired
	SaveProjectHeaderDaoImpl saveProjectHeaderDaoImpl;
	@Autowired
	SaveProjectActivitiesDaoImpl saveProjectActivitiesDaoImpl;
	@Autowired
	XxrRoleObjectLinksRepository xxrRoleObjectLinksRepository;

	private static final Logger log = LoggerFactory.getLogger(ProjectServiceImpl.class);

	@Override
	public List<XxrProjectWbsResPo> loadWbs(Long projectId, Long podId, HttpServletRequest request) throws Exception {
		log.info("Start of loadWbs Method in Service ####");
		List<XxrProjectWbs> xxrProjectWbsTab = new ArrayList<>();
		List<XxrProjectWbsResPo> xxrProjectWbsResPo = new ArrayList<>();
		try {
			projectEntryDaoImpl.loadWbs(projectId, podId, request);
			xxrProjectWbsTab = xxrProjectWbsTabRepository.getByprojectId(projectId, podId);

			xxrProjectWbsTab.stream().forEach(x -> {
				XxrProjectWbsResPo projectWbsResPo = new XxrProjectWbsResPo();

				String projectName = xxrLookUpValuesRepository.getValueById(x.getProjectId());
				String objectCode = xxrLookUpValuesRepository.getValueById(x.getObjectId());
				String parentObjectCode = xxrLookUpValuesRepository.getValueById(x.getParentObjectId());
				String podName = xxrLookUpValuesRepository.getValueById(x.getPodId());

				projectWbsResPo.setPodId(x.getPodId());
				projectWbsResPo.setPodName(podName);
				projectWbsResPo.setProjectId(x.getProjectId());
				projectWbsResPo.setProjectName(projectName);
				projectWbsResPo.setObjectId(x.getObjectId());
				projectWbsResPo.setObjectCode(objectCode);
				projectWbsResPo.setParentObjectId(x.getParentObjectId());
				projectWbsResPo.setParentObjectCode(parentObjectCode);
				projectWbsResPo.setWbsId(x.getWbsId());
				projectWbsResPo.setSeq(x.getSeq());
				if (x.getStartDate() != null)
					projectWbsResPo.setStartDate(x.getStartDate());
				if (x.getEndDate() != null)
					projectWbsResPo.setEndDate(x.getEndDate());
				if (!Validations.isNullOrEmpty(x.getSelectedFlag()))
					projectWbsResPo.setSelectedFlag(x.getSelectedFlag());

				xxrProjectWbsResPo.add(projectWbsResPo);
			});

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return xxrProjectWbsResPo;
	}

	@Override
	public String loadTask(Long projectId, Long podId, HttpServletRequest request) throws Exception {
		log.info("Start of loadTask Method in Service ####");
		String result = "";
		try {
			result = projectEntryDaoImpl.loadTask(projectId, podId, request);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return result;
	}

	@Override
	public SaveProjectHeaderResponsePo saveProjectHeaders(SaveProjectHeadersPo projectHeadersPo,
			HttpServletRequest request) throws Exception {
		log.info("Start of saveProjectHeaders Method in Service ####");
		SaveProjectHeaderResponsePo saveProjectHeaderResponsePo = new SaveProjectHeaderResponsePo();
		Long projectId = null;
		String message = "";
		try {
			message = saveProjectHeaderDaoImpl.saveProjectHeader(projectHeadersPo, request);
			saveProjectHeaderResponsePo.setMessage(message);

			if (!Validations.isNullOrEmpty(projectHeadersPo.getProjectName()) && projectHeadersPo.getPodId() != null) {
				projectId = xxrProjectsRepository.getProjectId(projectHeadersPo.getProjectName(),
						projectHeadersPo.getPodId());
				saveProjectHeaderResponsePo.setProjectId(projectId);
				saveProjectHeaderResponsePo.setProjectName(projectHeadersPo.getProjectName());
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
		return saveProjectHeaderResponsePo;
	}

	@Override
	public List<XxrProjectsResPo> getAllProjectHeaders() throws Exception {
		log.info("Start of getAllProjectHeaders Method in Service ####");
		// List<XxrProjects> xxrProjectsList = new ArrayList<>();
		List<XxrProjectsResPo> xxrProjectsResPoList = new ArrayList<>();
		try {
			xxrProjectsResPoList = xxrProjectsRepository.getAllProjectHeaders();

			/*
			 * xxrProjectsList.stream().forEach(x -> { XxrProjectsResPo projectsResPo= new
			 * XxrProjectsResPo(); projectsResPo.setProjectId(x.getProjectId());
			 * projectsResPo.setAccessLevel(x.getAccessLevel());
			 * projectsResPo.setClientManager(x.getClientManager());
			 * projectsResPo.setClientProjectNumber(x.getClientProjectNumber());
			 * projectsResPo.setDescription(x.getDescription());
			 * projectsResPo.setEndDate(x.getEndDate());
			 * projectsResPo.setStartDate(x.getStartDate());
			 * 
			 * String podValue=xxrLookUpValuesRepository.getValueById(x.getPodId());
			 * 
			 * });
			 */

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return xxrProjectsResPoList;
	}

	@Override
	public List<XxrActivitiesResPo> getProjectLinesById(Long projectId, Long podId) throws Exception {
		log.info("Start of getProjectLinesById Method in Service ####");
		List<XxrActivities> xxrActivitiesList = new ArrayList<>();
		List<XxrActivitiesResPo> xxrActivitiesResPoList = new ArrayList<>();
		try {
			xxrActivitiesList = xxrActivitiesRepository.getActivityLinesById(projectId, podId);

			xxrActivitiesList.stream().forEach(x -> {
				XxrActivitiesResPo xxrActivitiesResPo = new XxrActivitiesResPo();
				String clientResource = "";
				String cloudResource = "";
				String destinationResource = "";
				String integratorResource = "";
				String legacyResource = "";
				String taskOwner = "";
				String podName = "";

				if (x.getClientResourceId() != null) {
					clientResource = xxrLookUpValuesRepository.getValueById(x.getClientResourceId());
					xxrActivitiesResPo.setClientResourceId(x.getClientResourceId());
				}
				if (x.getCloudResourceId() != null) {
					cloudResource = xxrLookUpValuesRepository.getValueById(x.getCloudResourceId());
					xxrActivitiesResPo.setCloudResourceId(x.getCloudResourceId());
				}
				if (x.getDestinationResourceId() != null) {
					destinationResource = xxrLookUpValuesRepository.getValueById(x.getDestinationResourceId());
					xxrActivitiesResPo.setDestinationResourceId(x.getDestinationResourceId());
				}
				if (x.getIntegratorResourceId() != null) {
					integratorResource = xxrLookUpValuesRepository.getValueById(x.getIntegratorResourceId());
					xxrActivitiesResPo.setIntegratorResourceId(x.getIntegratorResourceId());
				}
				if (x.getLegacyResourceId() != null) {
					legacyResource = xxrLookUpValuesRepository.getValueById(x.getLegacyResourceId());
					xxrActivitiesResPo.setLegacyResourceId(x.getLegacyResourceId());
				}

				if (x.getTaskOwnerId() != null) {
					taskOwner = xxrLookUpValuesRepository.getValueById(x.getTaskOwnerId());
					xxrActivitiesResPo.setTaskOwnerId(x.getTaskOwnerId());
				}
				if (x.getPodId() != null) {
					podName = xxrLookUpValuesRepository.getValueById(x.getPodId());
					xxrActivitiesResPo.setPodId(x.getPodId());
				}

				String objectCode = xxrLookUpValuesRepository.getValueById(x.getObjectId());
				xxrActivitiesResPo.setObjectId(x.getObjectId());
				String parentObjectCode = xxrLookUpValuesRepository.getValueById(x.getParentObjectId());
				xxrActivitiesResPo.setParentObjectId(x.getParentObjectId());

				if (!Validations.isNullOrEmpty(podName))
					xxrActivitiesResPo.setPodName(podName);
				if (!Validations.isNullOrEmpty(clientResource))
					xxrActivitiesResPo.setClientResource(clientResource);
				if (!Validations.isNullOrEmpty(cloudResource))
					xxrActivitiesResPo.setCloudResource(cloudResource);
				if (!Validations.isNullOrEmpty(destinationResource))
					xxrActivitiesResPo.setDestinationResource(destinationResource);
				if (!Validations.isNullOrEmpty(integratorResource))
					xxrActivitiesResPo.setIntegratorResource(integratorResource);
				if (!Validations.isNullOrEmpty(legacyResource))
					xxrActivitiesResPo.setLegacyResource(legacyResource);
				if (!Validations.isNullOrEmpty(taskOwner))
					xxrActivitiesResPo.setTaskOwner(taskOwner);
				if (!Validations.isNullOrEmpty(objectCode))
					xxrActivitiesResPo.setObjectCode(objectCode);
				if (!Validations.isNullOrEmpty(parentObjectCode))
					xxrActivitiesResPo.setParentObjectCode(parentObjectCode);
				if (x.getCompletePercentage() != null)
					xxrActivitiesResPo.setCompletePercentage(x.getCompletePercentage());
				if (!Validations.isNullOrEmpty(x.getCompletionFlag()))
					xxrActivitiesResPo.setCompletionFlag(x.getCompletionFlag());
				if (x.getEndDate() != null)
					xxrActivitiesResPo.setEndDate(x.getEndDate());
				if (!Validations.isNullOrEmpty(x.getPreReqTask()))
					xxrActivitiesResPo.setPreReqTask(x.getPreReqTask());
				xxrActivitiesResPo.setSeq(x.getSeq());
				if (x.getStartDate() != null)
					xxrActivitiesResPo.setStartDate(x.getStartDate());
				if (x.getTaskId() != null)
					xxrActivitiesResPo.setTaskId(x.getTaskId());
				if (!Validations.isNullOrEmpty(x.getTaskName()))
					xxrActivitiesResPo.setTaskName(x.getTaskName());
				if (!Validations.isNullOrEmpty(x.getTaskNum()))
					xxrActivitiesResPo.setTaskNum(x.getTaskNum());
				if (!Validations.isNullOrEmpty(x.getTaskStatus()))
					xxrActivitiesResPo.setTaskStatus(x.getTaskStatus());
				if (!Validations.isNullOrEmpty(x.getTaskType()))
					xxrActivitiesResPo.setTaskType(x.getTaskType());
				if (x.getWeightage() != null)
					xxrActivitiesResPo.setWeightage(x.getWeightage());
				xxrActivitiesResPo.setWbsId(x.getWbsId());
				xxrActivitiesResPo.setProjectId(x.getProjectId());

				xxrActivitiesResPoList.add(xxrActivitiesResPo);
			});

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return xxrActivitiesResPoList;
	}

	@Override
	public List<String> getPreRequisiteTaskLov(Long projectId, String taskNumber, Long objectId, Long podId)
			throws Exception {
		log.info("Start of getPreRequisiteTaskLov Method in Service ####");
		List<String> preRequisiteTaskList = new ArrayList<>();
		try {
			xxrActivitiesRepository.getActivityLinesById(projectId, podId).stream().forEach(x -> {
				if (!x.getTaskNum().equals(taskNumber) && x.getObjectId() == objectId)
					preRequisiteTaskList.add(x.getTaskNum());
			});
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return preRequisiteTaskList;
	}

	@Override
	public DataResPo updateProjectWbsSelections(List<ProjectWbsPo> projectWbsPo) throws Exception {
		log.info("Start of updateProjectWbsSelections Method in Service ####");
		List<XxrProjectWbs> xxrProjectWbsTab = new ArrayList<>();
		XxrProjectWbs projectWbsTab = new XxrProjectWbs();
		// String result = "";
		DataResPo dataResPo = new DataResPo();
		try {
			xxrProjectWbsTab = xxrProjectWbsTabRepository.getByprojectId(projectWbsPo.get(0).getProjectId(),
					projectWbsPo.get(0).getPodId());
			for (ProjectWbsPo projectWbs : projectWbsPo) {
				projectWbsTab = xxrProjectWbsTab.stream()
						.filter(x -> x.getObjectId() == projectWbs.getObjectId()
								&& x.getProjectId() == projectWbs.getProjectId()
								&& x.getParentObjectId() == projectWbs.getParentObjectId())
						.findFirst().get();
				projectWbsTab.setSelectedFlag(projectWbs.getSelectedFlag());
				xxrProjectWbsTabRepository.save(projectWbsTab);
			}
			dataResPo.setMessage("WBS Saved Successfully");
		} catch (Exception e) {
			dataResPo.setError("Something went wrong");
			throw new Exception(e.getMessage());
		}
		return dataResPo;
	}

	@Override
	public ActivitiesResPo upsertProjectActivities(List<ActivitiesPo> activitiesPo, HttpServletRequest request)
			throws BadRequestException, Exception {
		log.info("Start of upsertProjectActivities Method in Service ####");

		List<XxrActivities> xxrActivitiesResp = new ArrayList<>();
		ActivitiesResPo activitiesResPo = new ActivitiesResPo();
		String msg = "";
		try {
			msg = saveProjectActivitiesDaoImpl.saveProjectActivities(activitiesPo, request);
			activitiesResPo.setMessage(msg);
			xxrActivitiesResp = xxrActivitiesRepository.getActivityLinesById(activitiesPo.get(0).getProjectId(),
					activitiesPo.get(0).getPodId());
			activitiesResPo.setXxrActivities(xxrActivitiesResp);
		} catch (BadRequestException e) {
			e.printStackTrace();
			throw new BadRequestException(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
		return activitiesResPo;
	}

	@Override
	public List<TaskBreakDownPo> getTaskBreakDown(Long projectId, Long podId) throws Exception {
		log.info("Start of getTaskBreakDown Method in Service ###");
		List<TaskBreakDownPo> taskBreakDownList = new ArrayList<>();
		try {
			taskBreakDownList = xxrLookUpValuesRepository.getTaskBreakDown(projectId, podId);

			/*
			 * taskBreakDownList.stream().forEach(x->{
			 * if(!Validations.isNullOrEmpty(x.getPreReqTask())) {
			 * 
			 * x.setPredecessor(xxrActivitiesRepository.getTaskIdByPreReqTask(x.
			 * getPreReqTask(),projectId)); } });
			 */

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return taskBreakDownList;
	}

	@Override
	public SaveProjectHeaderResponsePo copyProject(CopyProjectRequestPo copyProjectRequest, HttpServletRequest request)
			throws Exception {
		// TODO Auto-generated method stub
		log.info("Start of copyProject Method in Service ###");
		SaveProjectHeadersPo projectHeadersPo = new SaveProjectHeadersPo();
		SaveProjectHeaderResponsePo saveProjectHeaderResponsePo = new SaveProjectHeaderResponsePo();
		String message = "";
		try {

			XxrProjects xxrProjects = xxrProjectsRepository.getProject(copyProjectRequest.getProjectName(),
					copyProjectRequest.getOldPodId());

			projectHeadersPo.setProjectName(xxrProjects.getProjectName());
			projectHeadersPo.setProjectStatus(copyProjectRequest.getProjectStatus());
			projectHeadersPo.setStartDate(copyProjectRequest.getStartDate());
			projectHeadersPo.setCompletionDate(copyProjectRequest.getCompletionDate());
			projectHeadersPo.setPodId(copyProjectRequest.getNewPodId());
			projectHeadersPo.setAccessLevel(xxrProjects.getAccessLevel());
			projectHeadersPo.setClientManager(xxrProjects.getClientManager());
			projectHeadersPo.setClientProjectNum(xxrProjects.getClientProjectNumber());
			projectHeadersPo.setDescription(xxrProjects.getDescription());
			projectHeadersPo.setKpiAggregationLevel(xxrProjects.getKpiAggLevel());
			projectHeadersPo.setProgramNumber(xxrProjects.getProgramNumber());
			projectHeadersPo.setProjectManager(xxrProjects.getProjecManager());

			// save project header
			message = saveProjectHeaderDaoImpl.saveProjectHeader(projectHeadersPo, request);
			log.info(message);
			Long projectId = null;
			if (!Validations.isNullOrEmpty(copyProjectRequest.getProjectName())
					&& copyProjectRequest.getNewPodId() != null)
				projectId = xxrProjectsRepository.getProjectId(copyProjectRequest.getProjectName(),
						copyProjectRequest.getNewPodId());
			if (projectId == null)
				throw new Exception(
						"Please contact System Administrator there is an error while processing the request");
			else {
				// copy project wbs
				copyProjectWbs(projectId, copyProjectRequest);
				// copy project activity lines
				copyProjectActivities(projectId, copyProjectRequest, request);
				saveProjectHeaderResponsePo.setProjectId(projectId);
				saveProjectHeaderResponsePo.setProjectName(copyProjectRequest.getProjectName());
				saveProjectHeaderResponsePo.setMessage("Successfully copied project");
			}

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return saveProjectHeaderResponsePo;
	}

	private void copyProjectWbs(Long projectId, CopyProjectRequestPo copyProjectRequest) throws Exception {
		log.info("copyProjectWbs######");
		try {
			List<XxrProjectWbs> projectWbsList = xxrProjectWbsTabRepository.getByprojectId(projectId,
					copyProjectRequest.getOldPodId());
			for (XxrProjectWbs xxrProjectWbsOld : projectWbsList) {

				XxrProjectWbs xxrProjectWbsNew = new XxrProjectWbs();

				xxrProjectWbsNew.setProjectId(projectId);
				xxrProjectWbsNew.setPodId(copyProjectRequest.getNewPodId());
				xxrProjectWbsNew.setEndDate(xxrProjectWbsOld.getEndDate());
				xxrProjectWbsNew.setStartDate(xxrProjectWbsOld.getStartDate());
				xxrProjectWbsNew.setObjectId(xxrProjectWbsOld.getObjectId());
				xxrProjectWbsNew.setParentObjectId(xxrProjectWbsOld.getParentObjectId());
				xxrProjectWbsNew.setSelectedFlag(xxrProjectWbsOld.getSelectedFlag());
				xxrProjectWbsNew.setSeq(xxrProjectWbsOld.getSeq());
				xxrProjectWbsNew.setWbsId(xxrProjectWbsOld.getWbsId());

				xxrProjectWbsTabRepository.save(xxrProjectWbsNew);
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	private void copyProjectActivities(Long projectId, CopyProjectRequestPo copyProjectRequest,
			HttpServletRequest request) throws Exception {
		String msg = "";
		List<ActivitiesPo> activitiesPo = new ArrayList<>();
		try {
			List<XxrActivities> activityLines = xxrActivitiesRepository.getActivityLinesById(projectId,
					copyProjectRequest.getOldPodId());

			for (XxrActivities xxrActivitiesOld : activityLines) {
				ActivitiesPo activitiesPoReq = new ActivitiesPo();
				activitiesPoReq.setWeightage(xxrActivitiesOld.getWeightage());
				activitiesPoReq.setWbsId(xxrActivitiesOld.getWbsId());
				activitiesPoReq.setClientResourceId(xxrActivitiesOld.getClientResourceId());
				activitiesPoReq.setCloudResourceId(xxrActivitiesOld.getCloudResourceId());
				activitiesPoReq.setCompletePercentage(xxrActivitiesOld.getCompletePercentage());
				activitiesPoReq.setCompletionFlag(xxrActivitiesOld.getCompletionFlag());
				activitiesPoReq.setDestinationResourceId(xxrActivitiesOld.getDestinationResourceId());
				activitiesPoReq.setEndDate(xxrActivitiesOld.getEndDate());
				activitiesPoReq.setStartDate(xxrActivitiesOld.getStartDate());
				activitiesPoReq.setSeq(xxrActivitiesOld.getSeq());
				activitiesPoReq.setTaskId(xxrActivitiesOld.getTaskId());
				activitiesPoReq.setTaskName(xxrActivitiesOld.getTaskName());
				activitiesPoReq.setTaskNum(xxrActivitiesOld.getTaskNum());
				activitiesPoReq.setTaskOwnerId(xxrActivitiesOld.getTaskOwnerId());
				activitiesPoReq.setTaskStatus(xxrActivitiesOld.getTaskStatus());
				activitiesPoReq.setTaskType(xxrActivitiesOld.getTaskType());
				activitiesPoReq.setPreReqTask(xxrActivitiesOld.getPreReqTask());
				activitiesPoReq.setIntegratorResourceId(xxrActivitiesOld.getIntegratorResourceId());
				activitiesPoReq.setLegacyResourceId(xxrActivitiesOld.getLegacyResourceId());
				activitiesPoReq.setObjectId(xxrActivitiesOld.getObjectId());
				activitiesPoReq.setParentObjectId(xxrActivitiesOld.getParentObjectId());
				activitiesPoReq.setProjectId(projectId);
				activitiesPoReq.setPodId(copyProjectRequest.getNewPodId());

				activitiesPo.add(activitiesPoReq);

			}

			msg = saveProjectActivitiesDaoImpl.saveProjectActivities(activitiesPo, request);
			log.info(msg);

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	@Override
	public List<TaskOwnerLov> getTaskOwnerLov(Long projectId) throws Exception {
		// TODO Auto-generated method stub
		log.info("Start of getTaskOwnerLov#######");
		List<TaskOwnerLov> taskOwnerLi = new ArrayList<>();
		try {
			taskOwnerLi = xxrRoleObjectLinksRepository.getTaskOwnerLov(projectId);
			taskOwnerLi=taskOwnerLi.stream().filter(Utils.distinctByKey(TaskOwnerLov::getTaskOwnerId)).collect(Collectors.toList());
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return taskOwnerLi;
	}

}
