package com.rite.products.convertrite.respository;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;
import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.rite.products.convertrite.model.SourceTemplateHeaders;
import com.rite.products.convertrite.po.SourceStagingTablePo;

@Repository
public class CreateSourceStagTableDaoImpl {

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	SourceTemplateHeadersRepository sourceTemplateHeadersRepository;

	private static final Logger log = LoggerFactory.getLogger(CreateSourceStagTableDaoImpl.class);

	@Transactional
	public SourceStagingTablePo createStaggingTable(String tableName, long templateId, long podId,HttpServletRequest request) {
		log.info("Start of createStaggingTable Method in DaoImpl### ");
		SourceStagingTablePo stagingPo = new SourceStagingTablePo();
		/* EntityManager entityManager = em.createEntityManager(); */

		StoredProcedureQuery createStaggingStoredProcedure = entityManager
				.createStoredProcedureQuery("XXR_SOURCE_PKG.XXR_CREATE_STG_TAB_PRC")
				.registerStoredProcedureParameter("p_pod", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("p_table_name", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("p_template_id", Long.class, ParameterMode.IN)
				.registerStoredProcedureParameter("p_user_id", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("p_result", String.class, ParameterMode.OUT)
				.registerStoredProcedureParameter("p_table_name_out", String.class, ParameterMode.OUT)
				.setParameter("p_pod", Long.toString(podId)).setParameter("p_table_name", tableName)
				.setParameter("p_template_id", templateId).setParameter("p_user_id", request.getHeader("userId"));

		createStaggingStoredProcedure.execute();
		stagingPo.setResult((String) createStaggingStoredProcedure.getOutputParameterValue("p_result"));
		stagingPo.setTableName((String) createStaggingStoredProcedure.getOutputParameterValue("p_table_name_out"));
		entityManager.clear();
		entityManager.close();

		if (stagingPo != null && !(stagingPo.getResult().isBlank()) && stagingPo.getResult().equalsIgnoreCase("Y")) {
			SourceTemplateHeaders tempHeader = sourceTemplateHeadersRepository.findAll().stream()
					.filter(x -> x.getTemplateId() == templateId).findFirst().get();
			tempHeader.setStagingTableName(stagingPo.getTableName().split(":")[1]);
			sourceTemplateHeadersRepository.save(tempHeader);
		}

		return stagingPo;
	}
}
