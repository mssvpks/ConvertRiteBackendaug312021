package com.rite.products.convertrite.service;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.rite.products.convertrite.model.XxrCloudDataProcess;
import com.rite.products.convertrite.po.CloudDataProcessingReqPo;

public interface CloudDataProcessingService {

	XxrCloudDataProcess cloudDataProcessingRequests(CloudDataProcessingReqPo cloudDataProcessingReqPo) throws Exception;

	List<XxrCloudDataProcess> getAllCloudDataRequests()throws Exception;

	void downloadCsvFile(String requestId, HttpServletResponse response) throws Exception;

}
