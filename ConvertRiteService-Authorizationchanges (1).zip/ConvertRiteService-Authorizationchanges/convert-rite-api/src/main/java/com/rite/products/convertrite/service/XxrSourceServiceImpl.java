package com.rite.products.convertrite.service;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rite.products.convertrite.Validations.Validations;
import com.rite.products.convertrite.exception.BadRequestException;
import com.rite.products.convertrite.exception.ValidationException;
import com.rite.products.convertrite.model.SourceTemplateColumns;
import com.rite.products.convertrite.model.SourceTemplateHeaders;
import com.rite.products.convertrite.po.ColumnPo;
import com.rite.products.convertrite.po.CreateDynamicViewPo;
import com.rite.products.convertrite.po.SaveSourceTemplateColumnsResPo;
import com.rite.products.convertrite.po.SaveSourceTemplateHeadersPo;
import com.rite.products.convertrite.po.SaveSourceTemplatesColumnsPo;
import com.rite.products.convertrite.po.SaveTemplateHeaderResponsePo;
import com.rite.products.convertrite.po.SourceStagingTablePo;
import com.rite.products.convertrite.po.SourceTablesPo;
import com.rite.products.convertrite.po.SourceTemplateColumnsResPo;
import com.rite.products.convertrite.po.SourceTemplateHeadersResPo;
import com.rite.products.convertrite.po.SourceTemplatePo;
import com.rite.products.convertrite.respository.CreateSourceDynamicViewDaoImpl;
import com.rite.products.convertrite.respository.CreateSourceStagTableDaoImpl;
import com.rite.products.convertrite.respository.SaveSourceTemplateColumnsDaoImpl;
import com.rite.products.convertrite.respository.SaveSourceTemplateHeaderDaoImpl;
import com.rite.products.convertrite.respository.SourceTemplateColumnsRepository;
import com.rite.products.convertrite.respository.SourceTemplateHeadersDaoImpl;
import com.rite.products.convertrite.respository.SourceTemplateHeadersRepository;
import com.rite.products.convertrite.respository.XxrLookUpValuesRepository;
import com.rite.products.convertrite.respository.XxrMappingSetsRepository;
import com.rite.products.convertrite.respository.XxrSourceColumnsRepository;
import com.rite.products.convertrite.respository.XxrSourceTablesRepository;

@Service
public class XxrSourceServiceImpl implements XxrSourceService {
	private static final Logger log = LoggerFactory.getLogger(XxrSourceServiceImpl.class);

	@Autowired
	SourceTemplateHeadersRepository sourceTemplateHeadersRepository;
	@Autowired
	SourceTemplateColumnsRepository sourceTemplateColumnsRepository;
	@Autowired
	SourceTemplateHeadersDaoImpl sourceTemplateHeadersDaoImpl;
	@Autowired
	XxrSourceTablesRepository xxrSourceTablesRepository;
	@Autowired
	XxrSourceColumnsRepository xxrSourceColumnsRepository;
	@Autowired
	SaveSourceTemplateHeaderDaoImpl saveSourceTemplateHeaderDaoImpl;
	@Autowired
	SaveSourceTemplateColumnsDaoImpl saveSourceTemplateColumnsDaoImpl;
	@Autowired
	CreateSourceStagTableDaoImpl createSourceStagTableDaoImpl;
	@Autowired
	CreateSourceDynamicViewDaoImpl createSourceDynamicViewDaoImpl;
	@Autowired
	XxrLookUpValuesRepository xxrLookUpValuesRepository;
	@Autowired
	XxrMappingSetsRepository xxrColumnMapHdrRepository;

	public List<SourceTemplateHeadersResPo> getSourceTemplates() throws Exception {
		log.info("Start Of getSourceTemplates Method in Service Layer ####");
		List<SourceTemplateHeaders> sourceTemplateHeaders = new ArrayList<>();
		List<SourceTemplateHeadersResPo> sourceTemplateHeaderRes = new ArrayList<>();
		try {

			sourceTemplateHeaders = sourceTemplateHeadersRepository.findAll();

			sourceTemplateHeaders.stream().forEach(x -> {
				SourceTemplateHeadersResPo sourceTemplateHeadersResPo = new SourceTemplateHeadersResPo();
				String metaDataTableName = "";

				String podName = xxrLookUpValuesRepository.getValueById(x.getPodId());
				String projectName = xxrLookUpValuesRepository.getValueById(x.getProjectId());
				String objectCode = xxrLookUpValuesRepository.getValueById(x.getObjectId());
				String parentObjectCode = xxrLookUpValuesRepository.getValueById(x.getParentObjectId());
				if (x.getMetaDataTableId() != null) {
					metaDataTableName = xxrSourceTablesRepository.getMetaDataTableName(x.getMetaDataTableId());
					sourceTemplateHeadersResPo.setMetaDataTableId(x.getMetaDataTableId());
				}
				sourceTemplateHeadersResPo.setTemplateId(x.getTemplateId());
				sourceTemplateHeadersResPo.setTemplateName(x.getTemplateName());
				sourceTemplateHeadersResPo.setPodId(x.getPodId());
				sourceTemplateHeadersResPo.setPodName(podName);
				sourceTemplateHeadersResPo.setProjectId(x.getProjectId());
				sourceTemplateHeadersResPo.setProjectName(projectName);
				sourceTemplateHeadersResPo.setParentObjectId(x.getParentObjectId());
				sourceTemplateHeadersResPo.setParentObjectCode(parentObjectCode);
				sourceTemplateHeadersResPo.setObjectId(x.getObjectId());
				sourceTemplateHeadersResPo.setObjectCode(objectCode);
				if (!Validations.isNullOrEmpty(metaDataTableName))
					sourceTemplateHeadersResPo.setMetaDataTableName(metaDataTableName);
				if (!Validations.isNullOrEmpty(x.getStagingTableName()))
					sourceTemplateHeadersResPo.setStagingTableName(x.getStagingTableName());
				if (!Validations.isNullOrEmpty(x.getViewName()))
					sourceTemplateHeadersResPo.setViewName(x.getViewName());
				if (!Validations.isNullOrEmpty(x.getBu()))
					sourceTemplateHeadersResPo.setBu(x.getBu());
				if (!Validations.isNullOrEmpty(x.getBuSpecific()))
					sourceTemplateHeadersResPo.setBuSpecific(x.getBuSpecific());
				if (!Validations.isNullOrEmpty(x.getAttribute1()))
					sourceTemplateHeadersResPo.setAttribute1(x.getAttribute1());
				if (!Validations.isNullOrEmpty(x.getAttribute2()))
					sourceTemplateHeadersResPo.setAttribute2(x.getAttribute2());
				if (!Validations.isNullOrEmpty(x.getAttribute3()))
					sourceTemplateHeadersResPo.setAttribute3(x.getAttribute3());
				if (!Validations.isNullOrEmpty(x.getAttribute4()))
					sourceTemplateHeadersResPo.setAttribute4(x.getAttribute4());
				if (!Validations.isNullOrEmpty(x.getAttribute5()))
					sourceTemplateHeadersResPo.setAttribute5(x.getAttribute5());

				sourceTemplateHeaderRes.add(sourceTemplateHeadersResPo);
			});

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return sourceTemplateHeaderRes;
	}

	public List<SourceTemplateHeadersResPo> getSourceTemplateHeaderById(long templateId) throws Exception {

		log.info("Start Of getSourceTemplateHeaderById Method  in Service Layer ####");
		List<SourceTemplateHeaders> sourceTemplateHeaders = new ArrayList<>();
		List<SourceTemplateHeadersResPo> sourceTemplateHeaderRes = new ArrayList<>();
		try {

			sourceTemplateHeaders = sourceTemplateHeadersRepository.findByTemplateId(templateId);

			sourceTemplateHeaders.stream().forEach(x -> {
				SourceTemplateHeadersResPo sourceTemplateHeadersResPo = new SourceTemplateHeadersResPo();
				String metaDataTableName = "";

				String podName = xxrLookUpValuesRepository.getValueById(x.getPodId());
				String projectName = xxrLookUpValuesRepository.getValueById(x.getProjectId());
				String objectCode = xxrLookUpValuesRepository.getValueById(x.getObjectId());
				String parentObjectCode = xxrLookUpValuesRepository.getValueById(x.getParentObjectId());
				if (x.getMetaDataTableId() != null) {
					metaDataTableName = xxrSourceTablesRepository.getMetaDataTableName(x.getMetaDataTableId());
					sourceTemplateHeadersResPo.setMetaDataTableId(x.getMetaDataTableId());
				}
				sourceTemplateHeadersResPo.setTemplateId(x.getTemplateId());
				sourceTemplateHeadersResPo.setTemplateName(x.getTemplateName());
				sourceTemplateHeadersResPo.setPodId(x.getPodId());
				sourceTemplateHeadersResPo.setPodName(podName);
				sourceTemplateHeadersResPo.setProjectId(x.getProjectId());
				sourceTemplateHeadersResPo.setProjectName(projectName);
				sourceTemplateHeadersResPo.setParentObjectId(x.getParentObjectId());
				sourceTemplateHeadersResPo.setParentObjectCode(parentObjectCode);
				sourceTemplateHeadersResPo.setObjectId(x.getObjectId());
				sourceTemplateHeadersResPo.setObjectCode(objectCode);
				if (!Validations.isNullOrEmpty(metaDataTableName))
					sourceTemplateHeadersResPo.setMetaDataTableName(metaDataTableName);
				if (!Validations.isNullOrEmpty(x.getStagingTableName()))
					sourceTemplateHeadersResPo.setStagingTableName(x.getStagingTableName());
				if (!Validations.isNullOrEmpty(x.getViewName()))
					sourceTemplateHeadersResPo.setViewName(x.getViewName());
				if (!Validations.isNullOrEmpty(x.getBu()))
					sourceTemplateHeadersResPo.setBu(x.getBu());
				if (!Validations.isNullOrEmpty(x.getBuSpecific()))
					sourceTemplateHeadersResPo.setBuSpecific(x.getBuSpecific());
				if (!Validations.isNullOrEmpty(x.getAttribute1()))
					sourceTemplateHeadersResPo.setAttribute1(x.getAttribute1());
				if (!Validations.isNullOrEmpty(x.getAttribute2()))
					sourceTemplateHeadersResPo.setAttribute2(x.getAttribute2());
				if (!Validations.isNullOrEmpty(x.getAttribute3()))
					sourceTemplateHeadersResPo.setAttribute3(x.getAttribute3());
				if (!Validations.isNullOrEmpty(x.getAttribute4()))
					sourceTemplateHeadersResPo.setAttribute4(x.getAttribute4());
				if (!Validations.isNullOrEmpty(x.getAttribute5()))
					sourceTemplateHeadersResPo.setAttribute5(x.getAttribute5());

				sourceTemplateHeaderRes.add(sourceTemplateHeadersResPo);
			});

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return sourceTemplateHeaderRes;

	}

	public List<SourceTemplateHeaders> getSourceTemplatesByPo(SourceTemplatePo sourceTemplatePo) throws Exception {
		log.info("Start Of getSourceTemplatesByPo Method  in Service Layer ####");

		List<SourceTemplateHeaders> sourceTemplateHeaders = new ArrayList<>();
		try {
			sourceTemplateHeaders = sourceTemplateHeadersDaoImpl.getSourceTemplatesByPo(sourceTemplatePo);

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return sourceTemplateHeaders;
	}

	public List<SourceTemplateColumnsResPo> getSourceTemplateColumns(long templateId) throws Exception {

		log.info("Start Of getSourceTemplateColumns Method  in Service Layer ####");
		List<SourceTemplateColumns> sourceTemplateColumns = new ArrayList<>();
		List<SourceTemplateColumnsResPo> sourceTemplateColumnsRes = new ArrayList<>();
		try {

			sourceTemplateColumns = sourceTemplateColumnsRepository.findByTemplateId(templateId);

			sourceTemplateColumns.stream().forEach(x -> {
				String mappingSetName = "";
				SourceTemplateColumnsResPo sourceTemplateColumnsResPo = new SourceTemplateColumnsResPo();

				if (x.getMappingSetId() != null) {
					mappingSetName = xxrColumnMapHdrRepository.getMappingSetNameById(x.getMappingSetId());
					sourceTemplateColumnsResPo.setMappingSetId(x.getMappingSetId());
				}

				sourceTemplateColumnsResPo.setColumnId(x.getColumnId());
				sourceTemplateColumnsResPo.setColumnName(x.getColumnName());
				sourceTemplateColumnsResPo.setTemplateId(x.getTemplateId());
				if (!Validations.isNullOrEmpty(mappingSetName))
					sourceTemplateColumnsResPo.setMappingSetName(mappingSetName);
				if (!Validations.isNullOrEmpty(x.getEnabledFlag()))
					sourceTemplateColumnsResPo.setEnabledFlag(x.getEnabledFlag());
				if (!Validations.isNullOrEmpty(x.getMappingType()))
					sourceTemplateColumnsResPo.setMappingType(x.getMappingType());
				if (!Validations.isNullOrEmpty(x.getMappingValue()))
					sourceTemplateColumnsResPo.setMappingValue(x.getMappingValue());
				if (!Validations.isNullOrEmpty(x.getOrigTransRef()))
					sourceTemplateColumnsResPo.setOrigTransRef(x.getOrigTransRef());
				if (!Validations.isNullOrEmpty(x.getSelected()))
					sourceTemplateColumnsResPo.setSelected(x.getSelected());
				if (x.getStartDate() != null)
					sourceTemplateColumnsResPo.setStartDate(x.getStartDate());
				if (x.getEndDate() != null)
					sourceTemplateColumnsResPo.setEndDate(x.getEndDate());
				if (x.getSeq() != null)
					sourceTemplateColumnsResPo.setSeq(x.getSeq());
				if (!Validations.isNullOrEmpty(x.getAttribute1()))
					sourceTemplateColumnsResPo.setAttribute1(x.getAttribute1());
				if (!Validations.isNullOrEmpty(x.getAttribute2()))
					sourceTemplateColumnsResPo.setAttribute2(x.getAttribute2());
				if (!Validations.isNullOrEmpty(x.getAttribute3()))
					sourceTemplateColumnsResPo.setAttribute3(x.getAttribute3());
				if (!Validations.isNullOrEmpty(x.getAttribute4()))
					sourceTemplateColumnsResPo.setAttribute4(x.getAttribute4());
				if (!Validations.isNullOrEmpty(x.getAttribute5()))
					sourceTemplateColumnsResPo.setAttribute5(x.getAttribute5());
				if (!Validations.isNullOrEmpty(x.getColumnType()))
					sourceTemplateColumnsResPo.setColumnType(x.getColumnType());
				if (!Validations.isNullOrEmpty(x.getNullAllowedFlag()))
					sourceTemplateColumnsResPo.setNullAllowedFlag(x.getNullAllowedFlag());
				if (x.getWidth() != null)
					sourceTemplateColumnsResPo.setWidth(x.getWidth());

				sourceTemplateColumnsRes.add(sourceTemplateColumnsResPo);
			});

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return sourceTemplateColumnsRes;
	}

	public List<ColumnPo> getSourceColumnsByName(String sourceTableName) throws Exception {
		log.info("Start Of getSourceColumnsByName Method  in Service Layer ####");
		List<ColumnPo> sourceTemplateColumns = new ArrayList<>();

		try {
			Long tableId = xxrSourceTablesRepository.getTableId(sourceTableName);
			log.info("tableId::::::::" + tableId);

			if (tableId != null)
				sourceTemplateColumns = xxrSourceColumnsRepository.getSourceColumnsById(tableId);

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return sourceTemplateColumns;
	}

	public List<ColumnPo> getSourceColumnsById(long sourceTableId) throws Exception {
		log.info("Start Of getSourceColumnsById Method  in Service Layer ####");
		List<ColumnPo> sourceTemplateColumns = new ArrayList<>();

		try {
			sourceTemplateColumns = xxrSourceColumnsRepository.getSourceColumnsById(sourceTableId);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return sourceTemplateColumns;
	}

	public SaveTemplateHeaderResponsePo saveSourceTemplateHeaders(
			List<SaveSourceTemplateHeadersPo> sourceTemplateHeadersPo,HttpServletRequest request) throws ValidationException,Exception {
		log.info("Start of saveSourceTemplateHeaders in Service Layer ###");
		String msg = "";
		long templateId = 0;
		SaveTemplateHeaderResponsePo saveTemplateHeaderResponsePo = new SaveTemplateHeaderResponsePo();
		try {
			msg = saveSourceTemplateHeaderDaoImpl.saveSourceTemplateHeaders(sourceTemplateHeadersPo,request);
			saveTemplateHeaderResponsePo.setMessage(msg);
			SaveSourceTemplateHeadersPo saveSourceTemplateHeadersPo = sourceTemplateHeadersPo.get(0);
			String templateName = saveSourceTemplateHeadersPo.getTemplateName();
			if (!Validations.isNullOrEmpty(templateName)) {
				templateId = sourceTemplateHeadersRepository.getTemplateId(templateName);
				saveTemplateHeaderResponsePo.setTemplateId(templateId);
				saveTemplateHeaderResponsePo.setTemplateName(templateName);
			}
			log.info(msg + "msg###########");
		} catch (ValidationException e) {
			throw new ValidationException(e.getMessage());
		}catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return saveTemplateHeaderResponsePo;
	}

	public SaveSourceTemplateColumnsResPo saveSourceTemplateColumns(
			List<SaveSourceTemplatesColumnsPo> sourceTemplateColumnsPo,HttpServletRequest request) throws BadRequestException,Exception {
		log.info("Start of saveSourceTemplateColumns in Service Layer ###");
		String msg = "";
		List<SourceTemplateColumns> sourceTemplateColumns = new ArrayList<>();
		SaveSourceTemplateColumnsResPo saveSourceTemplateColumnsResPo = new SaveSourceTemplateColumnsResPo();
		try {
			msg = saveSourceTemplateColumnsDaoImpl.saveSourceTemplateColumns(sourceTemplateColumnsPo,request);
			saveSourceTemplateColumnsResPo.setMessage(msg);
			Long templateId = sourceTemplateColumnsPo.get(0).getTemplateId();
			if (templateId != null) {
				sourceTemplateColumns = sourceTemplateColumnsRepository.findByTemplateId(templateId);
				saveSourceTemplateColumnsResPo.setSourceTemplateColumns(sourceTemplateColumns);
			}
			log.info(msg + "msg###########");
		}catch (BadRequestException e) {
			throw new BadRequestException(e.getMessage());
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return saveSourceTemplateColumnsResPo;

	}

	public SourceStagingTablePo createSourceStaggingTab(String tableName, long templateId, long podId,HttpServletRequest request)
			throws Exception {

		log.info("Start Of createSourceStaggingTab Method in Service Layer ####");
		SourceStagingTablePo stagingPo = new SourceStagingTablePo();
		try {
			stagingPo = createSourceStagTableDaoImpl.createStaggingTable(tableName, templateId, podId,request);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return stagingPo;

	}

	public CreateDynamicViewPo createDynamicView(Long templateId, String stgTableName,HttpServletRequest request) throws Exception {
		log.info("Start Of createDynamicView Method in Service Layer ####");
		CreateDynamicViewPo createDynamicViewPo = new CreateDynamicViewPo();
		try {
			createDynamicViewPo = createSourceDynamicViewDaoImpl.createDynamicView(templateId, stgTableName,request);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return createDynamicViewPo;

	}

	@Override
	public List<SourceTablesPo> getSourceTableNames(Long objectId) throws Exception {
		log.info("Start Of getSourceTableNames Method in Service Layer ####");
		List<SourceTablesPo> sourceTableNames = new ArrayList<>();
		try {

			sourceTableNames = xxrSourceTablesRepository.getTableIdNames(objectId);

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return sourceTableNames;

	}

	@Override
	public SaveTemplateHeaderResponsePo copySourceTemplate(String newTemplateName, Long templateId, Long podId,HttpServletRequest request)
			throws Exception {
		log.info("Start Of copySourceTemplate Method in Service Layer ####");
		List<SaveSourceTemplatesColumnsPo> sourceTemplateColumnsPo = new ArrayList<>();
		List<SaveSourceTemplateHeadersPo> sourceTemplateHeadersPo = new ArrayList<>();
		SaveSourceTemplateHeadersPo saveSourceTemplateHeadersPo = new SaveSourceTemplateHeadersPo();
		SaveTemplateHeaderResponsePo saveTemplateHeaderResponsePo = new SaveTemplateHeaderResponsePo();
		String msg = "";
		Long newTemplateId = null;
		String metaDataTableName = "";
		SourceStagingTablePo stagingPo = new SourceStagingTablePo();
		CreateDynamicViewPo createDynamicViewPo = new CreateDynamicViewPo();
		List<SourceTemplateColumns> sourceTemplateColumns = new ArrayList<>();
		try {

			SourceTemplateHeaders tempHeader = sourceTemplateHeadersRepository.findAll().stream()
					.filter(x -> x.getTemplateId() == templateId).findFirst().get();

			saveSourceTemplateHeadersPo.setTemplateName(newTemplateName);
			saveSourceTemplateHeadersPo.setBu(tempHeader.getBu());
			saveSourceTemplateHeadersPo.setBuSpecific(tempHeader.getBuSpecific());
			saveSourceTemplateHeadersPo.setMetaDataTableId(tempHeader.getMetaDataTableId());
			saveSourceTemplateHeadersPo.setObjectId(tempHeader.getObjectId());
			saveSourceTemplateHeadersPo.setParentObjectId(tempHeader.getParentObjectId());
			saveSourceTemplateHeadersPo.setPodId(podId);
			saveSourceTemplateHeadersPo.setProjectId(tempHeader.getProjectId());

			sourceTemplateHeadersPo.add(saveSourceTemplateHeadersPo);

			msg = saveSourceTemplateHeaderDaoImpl.saveSourceTemplateHeaders(sourceTemplateHeadersPo,request);
			log.info("Source :::: " + msg);

			if (!Validations.isNullOrEmpty(newTemplateName))
				newTemplateId = sourceTemplateHeadersRepository.getTemplateId(newTemplateName);

			if (newTemplateId != null) {
				final long nTemplateId = newTemplateId;
				SourceTemplateHeaders srctempHeader = sourceTemplateHeadersRepository.findAll().stream()
						.filter(x -> x.getTemplateId() == nTemplateId).findFirst().get();

				log.info("tableId:::::::" + srctempHeader.getMetaDataTableId());
					
				sourceTemplateColumns = sourceTemplateColumnsRepository.findByTemplateId(templateId);

				for (SourceTemplateColumns sourceTemplateColumn : sourceTemplateColumns) {

					SaveSourceTemplatesColumnsPo saveSourceTemplatesColumnsPo = new SaveSourceTemplatesColumnsPo();

					saveSourceTemplatesColumnsPo.setColumnName(sourceTemplateColumn.getColumnName());
					saveSourceTemplatesColumnsPo.setDisplaySeq(sourceTemplateColumn.getSeq());
					saveSourceTemplatesColumnsPo.setEnableFlag(sourceTemplateColumn.getEnabledFlag());
					saveSourceTemplatesColumnsPo.setStartDate(sourceTemplateColumn.getStartDate());
					saveSourceTemplatesColumnsPo.setEndDate(sourceTemplateColumn.getEndDate());
					saveSourceTemplatesColumnsPo.setMappingSetId(sourceTemplateColumn.getMappingSetId());
					saveSourceTemplatesColumnsPo.setMappingValue(sourceTemplateColumn.getMappingValue());
					saveSourceTemplatesColumnsPo.setMappingType(sourceTemplateColumn.getMappingType());
					saveSourceTemplatesColumnsPo.setOrigTransRef(sourceTemplateColumn.getOrigTransRef());
					saveSourceTemplatesColumnsPo.setSelected(sourceTemplateColumn.getSelected());
					if(!Validations.isNullOrEmpty((sourceTemplateColumn.getColumnType())))
					saveSourceTemplatesColumnsPo.setColumnType(sourceTemplateColumn.getColumnType());
					if(!Validations.isNullOrEmpty((sourceTemplateColumn.getNullAllowedFlag())))
						saveSourceTemplatesColumnsPo.setNullAllowedFlag(sourceTemplateColumn.getNullAllowedFlag());
					if(sourceTemplateColumn.getWidth()!=null)
						saveSourceTemplatesColumnsPo.setWidth(sourceTemplateColumn.getWidth());			
					saveSourceTemplatesColumnsPo.setTemplateId(newTemplateId);

					sourceTemplateColumnsPo.add(saveSourceTemplatesColumnsPo);
				}

				msg = saveSourceTemplateColumnsDaoImpl.saveSourceTemplateColumns(sourceTemplateColumnsPo,request);

				log.info("source::: " + msg);
				
				if (srctempHeader.getMetaDataTableId() != null)
					metaDataTableName = xxrSourceTablesRepository
							.getMetaDataTableName(srctempHeader.getMetaDataTableId());

				System.out.println("metaDataTableName::" + metaDataTableName + "newTemplateId::" + newTemplateId
						+ "podId:::" + podId);

				stagingPo = createSourceStagTableDaoImpl.createStaggingTable(metaDataTableName, newTemplateId, podId,request);

				log.info("Source staging Table::::: " + stagingPo.getResult() + "stagingTableName :: "
						+ stagingPo.getTableName());
				
				if (stagingPo != null && !(stagingPo.getResult().isBlank())
						&& stagingPo.getResult().equalsIgnoreCase("Y")) {
					String stagingTableName=stagingPo.getTableName().split(":")[1];
					//srctempHeader.setStagingTableName(stagingTableName);

					createDynamicViewPo = createSourceDynamicViewDaoImpl.createDynamicView(newTemplateId,
							stagingTableName,request);
					log.info("Source Dynamic view ::::: " + createDynamicViewPo.getResult() + "DynamicView :: "
							+ createDynamicViewPo.getViewName());

					/*
					 * if (createDynamicViewPo != null &&
					 * !(createDynamicViewPo.getResult().isBlank()) &&
					 * createDynamicViewPo.getResult().equalsIgnoreCase("Y"))
					 * srctempHeader.setViewName(createDynamicViewPo.getViewName());
					 * 
					 * sourceTemplateHeadersRepository.save(srctempHeader);
					 */
				}

				
				saveTemplateHeaderResponsePo.setTemplateId(newTemplateId);
				saveTemplateHeaderResponsePo.setTemplateName(newTemplateName);
				saveTemplateHeaderResponsePo.setMessage("SourceTemplate Copied successfully");
			}

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return saveTemplateHeaderResponsePo;
	}
}
