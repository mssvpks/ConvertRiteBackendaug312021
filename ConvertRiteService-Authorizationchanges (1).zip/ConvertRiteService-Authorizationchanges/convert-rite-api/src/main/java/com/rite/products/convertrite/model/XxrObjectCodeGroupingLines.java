package com.rite.products.convertrite.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "XXR_OBJECT_CODE_GROUPING_LINES")
public class XxrObjectCodeGroupingLines {

	@Id
	@Column(name = "GROUP_LINE_ID ")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "objectcode_grouping_line_generator")
	@SequenceGenerator(name = "objectcode_grouping_line_generator", sequenceName = "xxr_object_code_grouping_line_id_s", allocationSize = 1)
	private Long groupLineId;
	@Column(name = "GROUP_ID")
	private Long groupId;
	@Column(name = "OBJECT_ID")
	private Long objectId;

	

	public Long getGroupLineId() {
		return groupLineId;
	}

	public void setGroupLineId(Long groupLineId) {
		this.groupLineId = groupLineId;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public Long getObjectId() {
		return objectId;
	}

	public void setObjectId(Long objectId) {
		this.objectId = objectId;
	}

}
