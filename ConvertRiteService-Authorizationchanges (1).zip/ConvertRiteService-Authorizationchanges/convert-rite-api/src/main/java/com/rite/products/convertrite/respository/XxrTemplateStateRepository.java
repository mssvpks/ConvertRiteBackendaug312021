package com.rite.products.convertrite.respository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rite.products.convertrite.model.XxrTemplateState;

public interface XxrTemplateStateRepository extends JpaRepository<XxrTemplateState,String> {

}
