package com.rite.products.convertrite.service;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.opencsv.CSVWriter;
import com.rite.products.convertrite.model.XxrBlobConvertrite;
import com.rite.products.convertrite.model.XxrCloudDataProcess;
import com.rite.products.convertrite.po.CloudDataProcessingReqPo;
import com.rite.products.convertrite.respository.XxrBlobConvertriteRepository;
import com.rite.products.convertrite.respository.XxrCloudDataProcessRepository;

@Service
public class CloudDataProcessingServiceImpl implements CloudDataProcessingService {

	private static final Logger log = LoggerFactory.getLogger(CloudDataProcessingServiceImpl.class);

	// private static AtomicLong numberGenerator = new AtomicLong(1);

	@Value("${file.local-dir}")
	private String localDir;

	@Value("${file.upload-dir}")
	private String remoteDir;

	@Value("${sftp.client.host}")
	private String remoteHost;

	@Value("${sftp.client.username}")
	private String username;

	@Value("${sftp.client.password}")
	private String password;

	@Autowired
	XxrCloudDataProcessRepository xxrCloudDataProcessRepository;
	@Autowired
	XxrBlobConvertriteRepository xxBlobConvertriteRepository;

	@Override
	public XxrCloudDataProcess cloudDataProcessingRequests(CloudDataProcessingReqPo cloudDataProcessingReqPo)
			throws Exception {
		log.info("Start of cloudDataProcessingRequests Method::::::::");

		XxrCloudDataProcess xxrCloudDataProcess = new XxrCloudDataProcess();
		XxrCloudDataProcess xxrCloudDataProcessRes = new XxrCloudDataProcess();
		try {
			// Long requestId=(numberGenerator.getAndIncrement());
			UUID requestId = UUID.randomUUID();
			xxrCloudDataProcess.setRequestId(requestId.toString());
			xxrCloudDataProcess.setDescription(cloudDataProcessingReqPo.getDescription());
			xxrCloudDataProcess.setSqlQuery(cloudDataProcessingReqPo.getSqlQuery());
			xxrCloudDataProcess.setLookupFlag(cloudDataProcessingReqPo.getLookUpFlag());
			xxrCloudDataProcess.setStatus("Starting");
			java.util.Date date = new java.util.Date();
			System.out.println("date::::::" + date);
			xxrCloudDataProcess.setCreationDate(date);
			xxrCloudDataProcess.setScheduledJobCall(cloudDataProcessingReqPo.getScheduledJobCall());
			if(cloudDataProcessingReqPo.getPriority()!=null)
			xxrCloudDataProcess.setPriority(cloudDataProcessingReqPo.getPriority());
			else
				xxrCloudDataProcess.setPriority(0);	
			xxrCloudDataProcessRepository.save(xxrCloudDataProcess);

			xxrCloudDataProcessRes = xxrCloudDataProcessRepository.findByrequestId(requestId.toString());
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
		return xxrCloudDataProcessRes;
	}

	@Override
	public List<XxrCloudDataProcess> getAllCloudDataRequests() throws Exception {
		log.info("Start of getAllCloudDataRequests Method::::::::");
		List<XxrCloudDataProcess> xxrCloudDataProcess = new ArrayList<>();
		try {
			xxrCloudDataProcess = xxrCloudDataProcessRepository.findAll();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return xxrCloudDataProcess;
	}

	@Override
	public void downloadCsvFile(String requestId, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		log.info("Start of downloadCsvFile Method in Service class######");
		XxrBlobConvertrite res = new XxrBlobConvertrite();
		try {
			PrintWriter writer = response.getWriter();
			Optional<XxrBlobConvertrite> lobResp = xxBlobConvertriteRepository.findById(requestId);
			if (lobResp.isPresent()) {
				res = lobResp.get();
				CSVWriter csvWriter = new CSVWriter(writer, CSVWriter.DEFAULT_SEPARATOR,
						CSVWriter.DEFAULT_QUOTE_CHARACTER, CSVWriter.DEFAULT_ESCAPE_CHARACTER,
						CSVWriter.DEFAULT_LINE_END);
				String lob=res.getBlob();
				String [] lineArr=lob.split("\n");
				List<String[]> csvList=new ArrayList<>();
				for(String line:lineArr) {
					csvList.add(line.split(","));
				}
				csvWriter.writeAll(csvList);
				csvWriter.flush();
				csvWriter.close();
			}
			// channelSftp.exit();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	/*
	 * private ChannelSftp setupJsch() throws JSchException { JSch jsch = new
	 * JSch(); Session jschSession = jsch.getSession(username, remoteHost);
	 * jschSession.setPassword(password); // jschSession.setPort(port);
	 * java.util.Properties config = new java.util.Properties();
	 * config.put("StrictHostKeyChecking", "no"); jschSession.setConfig(config);
	 * jschSession.setTimeout(6000); jschSession.connect(); return (ChannelSftp)
	 * jschSession.openChannel("sftp"); }
	 */
}
