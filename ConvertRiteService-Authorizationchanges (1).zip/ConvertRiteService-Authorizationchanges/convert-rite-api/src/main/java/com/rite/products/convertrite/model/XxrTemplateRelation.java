package com.rite.products.convertrite.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "XXR_TEMPLATE_RELATION")
public class XxrTemplateRelation {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "template_relaton_generator")
	@SequenceGenerator(name = "template_relaton_generator", sequenceName = "xxr_template_relation_id_s", allocationSize = 1)
	@Column(name = "ID")
	private Long id;
	@Column(name = "TEMPLATE_IDS")
	private String templateIds;
	@Column(name = "IS_ZIPPED")
	private String isZipped;
	@Column(name = "VERSION")
	private String version;
	@Column(name = "GROUP_ID")
	private Long groupId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTemplateIds() {
		return templateIds;
	}

	public void setTemplateIds(String templateIds) {
		this.templateIds = templateIds;
	}

	public String getIsZipped() {
		return isZipped;
	}

	public void setIsZipped(String isZipped) {
		this.isZipped = isZipped;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

}
