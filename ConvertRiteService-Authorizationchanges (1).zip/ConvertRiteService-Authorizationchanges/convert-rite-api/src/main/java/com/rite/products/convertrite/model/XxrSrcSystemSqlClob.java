package com.rite.products.convertrite.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "XXR_SRC_SYSTEM_SQL_CLOB")
public class XxrSrcSystemSqlClob {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "xxr_src_system_sqlclob_generator")
	@SequenceGenerator(name = "xxr_src_system_sqlclob_generator", sequenceName = "xxr_src_system_sql_clob_id_s", allocationSize = 1)
	@Column(name = "ID")
	private Long id;
	@Column(name = "OBJECT_CODE")
	private String objectCode;
	@Column(name = "SOURCE_SYSTEM")
	private String sourceSystem;
	@Column(name = "VERSION")
	private String version;
	@Lob
	@Column(name = "SQL_CLOB")
	private String sqlClob;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getObjectCode() {
		return objectCode;
	}

	public void setObjectCode(String objectCode) {
		this.objectCode = objectCode;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getSqlClob() {
		return sqlClob;
	}

	public void setSqlClob(String sqlClob) {
		this.sqlClob = sqlClob;
	}

}
