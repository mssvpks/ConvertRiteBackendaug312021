package com.rite.products.convertrite.service;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.rite.products.convertrite.model.XxrErpIntegration;
import com.rite.products.convertrite.po.LoadImportJobStatusResPo;
import com.rite.products.convertrite.po.LoadandImportDataReqPo;
import com.rite.products.convertrite.po.LoadandImportDataResPo;

public interface ErpIntegrationService {

	LoadandImportDataResPo loadAndImportData(LoadandImportDataReqPo loadandImportDataReqPo) throws Exception;

	LoadImportJobStatusResPo getJobStatus(Long resultId)throws Exception;

	List<XxrErpIntegration> getErpIntegrationDetails()throws Exception;

	byte[] downloadExportOutput(String requestId,HttpServletResponse response)throws Exception;

}
