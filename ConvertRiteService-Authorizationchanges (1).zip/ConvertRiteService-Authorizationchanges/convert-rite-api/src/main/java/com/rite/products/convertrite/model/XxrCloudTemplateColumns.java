package com.rite.products.convertrite.model;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "XXR_CLD_TEMP_COLS")
@IdClass(XxrCloudTemplateColumnsId.class)
public class XxrCloudTemplateColumns implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "TEMPLATE_ID")
	private long templateId;
	@Column(name = "COLUMN_ID")
	private long columnId;
	@Id
	@Column(name = "COLUMN_NAME")
	private String columnName;
	@Column(name = "SELECTED")
	private String selected;
	@Column(name = "SOURCE_COLUMN_ID")
	private Long sourceColumnId;
	@Column(name = "MAPPING_TYPE")
	private String mappingType;
	@Column(name = "MAPPING_SET_ID")
	private Long mappingSetId;
	@Column(name = "ENABLED_FLAG")
	private String enabledFlag;
	@Column(name = "MAPPING_VALUE")
	private String mappingValue;
	@Column(name = "DISPLAY_SEQ")
	private Integer seq;
	@Column(name = "COLUMN_TYPE")
	private String columnType;
	@Column(name = "WIDTH")
	private Long width;
	@Column(name = "NULL_ALLOWED_FLAG")
	private String nullAllowedFlag;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = "Asia/Kolkata")
	@Column(name = "START_DATE")
	private Date startDate;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = "Asia/Kolkata")
	@Column(name = "END_DATE")
	private Date endDate;
	@Column(name = "ORIG_TRANS_REF")
	private String origTransRef;
	@Column(name="DESCRIPTION")
	private String description;
	
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getOrigTransRef() {
		return origTransRef;
	}

	public void setOrigTransRef(String origTransRef) {
		this.origTransRef = origTransRef;
	}

	public String getColumnType() {
		return columnType;
	}

	public void setColumnType(String columnType) {
		this.columnType = columnType;
	}

	public Long getWidth() {
		return width;
	}

	public void setWidth(Long width) {
		this.width = width;
	}

	public String getNullAllowedFlag() {
		return nullAllowedFlag;
	}

	public void setNullAllowedFlag(String nullAllowedFlag) {
		this.nullAllowedFlag = nullAllowedFlag;
	}

	public long getTemplateId() {
		return templateId;
	}

	public void setTemplateId(long templateId) {
		this.templateId = templateId;
	}

	public long getColumnId() {
		return columnId;
	}

	public void setColumnId(long columnId) {
		this.columnId = columnId;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getSelected() {
		return selected;
	}

	public void setSelected(String selected) {
		this.selected = selected;
	}

	public Long getSourceColumnId() {
		return sourceColumnId;
	}

	public void setSourceColumnId(Long sourceColumnId) {
		this.sourceColumnId = sourceColumnId;
	}

	public String getMappingType() {
		return mappingType;
	}

	public void setMappingType(String mappingType) {
		this.mappingType = mappingType;
	}

	public Long getMappingSetId() {
		return mappingSetId;
	}

	public void setMappingSetId(Long mappingSetId) {
		this.mappingSetId = mappingSetId;
	}

	public String getEnabledFlag() {
		return enabledFlag;
	}

	public void setEnabledFlag(String enabledFlag) {
		this.enabledFlag = enabledFlag;
	}

	public String getMappingValue() {
		return mappingValue;
	}

	public void setMappingValue(String mappingValue) {
		this.mappingValue = mappingValue;
	}

	public Integer getSeq() {
		return seq;
	}

	public void setSeq(Integer seq) {
		this.seq = seq;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

}
