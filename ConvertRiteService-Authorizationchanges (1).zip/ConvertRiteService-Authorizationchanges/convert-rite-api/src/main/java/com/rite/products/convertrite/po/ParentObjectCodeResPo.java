package com.rite.products.convertrite.po;

public class ParentObjectCodeResPo {
	
	private long parentObjectId;
	private String parentObjectCode;
	public long getParentObjectId() {
		return parentObjectId;
	}
	public void setParentObjectId(long parentObjectId) {
		this.parentObjectId = parentObjectId;
	}
	public String getParentObjectCode() {
		return parentObjectCode;
	}
	public void setParentObjectCode(String parentObjectCode) {
		this.parentObjectCode = parentObjectCode;
	}
	
	

}
