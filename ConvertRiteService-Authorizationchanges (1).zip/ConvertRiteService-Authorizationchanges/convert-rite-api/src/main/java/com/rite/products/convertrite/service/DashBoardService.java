package com.rite.products.convertrite.service;

import java.util.List;

import com.rite.products.convertrite.exception.BadRequestException;
import com.rite.products.convertrite.po.DashBoardResPo;
import com.rite.products.convertrite.po.GantChatResPo;
import com.rite.products.convertrite.po.TaskBreakDownPo;

public interface DashBoardService {
	public List<DashBoardResPo> getTask(String user) throws BadRequestException, Exception;
	
	 public List<GantChatResPo> getGanttChat(String user) throws BadRequestException, Exception;

}
