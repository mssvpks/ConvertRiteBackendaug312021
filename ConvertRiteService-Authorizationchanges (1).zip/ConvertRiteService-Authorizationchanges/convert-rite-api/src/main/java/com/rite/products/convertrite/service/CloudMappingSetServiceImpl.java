package com.rite.products.convertrite.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rite.products.convertrite.Validations.Validations;
import com.rite.products.convertrite.exception.BadRequestException;
import com.rite.products.convertrite.exception.ValidationException;
import com.rite.products.convertrite.model.XxrMappingSets;
import com.rite.products.convertrite.model.XxrMappingValues;
import com.rite.products.convertrite.po.CloudColumnsPo;
import com.rite.products.convertrite.po.LovValuesPo;
import com.rite.products.convertrite.po.SaveCloudMappingSetColumnsPo;
import com.rite.products.convertrite.po.SaveCloudMappingSetColumnsResPo;
import com.rite.products.convertrite.po.SaveCloudMappingSetHeaderResPo;
import com.rite.products.convertrite.po.SaveCloudMappingSetHeadersPo;
import com.rite.products.convertrite.po.SourceColumnsPo;
import com.rite.products.convertrite.po.XxrMappingSetsResPo;
import com.rite.products.convertrite.respository.CloudMetaDataRepository;
import com.rite.products.convertrite.respository.SaveCloudMappingSetColumnsDaoImpl;
import com.rite.products.convertrite.respository.SaveCloudMappingSetHeadersDaoImpl;
import com.rite.products.convertrite.respository.SourceTemplateColumnsRepository;
import com.rite.products.convertrite.respository.SourceTemplateHeadersDaoImpl;
import com.rite.products.convertrite.respository.SourceTemplateHeadersRepository;
import com.rite.products.convertrite.respository.XxrCloudColumnsRepository;
import com.rite.products.convertrite.respository.XxrCloudMasterLookupTabRepository;
import com.rite.products.convertrite.respository.XxrCloudMasterLookupValueTabRepository;
import com.rite.products.convertrite.respository.XxrLookUpValuesRepository;
import com.rite.products.convertrite.respository.XxrLookupSetsRepository;
import com.rite.products.convertrite.respository.XxrMappingSetsRepository;
import com.rite.products.convertrite.respository.XxrMappingValuesRepository;
import com.rite.products.convertrite.utils.Utils;

@Service
public class CloudMappingSetServiceImpl implements CloudMappingSetService {

	private static final Logger log = LoggerFactory.getLogger(CloudMappingSetServiceImpl.class);

	@Autowired
	CloudMetaDataRepository cloudMetaDataRepository;
	@Autowired
	SourceTemplateHeadersRepository sourceTemplateHeadersRepository;
	@Autowired
	SourceTemplateColumnsRepository sourceTemplateColumnsRepository;
	@Autowired
	SourceTemplateHeadersDaoImpl sourceTemplateHeadersDaoImpl;
	@Autowired
	XxrCloudMasterLookupValueTabRepository xxrCloudMasterLookupValueTabRepository;
	@Autowired
	XxrCloudMasterLookupTabRepository xxrCloudMasterLookupTabRepository;
	@Autowired
	XxrMappingSetsRepository xxrColumnMapHdrRepository;
	@Autowired
	XxrMappingValuesRepository xxrColumnMapLineRepository;
	@Autowired
	XxrCloudColumnsRepository xxrCloudColumnsRepository;
	@Autowired
	SaveCloudMappingSetHeadersDaoImpl saveCloudMappingSetHeadersDaoImpl;
	@Autowired
	SaveCloudMappingSetColumnsDaoImpl saveCloudMappingSetColumnsDaoImpl;
	@Autowired
	XxrLookUpValuesRepository xxrLookUpValuesRepository;
	@Autowired
	XxrLookupSetsRepository xxrLookupSetsRepository;

	@Override
	public String[] getSourceObjects(Long podId, Long projectId, Long parentObjectId, Long objectCodeId)
			throws Exception {
		log.info("Start Of getSourceObjects Method in Service Layer ####");
		String[] sourceObjects = {};
		try {
			/*
			 * String podValue = cloudMetaDataRepository.getValueById(podId); String
			 * projectName = cloudMetaDataRepository.getValueById(projectId); String
			 * parentObjectCode = cloudMetaDataRepository.getValueById(parentObjectId);
			 * String objectCode = cloudMetaDataRepository.getValueById(objectCodeId);
			 * log.info("podValue:::::" + podValue + "projectName:::" + projectName +
			 * "parentObjectCode::::" + parentObjectCode + "objectCode:::" + objectCode); if
			 * (!Validations.isNullOrEmpty(podValue) &&
			 * !Validations.isNullOrEmpty(projectName) &&
			 * !Validations.isNullOrEmpty(parentObjectCode) &&
			 * !Validations.isNullOrEmpty(objectCode))
			 */

			sourceObjects = sourceTemplateHeadersRepository.getSourceObjects(podId, projectId, parentObjectId,
					objectCodeId);

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return sourceObjects;
	}

	@Override
	public List<SourceColumnsPo> getSourceColumns(String viewName) throws Exception {
		log.info("Start Of getSourceColumns Method in Service Layer ####");
		List<SourceColumnsPo> sourceTemplateColumns = new ArrayList<>();
		try {
			Long templateId = sourceTemplateHeadersRepository.getTemplateIdByViewName(viewName);
			if (templateId != null)
				sourceTemplateColumns = sourceTemplateColumnsRepository.getSourceColumns(templateId);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return sourceTemplateColumns;

	}

	@Override
	public List<Object> getSourceFields(String viewName, String columnName) throws Exception {

		log.info("Start Of getSourceFields Method in Service Layer ####");
		List<Object> sourceFields = new ArrayList<>();
		try {

			sourceFields = sourceTemplateHeadersDaoImpl.getSourceFields(columnName, viewName);

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return sourceFields;
	}

	@Override
	public List<String> getCloudValues(Long objectId, String cloudColumn) throws Exception {
		log.info("Start Of getCloudValues Method in Service Layer ####");
		// String[] cloudValues = new String[100];
		List<String> cloudValues = new ArrayList<String>();
		try {
//			Long lookupSetId = xxrCloudMasterLookupTabRepository.getLookUpSetId(objectCode, cloudColumn);
//			if (lookupSetId != null)
//				cloudValues = xxrClLovValuesPooudMasterLookupValueTabRepository.getlookupValue(lookupSetId);
			List<LovValuesPo> lovValues = cloudMetaDataRepository.getValues(cloudColumn);

			for (LovValuesPo lovVal : lovValues) {
				cloudValues.add(lovVal.getValue());
			}

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return cloudValues;
	}

	@Override
	public List<XxrMappingSetsResPo> getCloudMappingSets(Long podId, Long projectId, Long objectId) throws Exception {
		log.info("Start Of getCloudMappingSets Method in Service Layer ####");
		List<XxrMappingSets> cloudMappingSetList = new ArrayList<>();
		List<XxrMappingSetsResPo> mappingSetResPoList = new ArrayList<>();
		try {
			/*
			 * String podValue = cloudMetaDataRepository.getValueById(podId); String
			 * projectName = cloudMetaDataRepository.getValueById(projectId);
			 * log.info("podValue:::::" + podValue + "projectName:::" + projectName); if
			 * (!Validations.isNullOrEmpty(podValue) &&
			 * !Validations.isNullOrEmpty(projectName) &&objectId!=null)
			 */
			cloudMappingSetList = xxrColumnMapHdrRepository.getCloudMappingSets(podId, projectId, objectId);

			cloudMappingSetList.stream().forEach(x -> {

				XxrMappingSetsResPo xxrMappingSetsResPo = new XxrMappingSetsResPo();

				String podName = xxrLookUpValuesRepository.getValueById(x.getPodId());
				String projectName = xxrLookUpValuesRepository.getValueById(x.getProjectId());
				String objectCode = xxrLookUpValuesRepository.getValueById(x.getObjectId());
				String parentObjectCode = xxrLookUpValuesRepository.getValueById(x.getParentObjectId());

				if (x.getMapSetId() != null)
					xxrMappingSetsResPo.setMapSetId(x.getMapSetId());
				if (!Validations.isNullOrEmpty(x.getMapSetName()))
					xxrMappingSetsResPo.setMapSetName(x.getMapSetName());
				if (!Validations.isNullOrEmpty(x.getMapSetType()))
					xxrMappingSetsResPo.setMapSetType(x.getMapSetType());
				if (!Validations.isNullOrEmpty(x.getCloudColumn()))
					xxrMappingSetsResPo.setCloudColumn(x.getCloudColumn());
				xxrMappingSetsResPo.setPodId(x.getPodId());
				if (!Validations.isNullOrEmpty(podName))
					xxrMappingSetsResPo.setPodName(podName);
				if (!Validations.isNullOrEmpty(objectCode))
					xxrMappingSetsResPo.setObjectCode(objectCode);
				xxrMappingSetsResPo.setObjectId(x.getObjectId());
				if (!Validations.isNullOrEmpty(parentObjectCode))
					xxrMappingSetsResPo.setParentObjectCode(parentObjectCode);
				xxrMappingSetsResPo.setParentObjectId(x.getParentObjectId());
				xxrMappingSetsResPo.setProjectId(x.getProjectId());
				if (!Validations.isNullOrEmpty(projectName))
					xxrMappingSetsResPo.setProjectName(projectName);
				if (!Validations.isNullOrEmpty(x.getSourceColumn1()))
					xxrMappingSetsResPo.setSourceColumn1(x.getSourceColumn1());
				if (!Validations.isNullOrEmpty(x.getSourceColumn2()))
					xxrMappingSetsResPo.setSourceColumn2(x.getSourceColumn2());
				if (!Validations.isNullOrEmpty(x.getSourceColumn3()))
					xxrMappingSetsResPo.setSourceColumn3(x.getSourceColumn3());
				if (!Validations.isNullOrEmpty(x.getSourceObject1()))
					xxrMappingSetsResPo.setSourceObject1(x.getSourceObject1());
				if (!Validations.isNullOrEmpty(x.getSourceObject2()))
					xxrMappingSetsResPo.setSourceObject2(x.getSourceObject2());
				if (!Validations.isNullOrEmpty(x.getSourceObject3()))
					xxrMappingSetsResPo.setSourceObject3(x.getSourceObject3());
				if (!Validations.isNullOrEmpty(x.getAttribute1()))
					xxrMappingSetsResPo.setAttribute1(x.getAttribute1());
				if (!Validations.isNullOrEmpty(x.getAttribute2()))
					xxrMappingSetsResPo.setAttribute2(x.getAttribute2());
				if (!Validations.isNullOrEmpty(x.getAttribute3()))
					xxrMappingSetsResPo.setAttribute3(x.getAttribute3());
				if (!Validations.isNullOrEmpty(x.getAttribute4()))
					xxrMappingSetsResPo.setAttribute4(x.getAttribute4());
				if (!Validations.isNullOrEmpty(x.getAttribute5()))
					xxrMappingSetsResPo.setAttribute5(x.getAttribute5());
				if (!Validations.isNullOrEmpty(x.getWhereClause()))
					xxrMappingSetsResPo.setWhereClause(x.getWhereClause());

				mappingSetResPoList.add(xxrMappingSetsResPo);
			});

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return mappingSetResPoList;
	}

	@Override
	public List<XxrMappingSetsResPo> getAllCloudMappingSets() throws Exception {
		log.info("Start Of getAllCloudMappingSets Method in Service Layer ####");
		List<XxrMappingSets> cloudMappingSetList = new ArrayList<>();
		List<XxrMappingSetsResPo> mappingSetResPoList = new ArrayList<>();
		try {

			cloudMappingSetList = xxrColumnMapHdrRepository.findAll();

			cloudMappingSetList.stream().forEach(x -> {

				XxrMappingSetsResPo xxrMappingSetsResPo = new XxrMappingSetsResPo();

				String podName = xxrLookUpValuesRepository.getValueById(x.getPodId());
				String projectName = xxrLookUpValuesRepository.getValueById(x.getProjectId());
				String objectCode = xxrLookUpValuesRepository.getValueById(x.getObjectId());
				String parentObjectCode = xxrLookUpValuesRepository.getValueById(x.getParentObjectId());
				Long lookupSetId=xxrLookupSetsRepository.getLookupSetId(x.getLookupSetName());
				
				
				if (x.getMapSetId() != null)
					xxrMappingSetsResPo.setMapSetId(x.getMapSetId());
				if (!Validations.isNullOrEmpty(x.getMapSetName()))
					xxrMappingSetsResPo.setMapSetName(x.getMapSetName());
				if (!Validations.isNullOrEmpty(x.getMapSetType()))
					xxrMappingSetsResPo.setMapSetType(x.getMapSetType());
				if (!Validations.isNullOrEmpty(x.getCloudColumn()))
					xxrMappingSetsResPo.setCloudColumn(x.getCloudColumn());
				xxrMappingSetsResPo.setPodId(x.getPodId());
				if (!Validations.isNullOrEmpty(podName))
					xxrMappingSetsResPo.setPodName(podName);
				if (!Validations.isNullOrEmpty(objectCode))
					xxrMappingSetsResPo.setObjectCode(objectCode);
				xxrMappingSetsResPo.setObjectId(x.getObjectId());
				if (!Validations.isNullOrEmpty(parentObjectCode))
					xxrMappingSetsResPo.setParentObjectCode(parentObjectCode);
				xxrMappingSetsResPo.setParentObjectId(x.getParentObjectId());
				xxrMappingSetsResPo.setProjectId(x.getProjectId());
				if (!Validations.isNullOrEmpty(projectName))
					xxrMappingSetsResPo.setProjectName(projectName);
				if (!Validations.isNullOrEmpty(x.getSourceColumn1()))
					xxrMappingSetsResPo.setSourceColumn1(x.getSourceColumn1());
				if (!Validations.isNullOrEmpty(x.getSourceColumn2()))
					xxrMappingSetsResPo.setSourceColumn2(x.getSourceColumn2());
				if (!Validations.isNullOrEmpty(x.getSourceColumn3()))
					xxrMappingSetsResPo.setSourceColumn3(x.getSourceColumn3());
				if (!Validations.isNullOrEmpty(x.getSourceObject1()))
					xxrMappingSetsResPo.setSourceObject1(x.getSourceObject1());
				if (!Validations.isNullOrEmpty(x.getSourceObject2()))
					xxrMappingSetsResPo.setSourceObject2(x.getSourceObject2());
				if (!Validations.isNullOrEmpty(x.getSourceObject3()))
					xxrMappingSetsResPo.setSourceObject3(x.getSourceObject3());
				if (!Validations.isNullOrEmpty(x.getAttribute1()))
					xxrMappingSetsResPo.setAttribute1(x.getAttribute1());
				if (!Validations.isNullOrEmpty(x.getAttribute2()))
					xxrMappingSetsResPo.setAttribute2(x.getAttribute2());
				if (!Validations.isNullOrEmpty(x.getAttribute3()))
					xxrMappingSetsResPo.setAttribute3(x.getAttribute3());
				if (!Validations.isNullOrEmpty(x.getAttribute4()))
					xxrMappingSetsResPo.setAttribute4(x.getAttribute4());
				if (!Validations.isNullOrEmpty(x.getAttribute5()))
					xxrMappingSetsResPo.setAttribute5(x.getAttribute5());
				if (!Validations.isNullOrEmpty(x.getWhereClause()))
					xxrMappingSetsResPo.setWhereClause(x.getWhereClause());
				
				xxrMappingSetsResPo.setLookupSetId(lookupSetId);
				xxrMappingSetsResPo.setLookupSetName(x.getLookupSetName());
				mappingSetResPoList.add(xxrMappingSetsResPo);
			});

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return mappingSetResPoList;
	}

	@Override
	public List<XxrMappingValues> getCloudMappingSetValues(Long mappingSetId) throws Exception {
		log.info("Start Of getCloudMappingSetValues Method in Service Layer ####");
		List<XxrMappingValues> cloudMappingSetValues = new ArrayList<>();
		try {
			cloudMappingSetValues = xxrColumnMapLineRepository.getMappingSetValues(mappingSetId);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return cloudMappingSetValues;
	}

	
	@Override
	public List<CloudColumnsPo> getCloudColumns(Long objectId) throws Exception {
		log.info("Start Of getCloudColumns Method in Service Layer ####");
		List<CloudColumnsPo> cloudColumnsList = new ArrayList<>();
		try {
			cloudColumnsList = xxrCloudColumnsRepository.getCloudColumns(objectId);
			
			cloudColumnsList=cloudColumnsList.stream().filter(Utils.distinctByKey(CloudColumnsPo::getColumnName)).collect(Collectors.toList());
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return cloudColumnsList;
	}

	
	@Override
	public SaveCloudMappingSetHeaderResPo saveCloudMappingSetHeaders(
			List<SaveCloudMappingSetHeadersPo> saveCloudMappingSetHeadersPo,HttpServletRequest request) throws ValidationException, Exception {
		log.info("Start Of saveCloudMappingSetHeaders Method in Service Layer ####");
		String msg = "";
		long mapSetId = 0;
		SaveCloudMappingSetHeaderResPo saveCloudMappingSetHeaderResPo = new SaveCloudMappingSetHeaderResPo();
		try {
			msg = saveCloudMappingSetHeadersDaoImpl.saveCloudMappingSetHeaders(saveCloudMappingSetHeadersPo,request);
			saveCloudMappingSetHeaderResPo.setMessage(msg);
			SaveCloudMappingSetHeadersPo saveSourceTemplateHeadersPo = saveCloudMappingSetHeadersPo.get(0);
			String mapSetName = saveSourceTemplateHeadersPo.getMapSetName();
			if (!Validations.isNullOrEmpty(mapSetName)) {
				mapSetId = xxrColumnMapHdrRepository.getMapId(mapSetName);
				saveCloudMappingSetHeaderResPo.setMapSetId(mapSetId);
				saveCloudMappingSetHeaderResPo.setMapSetName(mapSetName);
			}
			log.info(msg + "msg###########");
		} catch (ValidationException e) {
			throw new ValidationException(e.getMessage());
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return saveCloudMappingSetHeaderResPo;

	}

	@Override
	public SaveCloudMappingSetColumnsResPo saveCloudMappingSetColumns(
			List<SaveCloudMappingSetColumnsPo> cloudMappingSetColumnsPo,HttpServletRequest request) throws BadRequestException, Exception {
		log.info("Start of saveCloudMappingSetColumns in Service Layer ###");
		String msg = "";
		List<XxrMappingValues> cloudMappingSetColumns = new ArrayList<>();
		SaveCloudMappingSetColumnsResPo cloudMappingSetColumnsResPo = new SaveCloudMappingSetColumnsResPo();
		try {
			msg = saveCloudMappingSetColumnsDaoImpl.saveCloudMappingSetColumns(cloudMappingSetColumnsPo,request);
			cloudMappingSetColumnsResPo.setMessage(msg);
			Long mapSetId = cloudMappingSetColumnsPo.get(0).getMapSetId();
			if (mapSetId != null) {
				cloudMappingSetColumns = xxrColumnMapLineRepository.getMappingSetValues(mapSetId);
				cloudMappingSetColumnsResPo.setCloudMappingSetColumns(cloudMappingSetColumns);
			}
			log.info(msg + "msg###########");
		} catch (BadRequestException e) {
			throw new BadRequestException(e.getMessage());
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return cloudMappingSetColumnsResPo;
	}

	@Override
	public String[] getAllSourceObjects() throws Exception {
		log.info("Start Of getAllSourceObjects Method in Service Layer ####");
		String[] sourceObjects = {};
		try {
			sourceObjects = sourceTemplateHeadersRepository.getAllSourceObjects();

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return sourceObjects;
	}

	@Override
	public SaveCloudMappingSetHeaderResPo copyCloudMappingSet(String newMapSetName, Long mapSetId, Long podId,HttpServletRequest request)
			throws Exception {
		log.info("Start Of copyCloudMappingSet Method in Service Layer ####");
		List<XxrMappingSets> xxrMappingSetList = new ArrayList<>();
		List<SaveCloudMappingSetHeadersPo> cloudMappingSetHeadersPo = new ArrayList<>();
		String msg = "";
		Long newMapSetId = null;
		List<XxrMappingValues> xxrMappingValuesList = new ArrayList<>();
		List<SaveCloudMappingSetColumnsPo> cloudMappingSetColumnsPo = new ArrayList<>();
		SaveCloudMappingSetHeaderResPo saveCloudMappingSetHeaderResPo = new SaveCloudMappingSetHeaderResPo();
		try {
			xxrMappingSetList = xxrColumnMapHdrRepository.getCloudMappingSetsById(mapSetId);

			xxrMappingSetList.stream().forEach(x -> {
				SaveCloudMappingSetHeadersPo saveCloudMappingSetHeadersPo = new SaveCloudMappingSetHeadersPo();

				saveCloudMappingSetHeadersPo.setMapSetName(newMapSetName);
				saveCloudMappingSetHeadersPo.setPodId(podId);
				saveCloudMappingSetHeadersPo.setMapSetType(x.getMapSetType());
				saveCloudMappingSetHeadersPo.setCloudColumn(x.getCloudColumn());
				saveCloudMappingSetHeadersPo.setObjectId(x.getObjectId());
				saveCloudMappingSetHeadersPo.setParentObjectId(x.getParentObjectId());
				saveCloudMappingSetHeadersPo.setProjectId(x.getProjectId());
				saveCloudMappingSetHeadersPo.setSourceColumn1(x.getSourceColumn1());
				saveCloudMappingSetHeadersPo.setSourceColumn2(x.getSourceColumn2());
				saveCloudMappingSetHeadersPo.setSourceColumn3(x.getSourceColumn3());
				saveCloudMappingSetHeadersPo.setSourceObject1(x.getSourceObject1());
				saveCloudMappingSetHeadersPo.setSourceObject2(x.getSourceObject2());
				saveCloudMappingSetHeadersPo.setSourceObject3(x.getSourceObject3());
				saveCloudMappingSetHeadersPo.setAttribute1(x.getAttribute1());
				saveCloudMappingSetHeadersPo.setAttribute2(x.getAttribute2());
				saveCloudMappingSetHeadersPo.setAttribute3(x.getAttribute3());
				saveCloudMappingSetHeadersPo.setAttribute4(x.getAttribute4());
				saveCloudMappingSetHeadersPo.setAttribute5(x.getAttribute5());
				saveCloudMappingSetHeadersPo.setWhereClause(x.getWhereClause());
				saveCloudMappingSetHeadersPo.setLookupSetName(x.getLookupSetName());
				cloudMappingSetHeadersPo.add(saveCloudMappingSetHeadersPo);
			});
			msg = saveCloudMappingSetHeadersDaoImpl.saveCloudMappingSetHeaders(cloudMappingSetHeadersPo,request);
			log.info("MappingsetHeader :: " + msg);

			if (!Validations.isNullOrEmpty(newMapSetName))
				newMapSetId = xxrColumnMapHdrRepository.getMapId(newMapSetName);

			xxrMappingValuesList = xxrColumnMapLineRepository.getMappingSetValues(mapSetId);

			for (XxrMappingValues xxrMappingValue : xxrMappingValuesList) {
				SaveCloudMappingSetColumnsPo saveCloudMappingSetColumnsPo = new SaveCloudMappingSetColumnsPo();

				saveCloudMappingSetColumnsPo.setMapSetId(newMapSetId);
				saveCloudMappingSetColumnsPo.setCloudValue(xxrMappingValue.getCloudValue());
				saveCloudMappingSetColumnsPo.setEnabled(xxrMappingValue.getEnabled());
				saveCloudMappingSetColumnsPo.setSourceField1(xxrMappingValue.getSourceField1());
				saveCloudMappingSetColumnsPo.setSourceField2(xxrMappingValue.getSourceField2());
				saveCloudMappingSetColumnsPo.setSourceField3(xxrMappingValue.getSourceField3());
				saveCloudMappingSetColumnsPo.setAttribute1(xxrMappingValue.getAttribute1());
				saveCloudMappingSetColumnsPo.setAttribute2(xxrMappingValue.getAttribute2());
				saveCloudMappingSetColumnsPo.setAttribute3(xxrMappingValue.getAttribute3());
				saveCloudMappingSetColumnsPo.setAttribute4(xxrMappingValue.getAttribute4());
				saveCloudMappingSetColumnsPo.setAttribute5(xxrMappingValue.getAttribute5());

				cloudMappingSetColumnsPo.add(saveCloudMappingSetColumnsPo);
			}
			;

			msg = saveCloudMappingSetColumnsDaoImpl.saveCloudMappingSetColumns(cloudMappingSetColumnsPo,request);
			log.info("MappingsetColumn :: " + msg);

			saveCloudMappingSetHeaderResPo.setMapSetId(newMapSetId);
			saveCloudMappingSetHeaderResPo.setMapSetName(newMapSetName);
			saveCloudMappingSetHeaderResPo.setMessage("MappingSet is Successfully copied");

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return saveCloudMappingSetHeaderResPo;
	}
}
