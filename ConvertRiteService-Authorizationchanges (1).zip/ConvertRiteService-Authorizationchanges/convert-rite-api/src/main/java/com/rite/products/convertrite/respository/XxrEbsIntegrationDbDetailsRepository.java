package com.rite.products.convertrite.respository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.rite.products.convertrite.model.XxrEbsIntegrationDbDetails;

public interface XxrEbsIntegrationDbDetailsRepository extends JpaRepository<XxrEbsIntegrationDbDetails,Long>{

	XxrEbsIntegrationDbDetails findByPodIdAndProjectIdAndParentObjectIdAndObjectId(@Param("podId") Long podId,@Param("projectId") Long projectId,@Param("parentObjectId") Long parentObjectId,@Param("objectId") Long objectId);

}
