package com.rite.products.convertrite.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.rite.products.convertrite.model.SourceTemplateHeaders;
import com.rite.products.convertrite.po.ColumnPo;
import com.rite.products.convertrite.po.CreateDynamicViewPo;
import com.rite.products.convertrite.po.SaveSourceTemplateColumnsResPo;
import com.rite.products.convertrite.po.SaveSourceTemplateHeadersPo;
import com.rite.products.convertrite.po.SaveSourceTemplatesColumnsPo;
import com.rite.products.convertrite.po.SaveTemplateHeaderResponsePo;
import com.rite.products.convertrite.po.SourceStagingTablePo;
import com.rite.products.convertrite.po.SourceTablesPo;
import com.rite.products.convertrite.po.SourceTemplateColumnsResPo;
import com.rite.products.convertrite.po.SourceTemplateHeadersResPo;
import com.rite.products.convertrite.po.SourceTemplatePo;

public interface XxrSourceService {
	List<SourceTemplateHeadersResPo> getSourceTemplates() throws Exception;

	List<SourceTemplateHeadersResPo> getSourceTemplateHeaderById(long templateId) throws Exception;

	List<SourceTemplateHeaders> getSourceTemplatesByPo(SourceTemplatePo sourceTemplatePo) throws Exception;

	List<SourceTemplateColumnsResPo> getSourceTemplateColumns(long templateId) throws Exception;

	List<ColumnPo> getSourceColumnsByName(String sourceTableName) throws Exception;
	
	List<ColumnPo> getSourceColumnsById(long sourceTableId) throws Exception;
	
	SaveTemplateHeaderResponsePo saveSourceTemplateHeaders(List<SaveSourceTemplateHeadersPo> sourceTemplateHeadersPo,HttpServletRequest request) throws Exception;
	
	SaveSourceTemplateColumnsResPo saveSourceTemplateColumns(List<SaveSourceTemplatesColumnsPo> sourceTemplateColumnsPo,HttpServletRequest request) throws Exception;
	
	SourceStagingTablePo createSourceStaggingTab(String tableName,long templateId,long podId,HttpServletRequest request) throws Exception;

	CreateDynamicViewPo createDynamicView(Long templateId, String stgTableName,HttpServletRequest request) throws Exception;

	List<SourceTablesPo> getSourceTableNames(Long objectId) throws Exception;

	SaveTemplateHeaderResponsePo copySourceTemplate(String newTemplateName, Long templateId, Long podId,HttpServletRequest request)throws Exception;
}
