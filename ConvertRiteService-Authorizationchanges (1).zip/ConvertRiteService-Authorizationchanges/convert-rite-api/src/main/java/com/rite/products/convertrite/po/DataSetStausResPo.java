package com.rite.products.convertrite.po;

public class DataSetStausResPo {
	
	private String resultStatus;

	public String getResultStatus() {
		return resultStatus;
	}

	public void setResultStatus(String resultStatus) {
		this.resultStatus = resultStatus;
	}
	
	

}
