package com.rite.products.convertrite.po;

public class LovValuesPo {
	
	private String value;
	
	private long id;

	public LovValuesPo(String value, long id) {
		super();
		this.value = value;
		this.id = id;
	}
	
	public LovValuesPo(long id,String value) {
		super();
		this.value = value;
		this.id = id;
	}

	public String getValue() {
		return value;
	}

	public long getId() {
		return id;
	}
	
	
	

}
