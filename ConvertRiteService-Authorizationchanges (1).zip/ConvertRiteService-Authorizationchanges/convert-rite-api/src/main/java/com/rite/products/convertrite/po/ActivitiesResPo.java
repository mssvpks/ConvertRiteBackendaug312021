package com.rite.products.convertrite.po;

import java.util.List;

import com.rite.products.convertrite.model.XxrActivities;

public class ActivitiesResPo {

	private List<XxrActivities> xxrActivities;
	private String message;
	private String error;

	public List<XxrActivities> getXxrActivities() {
		return xxrActivities;
	}

	public void setXxrActivities(List<XxrActivities> xxrActivities) {
		this.xxrActivities = xxrActivities;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

}
