package com.rite.products.convertrite.respository;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.opencsv.CSVWriter;
import com.rite.products.convertrite.model.XxrCloudTemplateHeader;
import com.rite.products.convertrite.po.CloudTemplatePo;
import com.rite.products.convertrite.po.UpdateFailedRecResp;
import com.rite.products.convertrite.utils.DataSourceUtil;
import com.rite.products.convertrite.utils.Utils;

import oracle.jdbc.pool.OracleDataSource;

@Repository
public class CloudTemplateHeaderDaoImpl {

	@PersistenceContext
	private EntityManager entityManager;

	@Value("${datasource.hostname}")
	private String datasourceHostName;
	@Value("${datasource.port}")
	private int datasourcePort;
	@Value("${spring.datasource.username}")
	private String datasourceUserName;
	@Value("${spring.datasource.password}")
	private String datasourcePassword;
	@Value("${datasource.name}")
	private String dataSourceName;

	@Autowired
	DataSourceUtil dataSourceUtil;

	private static final Logger log = LoggerFactory.getLogger(CloudTemplateHeaderDaoImpl.class);

	@SuppressWarnings("unchecked")
	public List<XxrCloudTemplateHeader> getCloudTemplate(CloudTemplatePo cloudTemplatePo) {

		List<XxrCloudTemplateHeader> list = new ArrayList<>();
		try {
			StringBuilder sqlBuilder = new StringBuilder().append("select x from XxrCloudTemplateHeader x");

			if (!isNullOrEmpty(cloudTemplatePo.getObjectCode()))
				sqlBuilder.append(" where x.objectCode = :objectCode");
			if (cloudTemplatePo.getTemplateId() != null)
				sqlBuilder.append(" and x.templateId = :templateId");
			if (cloudTemplatePo.getPodId() != null)
				sqlBuilder.append(" and x.podId = :podId");
			if (cloudTemplatePo.getBu() != null)
				sqlBuilder.append(" and x.bu = :bu");
			if (!isNullOrEmpty(cloudTemplatePo.getBuSpecific()))
				sqlBuilder.append(" and x.buSpecific = :buSpecific");
			if (!isNullOrEmpty(cloudTemplatePo.getCloudDataTableName()))
				sqlBuilder.append(" and x.cloudDataTableName = :cloudDataTableName");
			if (!isNullOrEmpty(cloudTemplatePo.getParentObjectCode()))
				sqlBuilder.append(" and x.parentObjectCode = :parentObjectCode");
			if (!isNullOrEmpty(cloudTemplatePo.getProjectName()))
				sqlBuilder.append(" and x.projectName = :projectName");
			if (!isNullOrEmpty(cloudTemplatePo.getSourceHeaderTemplate()))
				sqlBuilder.append(" and x.sourceHeaderTemplate = :sourceHeaderTemplate");
			if (!isNullOrEmpty(cloudTemplatePo.getTableName()))
				sqlBuilder.append(" and x.tableName LIKE :tableName");
			if (!isNullOrEmpty(cloudTemplatePo.getTemplateName()))
				sqlBuilder.append(" and x.templateName LIKE :templateName");
			if (!isNullOrEmpty(cloudTemplatePo.getTemplateType()))
				sqlBuilder.append(" and x.templateType = :templateType");
			if (!isNullOrEmpty(cloudTemplatePo.getViewName()))
				sqlBuilder.append(" and x.viewName LIKE :viewName");
			String sql = sqlBuilder.toString();

			/* EntityManager en = em.createEntityManager(); */
			Query query = entityManager.createQuery(sql);

			if (!isNullOrEmpty(cloudTemplatePo.getObjectCode()))
				query.setParameter("objectCode", cloudTemplatePo.getObjectCode());
			if (cloudTemplatePo.getTemplateId() != null)
				query.setParameter("templateId", cloudTemplatePo.getTemplateId());
			if (cloudTemplatePo.getPodId() != null)
				query.setParameter("podId", cloudTemplatePo.getPodId());
			if (cloudTemplatePo.getBu() != null)
				query.setParameter("bu", cloudTemplatePo.getBu());
			if (!isNullOrEmpty(cloudTemplatePo.getBuSpecific()))
				query.setParameter("buSpecific", cloudTemplatePo.getBuSpecific());
			if (!isNullOrEmpty(cloudTemplatePo.getCloudDataTableName()))
				query.setParameter("cloudDataTableName", cloudTemplatePo.getCloudDataTableName());
			if (!isNullOrEmpty(cloudTemplatePo.getParentObjectCode()))
				query.setParameter("parentObjectCode", cloudTemplatePo.getParentObjectCode());
			if (!isNullOrEmpty(cloudTemplatePo.getProjectName()))
				query.setParameter("projectName", cloudTemplatePo.getProjectName());
			if (!isNullOrEmpty(cloudTemplatePo.getSourceHeaderTemplate()))
				query.setParameter("sourceHeaderTemplate", cloudTemplatePo.getSourceHeaderTemplate());
			if (!isNullOrEmpty(cloudTemplatePo.getTableName()))
				query.setParameter("tableName", "%" + cloudTemplatePo.getTableName() + "%");
			if (!isNullOrEmpty(cloudTemplatePo.getTemplateName()))
				query.setParameter("templateName", "%" + cloudTemplatePo.getTemplateName() + "%");
			if (!isNullOrEmpty(cloudTemplatePo.getTemplateType()))
				query.setParameter("templateType", cloudTemplatePo.getTemplateType());
			if (!isNullOrEmpty(cloudTemplatePo.getViewName()))
				query.setParameter("viewName", "%" + cloudTemplatePo.getViewName() + "%");

			list = query.getResultList();
		} catch (Exception e) {
			log.error(e.getMessage());
		}

		entityManager.clear();
		entityManager.close();
		return list;
	}

	private boolean isNullOrEmpty(String string) {
		return string == null || string.isEmpty();
	}

	public void generateFbdi(String tableName, PrintWriter writer) throws Exception {
		log.info("Start of generateFbdi Method in DaoImpl######");
		ResultSet rs = null;
		Connection con = null;
		try {
			StringBuilder sqlBuilder = new StringBuilder().append("select");
			sqlBuilder.append(" *");
			sqlBuilder.append(" from " + tableName);
			String sql = sqlBuilder.toString();

			Class.forName("oracle.jdbc.driver.OracleDriver");
			OracleDataSource dataSource = new OracleDataSource();
			dataSource.setServerName(datasourceHostName);
			dataSource.setUser(datasourceUserName);
			dataSource.setPassword(datasourcePassword);
			dataSource.setDatabaseName(dataSourceName);
			dataSource.setPortNumber(datasourcePort);
			dataSource.setDriverType("thin");
			con = dataSource.getConnection();

			// step3 create the statement object
			PreparedStatement stmt = con.prepareStatement(sql);

			// step4 execute query
			rs = stmt.executeQuery();

			CSVWriter csvWriter = new CSVWriter(writer, CSVWriter.DEFAULT_SEPARATOR, CSVWriter.NO_QUOTE_CHARACTER,
					CSVWriter.NO_ESCAPE_CHARACTER, CSVWriter.DEFAULT_LINE_END);

			csvWriter.writeAll(rs, false);
			csvWriter.flush();
			csvWriter.close();

		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		} finally {
			if (con != null)
				con.close();
		}
	}

	public void generateFbdiFromLob(Long cloudTemplateId, PrintWriter writer) throws Exception {
		log.info("Start of generateFbdi Method in DaoImpl######");
		ResultSet rs = null;
		Connection con = null;
		try {
			StringBuilder sqlBuilder = new StringBuilder().append("select xxr_conversion_utils_pkg.fbdi_filegen(");
			sqlBuilder.append(cloudTemplateId + ")");
			sqlBuilder.append(" from dual");
			String sql = sqlBuilder.toString();
			System.out.println(sql);
			con = dataSourceUtil.createConnection();
			// con = dataSource.getConnection();

			// step3 create the statement object
			PreparedStatement stmt = con.prepareStatement(sql);

			// step4 execute query
			rs = stmt.executeQuery();

			CSVWriter csvWriter = new CSVWriter(writer, CSVWriter.DEFAULT_SEPARATOR, CSVWriter.NO_QUOTE_CHARACTER,
					CSVWriter.NO_ESCAPE_CHARACTER, CSVWriter.DEFAULT_LINE_END);
			int columnCount = 0;
			if (rs.next()) {
				columnCount = rs.getMetaData().getColumnCount();
				System.out.println("true###########" + columnCount);
				String clobString = Utils.clobToString(rs.getClob(1));
				System.out.println("clobString::::::" + clobString);
				csvWriter.writeNext(clobString.split(","));
			}
			csvWriter.flush();
			csvWriter.close();

		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		} finally {
			if (con != null)
				con.close();
		}

	}

	public void generateHdlFromLob(Long cloudTemplateId, PrintWriter writer) throws Exception {
		log.info("Start of generateHdlFromLob Method in DaoImpl######");
		ResultSet rs = null;
		Connection con = null;
		try {
			StringBuilder sqlBuilder = new StringBuilder().append("select xxr_conversion_utils_pkg.hdl_filegen(");
			sqlBuilder.append(cloudTemplateId + ")");
			sqlBuilder.append(" from dual");
			String sql = sqlBuilder.toString();
			con = dataSourceUtil.createConnection();
			// con = dataSource.getConnection();
			// step3 create the statement object
			PreparedStatement stmt = con.prepareStatement(sql);
			// step4 execute query
			rs = stmt.executeQuery();
			// int columnCount=0;
			if (rs.next()) {
				// columnCount= rs.getMetaData().getColumnCount();
				String clobString = Utils.clobToString(rs.getClob(1));
				System.out.println("clobString::::::" + clobString);
				writer.write(clobString);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		} finally {
			if (con != null)
				con.close();
		}
	}

	public UpdateFailedRecResp updateFailedRec(List<String> sqlQueryLi) throws Exception {
		log.info("Start of updateFailedRec Method in DaoImpl######");
		Connection con = null;
		UpdateFailedRecResp updateFailedRecResp = new UpdateFailedRecResp();
		try {
			con = dataSourceUtil.createConnection();
			Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			con.setAutoCommit(false);
			for (String sqlQuery : sqlQueryLi) {
				stmt.addBatch(sqlQuery);
			}
			stmt.executeBatch();
			con.commit();
			updateFailedRecResp.setMessage("Suceessfully update edited failed Records");
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return updateFailedRecResp;
	}

	public void getTransformationReport(Long cloudTemplateId, PrintWriter writer) throws Exception {
		log.info("Start of getTransformationReport Method in DaoImpl######");
		ResultSet rs = null;
		Connection con = null;
		try {
			StringBuilder sqlBuilder = new StringBuilder()
					.append("SELECT xxr_conversion_utils_pkg.conversion_report_filegen(");
			sqlBuilder.append(cloudTemplateId + ")");
			sqlBuilder.append(" from dual");
			String sql = sqlBuilder.toString();
			con = dataSourceUtil.createConnection();
			// con = dataSource.getConnection();
			// step3 create the statement object
			PreparedStatement stmt = con.prepareStatement(sql);
			// step4 execute query
			rs = stmt.executeQuery();
			// int columnCount=0;
			if (rs.next()) {
				// columnCount= rs.getMetaData().getColumnCount();
				String clobString = Utils.clobToString(rs.getClob(1));
				System.out.println("clobString::::::" + clobString);
				writer.write(clobString);
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		} finally {
			if (con != null)
				con.close();
		}

	}
}
