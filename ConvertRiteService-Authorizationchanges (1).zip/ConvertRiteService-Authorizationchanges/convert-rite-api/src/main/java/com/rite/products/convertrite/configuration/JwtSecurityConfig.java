package com.rite.products.convertrite.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.oauth2.jwt.JwtDecoders;
import org.springframework.security.web.firewall.DefaultHttpFirewall;
import org.springframework.security.web.firewall.HttpFirewall;

@Configuration
@EnableWebSecurity
public class JwtSecurityConfig extends WebSecurityConfigurerAdapter {

	@Value("${spring.security.oauth2.resourceserver.jwt.issuer-uri}")
    String issuerUri;

    @Override
    protected void configure(HttpSecurity http) throws Exception {
    	System.out.println("entering##########");
    	http.cors().and().csrf().disable().authorizeRequests().anyRequest().authenticated();
    	http.oauth2ResourceServer(oauth2ResourceServer ->oauth2ResourceServer.jwt(jwt ->jwt.decoder(JwtDecoders.fromIssuerLocation(issuerUri))));
    	//http.cors().and().csrf().disable().authorizeRequests(authz -> authz.anyRequest().authenticated()).oauth2ResourceServer(oauth2ResourceServer ->oauth2ResourceServer.jwt(jwt ->jwt.decoder(JwtDecoders.fromIssuerLocation(issuerUri))));
    	System.out.println("entering111111##########");
    }

    
    @Override
	public void configure(WebSecurity web) {
	         //The new firewall is forced to overwrite the original
	    web.httpFirewall(allowUrlEncodedSlashHttpFirewall());
	}
	 
	@Bean
	public HttpFirewall allowUrlEncodedSlashHttpFirewall() {
		DefaultHttpFirewall firewall = new DefaultHttpFirewall();
	    firewall.setAllowUrlEncodedSlash(true);
	    return firewall;
	}

}
