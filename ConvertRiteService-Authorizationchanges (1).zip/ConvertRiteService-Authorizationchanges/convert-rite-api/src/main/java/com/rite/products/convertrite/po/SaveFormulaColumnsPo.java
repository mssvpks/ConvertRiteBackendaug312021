package com.rite.products.convertrite.po;

public class SaveFormulaColumnsPo {

	private Long formulaSetId;
	private Long formulaTableId;
	private Long formulaColumnId;
	private Long seq;
	private Long sourceColumnId;
	private String description;
	private String attribute1;
	private String attribute2;
	private String attribute3;
	private String attribute4;
	private String attribute5;

	public Long getFormulaSetId() {
		return formulaSetId;
	}

	public void setFormulaSetId(Long formulaSetId) {
		this.formulaSetId = formulaSetId;
	}

	public Long getFormulaTableId() {
		return formulaTableId;
	}

	public void setFormulaTableId(Long formulaTableId) {
		this.formulaTableId = formulaTableId;
	}

	public Long getFormulaColumnId() {
		return formulaColumnId;
	}

	public void setFormulaColumnId(Long formulaColumnId) {
		this.formulaColumnId = formulaColumnId;
	}

	public Long getSeq() {
		return seq;
	}

	public void setSeq(Long seq) {
		this.seq = seq;
	}

	public Long getSourceColumnId() {
		return sourceColumnId;
	}

	public void setSourceColumnId(Long sourceColumnId) {
		this.sourceColumnId = sourceColumnId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAttribute1() {
		return attribute1;
	}

	public void setAttribute1(String attribute1) {
		this.attribute1 = attribute1;
	}

	public String getAttribute2() {
		return attribute2;
	}

	public void setAttribute2(String attribute2) {
		this.attribute2 = attribute2;
	}

	public String getAttribute3() {
		return attribute3;
	}

	public void setAttribute3(String attribute3) {
		this.attribute3 = attribute3;
	}

	public String getAttribute4() {
		return attribute4;
	}

	public void setAttribute4(String attribute4) {
		this.attribute4 = attribute4;
	}

	public String getAttribute5() {
		return attribute5;
	}

	public void setAttribute5(String attribute5) {
		this.attribute5 = attribute5;
	}

}
