package com.rite.products.convertrite.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.rite.products.convertrite.model.XxrCloudDataProcess;
import com.rite.products.convertrite.po.DataSetStausResPo;
import com.rite.products.convertrite.po.HcmLoadAndImportDataRes;
import com.rite.products.convertrite.po.HcmLoadandImportDataReqPo;
import com.rite.products.convertrite.po.XxrHcmDataLoaderResPo;

public interface HcmDataImportService {

	DataSetStausResPo getDataSetStatus(String contentId, String processId) throws Exception;

	HcmLoadAndImportDataRes hcmLoadAndImportData(HcmLoadandImportDataReqPo hcmLoadandImportDataReqPo) throws Exception;

	List<XxrHcmDataLoaderResPo> getHcmDataLoaderDetails()throws Exception;

	XxrCloudDataProcess processHdlReconcile(String contentId,HttpServletRequest request)throws Exception;

}
