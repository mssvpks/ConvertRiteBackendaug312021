package com.rite.products.convertrite.respository;

import java.sql.Timestamp;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.rite.products.convertrite.model.XxrCloudDataProcess;

@Repository
public interface XxrCloudDataProcessRepository extends JpaRepository<XxrCloudDataProcess, String> {
	@Query(value = "SELECT * FROM XXR_CLOUD_DATA_PROCESS C WHERE C.request_id = :requestId", 
			  nativeQuery = true)
	XxrCloudDataProcess findByrequestId(@Param("requestId") String requestId);

	@Query("select max(creationDate) from XxrCloudDataProcess where scheduledJobCall='Y' and status='completed'")
	Timestamp getCreationDate();
	
	

}
