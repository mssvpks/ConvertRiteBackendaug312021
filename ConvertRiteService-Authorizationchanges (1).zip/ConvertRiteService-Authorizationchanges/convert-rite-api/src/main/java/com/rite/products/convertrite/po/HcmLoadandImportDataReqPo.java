package com.rite.products.convertrite.po;

public class HcmLoadandImportDataReqPo {

	private Long cloudTemplateId;
	private String documentTitle;
	private String documentAuthor;
	private String documentSecurityGroup;
	private String documentAccount;

	public Long getCloudTemplateId() {
		return cloudTemplateId;
	}

	public void setCloudTemplateId(Long cloudTemplateId) {
		this.cloudTemplateId = cloudTemplateId;
	}

	public String getDocumentTitle() {
		return documentTitle;
	}

	public void setDocumentTitle(String documentTitle) {
		this.documentTitle = documentTitle;
	}

	public String getDocumentAuthor() {
		return documentAuthor;
	}

	public void setDocumentAuthor(String documentAuthor) {
		this.documentAuthor = documentAuthor;
	}

	public String getDocumentSecurityGroup() {
		return documentSecurityGroup;
	}

	public void setDocumentSecurityGroup(String documentSecurityGroup) {
		this.documentSecurityGroup = documentSecurityGroup;
	}

	public String getDocumentAccount() {
		return documentAccount;
	}

	public void setDocumentAccount(String documentAccount) {
		this.documentAccount = documentAccount;
	}

}
