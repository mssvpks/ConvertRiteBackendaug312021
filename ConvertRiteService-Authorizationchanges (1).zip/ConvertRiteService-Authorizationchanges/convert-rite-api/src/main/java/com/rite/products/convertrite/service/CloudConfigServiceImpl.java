package com.rite.products.convertrite.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rite.products.convertrite.model.XxrCloudDataProcessConfig;
import com.rite.products.convertrite.po.SaveCloudConfigDetailsResPo;
import com.rite.products.convertrite.po.SaveCloudConfigReqPo;
import com.rite.products.convertrite.respository.XxrCloudDataProcessConfigRepository;
@Service
public class CloudConfigServiceImpl implements CloudConfigService {

	private static final Logger log = LoggerFactory.getLogger(CloudConfigServiceImpl.class);

	@Autowired
	XxrCloudDataProcessConfigRepository xxrCloudDataProcessConfigRepository;

	@Override
	public XxrCloudDataProcessConfig getCloudConfig() {
		// TODO Auto-generated method stub
		log.info("Start of getCloudConfig in service#####");
		List<XxrCloudDataProcessConfig> cloudDataConfig = new ArrayList<>();
		XxrCloudDataProcessConfig xxrCloudDataProcessConfig = new XxrCloudDataProcessConfig();
		try {
			cloudDataConfig = xxrCloudDataProcessConfigRepository.findAll();
			if (cloudDataConfig != null && !cloudDataConfig.isEmpty())
				xxrCloudDataProcessConfig = cloudDataConfig.get(0);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return xxrCloudDataProcessConfig;
	}

	@Override
	public SaveCloudConfigDetailsResPo saveCloudConfigDetails(SaveCloudConfigReqPo saveCloudConfigReqPo)
			throws Exception {
		// TODO Auto-generated method stub
		log.info("Start of saveCloudConfigDetails Method in service##");
		SaveCloudConfigDetailsResPo saveCloudConfigDetailsResPo = new SaveCloudConfigDetailsResPo();
		XxrCloudDataProcessConfig xxrCloudDataProcessConfigRes=new XxrCloudDataProcessConfig();
		try {

			Optional<XxrCloudDataProcessConfig> cloudprocessConfig = xxrCloudDataProcessConfigRepository
					.findById("50f2f052-4717-4fac-a53d-35f07218333a");
			if(cloudprocessConfig.isPresent()) {
				XxrCloudDataProcessConfig xxrCloudDataProcessConfig=cloudprocessConfig.get();
				xxrCloudDataProcessConfig.setCloudUrl(saveCloudConfigReqPo.getCloudUrl());
				xxrCloudDataProcessConfig.setPassword(saveCloudConfigReqPo.getPassword());
				xxrCloudDataProcessConfig.setUserName(saveCloudConfigReqPo.getUserName());
				xxrCloudDataProcessConfigRes=xxrCloudDataProcessConfigRepository.save(xxrCloudDataProcessConfig);
			}else {
				XxrCloudDataProcessConfig xxrCloudDataProcessConfig=new XxrCloudDataProcessConfig();
				xxrCloudDataProcessConfig.setId("50f2f052-4717-4fac-a53d-35f07218333a");
				xxrCloudDataProcessConfig.setCloudUrl(saveCloudConfigReqPo.getCloudUrl());
				xxrCloudDataProcessConfig.setPassword(saveCloudConfigReqPo.getPassword());
				xxrCloudDataProcessConfig.setUserName(saveCloudConfigReqPo.getUserName());
				xxrCloudDataProcessConfigRes=xxrCloudDataProcessConfigRepository.save(xxrCloudDataProcessConfig);	
			}
			saveCloudConfigDetailsResPo.setXxrCloudDataProcessConfig(xxrCloudDataProcessConfigRes);
			saveCloudConfigDetailsResPo.setMessage("Successfully saved cloud config details");
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return saveCloudConfigDetailsResPo;
	}

}
