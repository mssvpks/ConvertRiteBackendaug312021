package com.rite.products.convertrite.po;

public class CloudDataProcessingReqPo {
	private String sqlQuery;
	private String description;
	private String lookUpFlag;
	private String scheduledJobCall;
	private Integer priority;
	
	

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public String getSqlQuery() {
		return sqlQuery;
	}

	public void setSqlQuery(String sqlQuery) {
		this.sqlQuery = sqlQuery;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLookUpFlag() {
		return lookUpFlag;
	}

	public void setLookUpFlag(String lookUpFlag) {
		this.lookUpFlag = lookUpFlag;
	}

	public String getScheduledJobCall() {
		return scheduledJobCall;
	}

	public void setScheduledJobCall(String scheduledJobCall) {
		this.scheduledJobCall = scheduledJobCall;
	}

}
