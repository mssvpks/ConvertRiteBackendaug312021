package com.rite.products.convertrite.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "XXR_HCM_DATA_LOADER")
public class XxrHcmDataLoader {

	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "hcm_data_generator")
	@SequenceGenerator(name = "hcm_data_generator", sequenceName = "xxr_hcm_data_loader_id_s", allocationSize = 1)
	private long id;
	@Column(name = "CLOUD_TEMPLATE_ID")
	private long cloudTemplateId;
	@Column(name = "DOCUMENT_TITLE")
	private String documentTitle;
	@Column(name = "DOCUMENT_AUTHOR")
	private String documentAuthor;
	@Column(name = "DOCUMENT_SECURITY_GROUP")
	private String documentSecurityGroup;
	@Column(name = "DOCUMENT_ACCOUNT")
	private String documentAccount;
	@Column(name = "CONTENT_ID")
	private String contentId;
	@Column(name = "PROCESS_ID")
	private String processId;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getCloudTemplateId() {
		return cloudTemplateId;
	}

	public void setCloudTemplateId(long cloudTemplateId) {
		this.cloudTemplateId = cloudTemplateId;
	}

	public String getDocumentTitle() {
		return documentTitle;
	}

	public void setDocumentTitle(String documentTitle) {
		this.documentTitle = documentTitle;
	}

	public String getDocumentAuthor() {
		return documentAuthor;
	}

	public void setDocumentAuthor(String documentAuthor) {
		this.documentAuthor = documentAuthor;
	}

	public String getDocumentSecurityGroup() {
		return documentSecurityGroup;
	}

	public void setDocumentSecurityGroup(String documentSecurityGroup) {
		this.documentSecurityGroup = documentSecurityGroup;
	}

	public String getDocumentAccount() {
		return documentAccount;
	}

	public void setDocumentAccount(String documentAccount) {
		this.documentAccount = documentAccount;
	}

	public String getContentId() {
		return contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}

	public String getProcessId() {
		return processId;
	}

	public void setProcessId(String processId) {
		this.processId = processId;
	}

}
