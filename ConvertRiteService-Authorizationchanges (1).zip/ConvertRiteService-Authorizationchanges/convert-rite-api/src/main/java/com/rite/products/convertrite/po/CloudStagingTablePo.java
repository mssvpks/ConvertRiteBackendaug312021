package com.rite.products.convertrite.po;

public class CloudStagingTablePo {
	
	private String result;
	
	private String tableName;

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	
	

}
