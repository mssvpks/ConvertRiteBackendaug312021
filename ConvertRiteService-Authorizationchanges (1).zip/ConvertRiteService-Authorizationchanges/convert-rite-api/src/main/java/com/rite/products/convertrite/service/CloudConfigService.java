package com.rite.products.convertrite.service;

import org.springframework.stereotype.Service;

import com.rite.products.convertrite.model.XxrCloudDataProcessConfig;
import com.rite.products.convertrite.po.SaveCloudConfigDetailsResPo;
import com.rite.products.convertrite.po.SaveCloudConfigReqPo;

@Service
public interface CloudConfigService {

	XxrCloudDataProcessConfig getCloudConfig() throws Exception;

	SaveCloudConfigDetailsResPo saveCloudConfigDetails(SaveCloudConfigReqPo saveCloudConfigReqPo) throws Exception;

}
