package com.rite.products.convertrite.po;

public class XxrObjectCodeGroupingLinesResPo {

	private Long groupLineId;
	private Long groupId;
	private String groupName;
	private Long objectId;
	private String objectCode;

	public Long getGroupLineId() {
		return groupLineId;
	}

	public void setGroupLineId(Long groupLineId) {
		this.groupLineId = groupLineId;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public Long getObjectId() {
		return objectId;
	}

	public void setObjectId(Long objectId) {
		this.objectId = objectId;
	}

	public String getObjectCode() {
		return objectCode;
	}

	public void setObjectCode(String objectCode) {
		this.objectCode = objectCode;
	}

}
