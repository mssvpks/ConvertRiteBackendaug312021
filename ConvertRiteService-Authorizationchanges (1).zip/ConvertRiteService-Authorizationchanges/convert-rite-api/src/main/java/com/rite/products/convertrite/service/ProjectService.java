package com.rite.products.convertrite.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.rite.products.convertrite.po.ActivitiesPo;
import com.rite.products.convertrite.po.ActivitiesResPo;
import com.rite.products.convertrite.po.CopyProjectRequestPo;
import com.rite.products.convertrite.po.DataResPo;
import com.rite.products.convertrite.po.ProjectWbsPo;
import com.rite.products.convertrite.po.SaveProjectHeaderResponsePo;
import com.rite.products.convertrite.po.SaveProjectHeadersPo;
import com.rite.products.convertrite.po.TaskBreakDownPo;
import com.rite.products.convertrite.po.TaskOwnerLov;
import com.rite.products.convertrite.po.XxrActivitiesResPo;
import com.rite.products.convertrite.po.XxrProjectWbsResPo;
import com.rite.products.convertrite.po.XxrProjectsResPo;

public interface ProjectService {

	List<XxrProjectWbsResPo> loadWbs(Long projectId,Long podId,HttpServletRequest request) throws Exception;

	String loadTask(Long projectId,Long podId,HttpServletRequest request) throws Exception;

	SaveProjectHeaderResponsePo saveProjectHeaders(SaveProjectHeadersPo projectHeadersPo,HttpServletRequest request)throws Exception;

	List<XxrProjectsResPo> getAllProjectHeaders() throws Exception;

	List<XxrActivitiesResPo> getProjectLinesById(Long projectId,Long podId)throws Exception;

	DataResPo updateProjectWbsSelections(List<ProjectWbsPo> projectWbsPo) throws Exception;

	ActivitiesResPo upsertProjectActivities(List<ActivitiesPo> activitiesPo,HttpServletRequest request) throws Exception;

	List<String> getPreRequisiteTaskLov(Long projectId, String taskNumber,Long objectId,Long podId) throws Exception;
	
	List<TaskBreakDownPo> getTaskBreakDown(Long projectId,Long podId) throws Exception;

	SaveProjectHeaderResponsePo copyProject(CopyProjectRequestPo copyProjectRequest,HttpServletRequest request) throws Exception;

	List<TaskOwnerLov> getTaskOwnerLov(Long projectId)throws Exception;

}
