package com.rite.products.convertrite.po;

public class SaveObjectCodeGroupingPo {

	private String groupName;
	private String ctlFile;
	private String version;

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getCtlFile() {
		return ctlFile;
	}

	public void setCtlFile(String ctlFile) {
		this.ctlFile = ctlFile;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

}
