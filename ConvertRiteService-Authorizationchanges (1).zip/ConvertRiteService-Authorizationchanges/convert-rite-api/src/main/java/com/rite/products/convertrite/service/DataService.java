package com.rite.products.convertrite.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.rite.products.convertrite.model.XxrCloudDataProcess;
import com.rite.products.convertrite.model.XxrProcessJobs;
import com.rite.products.convertrite.model.XxrTemplateState;
import com.rite.products.convertrite.po.ProcessJobPo;
import com.rite.products.convertrite.po.ProcessRequestsPo;
import com.rite.products.convertrite.po.ProcessSourceDataResPo;
import com.rite.products.convertrite.po.SourceTemplateStatisticsRes;
import com.rite.products.convertrite.po.UpdateFailedRecReqPo;
import com.rite.products.convertrite.po.UpdateFailedRecResp;
import com.rite.products.convertrite.po.XxrSourceLoadFailRecordsResPo;

public interface DataService {

	String generateFbdi(String cloudTemplateName, HttpServletResponse response) throws Exception;

	ProcessJobPo processJob(String cloudTemplateName, String type,HttpServletRequest request) throws Exception;

	List<XxrProcessJobs> getProcessJobs() throws Exception;

	List<ProcessRequestsPo> getProcessRequests() throws Exception;

	List<XxrTemplateState> getTemplatesState() throws Exception;

	void getRecordsPostJobExecution(String cloudTemplateName, String status, String type, HttpServletResponse response)
			throws Exception;

	ProcessSourceDataResPo processSourceStagingData(String fileName, String templateName,HttpServletRequest request) throws Exception;

	//List<Object> getTemplatesStatistics(String filterBy) throws Exception;
	
	List<Object> getTemplatesStatistics() throws Exception;

	void processSourceData(String fileName, String templateName, String path) throws Exception;

	void exportFailedRecords(Long sourceTemplateId,Long id,HttpServletResponse response,String type)throws Exception;

	XxrSourceLoadFailRecordsResPo getStageDataLoadStatus(Long sourceTemplateId)throws Exception;

	void generateFbdiFromLob(Long cloudTemplateId, HttpServletResponse response)throws Exception;

	List<XxrSourceLoadFailRecordsResPo> getAllStageDataLoadStatus()throws Exception;

	List<SourceTemplateStatisticsRes> getSourceTemplatesStatistics()throws Exception;

	
	 List<XxrCloudDataProcess> processReconcile(Long cloudTemplateId,HttpServletRequest request) throws Exception;

	void processReconcileReport(Long cloudTemplateId, List<String> requestId, HttpServletResponse response)throws Exception;

	void generateHdlFromLob(Long cloudTemplateId, HttpServletResponse response)throws Exception;

	UpdateFailedRecResp updateEditedFailedRecords(UpdateFailedRecReqPo updateFailedRecReqPo)throws Exception;

	void getTransformationReport(Long cloudTemplateId, HttpServletResponse response)throws Exception;

}
