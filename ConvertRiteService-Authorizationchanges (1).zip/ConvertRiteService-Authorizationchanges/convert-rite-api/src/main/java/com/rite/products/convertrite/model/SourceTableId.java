package com.rite.products.convertrite.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class SourceTableId implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Column(name = "TABLE_ID")
	private long tableId;

	@Column(name = "TABLE_NAME")
	private String tableName;

	public long getTableId() {
		return tableId;
	}

	public void setTableId(long tableId) {
		this.tableId = tableId;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

}
