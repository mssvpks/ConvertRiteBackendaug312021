package com.rite.products.convertrite.po;

import java.util.List;

import com.rite.products.convertrite.model.SourceTemplateColumns;

public class SaveSourceTemplateColumnsResPo {

	private String message;
	private List<SourceTemplateColumns> sourceTemplateColumns;
	private String error;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<SourceTemplateColumns> getSourceTemplateColumns() {
		return sourceTemplateColumns;
	}

	public void setSourceTemplateColumns(List<SourceTemplateColumns> sourceTemplateColumns) {
		this.sourceTemplateColumns = sourceTemplateColumns;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

}
