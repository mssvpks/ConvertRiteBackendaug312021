package com.rite.products.convertrite.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "XXR_CLOUD_DATA_PROCESS")
public class XxrCloudDataProcess {

	@Id
	@Column(name = "REQUEST_ID")
	private String requestId;
	@Column(name = "SQLQUERY")
	private String sqlQuery;
	@Column(name = "DESCRIPTION")
	private String description;
	@Column(name = "PATH")
	private String path;
	@Column(name = "STATUS")
	private String status;
	@Column(name = "LOOKUP_FLAG")
	private String lookupFlag;
	@Column(name = "SCHEDULED_JOB_CALL")
	private String scheduledJobCall;
	@Column(name = "CREATION_DATE")
	private Date creationDate;
	@Column(name = "LAST_UPDATE_DATE")
	private Date lastUpdatedDate;
	@Column(name="PRIORITY")
	private Integer priority;
	
	

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getScheduledJobCall() {
		return scheduledJobCall;
	}

	public void setScheduledJobCall(String scheduledJobCall) {
		this.scheduledJobCall = scheduledJobCall;
	}

	public String getLookupFlag() {
		return lookupFlag;
	}

	public void setLookupFlag(String lookupFlag) {
		this.lookupFlag = lookupFlag;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getSqlQuery() {
		return sqlQuery;
	}

	public void setSqlQuery(String sqlQuery) {
		this.sqlQuery = sqlQuery;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
