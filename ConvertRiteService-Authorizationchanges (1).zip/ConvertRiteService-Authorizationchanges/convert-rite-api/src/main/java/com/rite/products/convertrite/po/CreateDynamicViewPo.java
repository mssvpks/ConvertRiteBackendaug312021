package com.rite.products.convertrite.po;

public class CreateDynamicViewPo {

	private String result;
	private String viewName;

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getViewName() {
		return viewName;
	}

	public void setViewName(String viewName) {
		this.viewName = viewName;
	}

}
