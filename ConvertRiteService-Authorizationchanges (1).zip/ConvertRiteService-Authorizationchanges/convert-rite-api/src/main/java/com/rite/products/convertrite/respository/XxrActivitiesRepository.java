package com.rite.products.convertrite.respository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.rite.products.convertrite.model.XxrActivities;
@Repository
public interface XxrActivitiesRepository extends JpaRepository<XxrActivities,Long>{
	
	List<XxrActivities> findByprojectId(Long projectId);
	
	
	@Query("select c from XxrActivities c where c.projectId=:projectId and c.podId=:podId order by c.seq asc")
	List<XxrActivities> getActivityLinesById(@Param("projectId") Long projectId,@Param("podId") Long podId);
	
	@Query("select taskId from XxrActivities where taskNum=:preReqTask and projectId=:projectId")
	public Long getTaskIdByPreReqTask(@Param("preReqTask") String preReqTask,@Param("projectId") Long projectId);
	
	@Query("select c from XxrActivities c where c.taskOwnerId=:userId")
 	List<XxrActivities> getActivityByTaskOwnerId(@Param("userId") Long userId);
	
	


}
