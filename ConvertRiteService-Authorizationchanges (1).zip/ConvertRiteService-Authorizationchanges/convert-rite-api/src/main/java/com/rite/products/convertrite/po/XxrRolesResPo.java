package com.rite.products.convertrite.po;

import com.rite.products.convertrite.model.XxrRoles;

public class XxrRolesResPo {

	private XxrRoles xxrRoles;
	private String message;
	private String error;

	public XxrRoles getXxrRoles() {
		return xxrRoles;
	}

	public void setXxrRoles(XxrRoles xxrRoles) {
		this.xxrRoles = xxrRoles;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

}
