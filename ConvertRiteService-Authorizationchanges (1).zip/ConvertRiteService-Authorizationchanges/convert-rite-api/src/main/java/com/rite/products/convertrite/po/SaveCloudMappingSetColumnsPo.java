package com.rite.products.convertrite.po;

public class SaveCloudMappingSetColumnsPo {

	private Long mapSetId;
	private Long mapLineId;
	private String sourceField1;
	private String sourceField2;
	private String sourceField3;
	private String enabled;
	private String cloudValue;
	private String attribute1;
	private String attribute2;
	private String attribute3;
	private String attribute4;
	private String attribute5;

	public Long getMapSetId() {
		return mapSetId;
	}

	public void setMapSetId(Long mapSetId) {
		this.mapSetId = mapSetId;
	}

	public Long getMapLineId() {
		return mapLineId;
	}

	public void setMapLineId(Long mapLineId) {
		this.mapLineId = mapLineId;
	}

	public String getSourceField1() {
		return sourceField1;
	}

	public void setSourceField1(String sourceField1) {
		this.sourceField1 = sourceField1;
	}

	public String getSourceField2() {
		return sourceField2;
	}

	public void setSourceField2(String sourceField2) {
		this.sourceField2 = sourceField2;
	}

	public String getSourceField3() {
		return sourceField3;
	}

	public void setSourceField3(String sourceField3) {
		this.sourceField3 = sourceField3;
	}

	public String getEnabled() {
		return enabled;
	}

	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}

	public String getCloudValue() {
		return cloudValue;
	}

	public void setCloudValue(String cloudValue) {
		this.cloudValue = cloudValue;
	}

	public String getAttribute1() {
		return attribute1;
	}

	public void setAttribute1(String attribute1) {
		this.attribute1 = attribute1;
	}

	public String getAttribute2() {
		return attribute2;
	}

	public void setAttribute2(String attribute2) {
		this.attribute2 = attribute2;
	}

	public String getAttribute3() {
		return attribute3;
	}

	public void setAttribute3(String attribute3) {
		this.attribute3 = attribute3;
	}

	public String getAttribute4() {
		return attribute4;
	}

	public void setAttribute4(String attribute4) {
		this.attribute4 = attribute4;
	}

	public String getAttribute5() {
		return attribute5;
	}

	public void setAttribute5(String attribute5) {
		this.attribute5 = attribute5;
	}

}
