package com.rite.products.convertrite.respository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rite.products.convertrite.model.XxrProcessJobs;

public interface XxrProcessJobsRepository extends JpaRepository<XxrProcessJobs,Long>{

}
