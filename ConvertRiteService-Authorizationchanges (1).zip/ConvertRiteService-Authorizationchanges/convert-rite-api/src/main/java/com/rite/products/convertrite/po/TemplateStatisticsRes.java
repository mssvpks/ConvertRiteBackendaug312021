package com.rite.products.convertrite.po;

import java.util.List;

public class TemplateStatisticsRes {

	private String criteriaType;
	
	private List<TemplateStatisticsResPo> data;

	public String getCriteriaType() {
		return criteriaType;
	}

	public void setCriteriaType(String criteriaType) {
		this.criteriaType = criteriaType;
	}

	public List<TemplateStatisticsResPo> getData() {
		return data;
	}

	public void setData(List<TemplateStatisticsResPo> data) {
		this.data = data;
	}
	
	
	
	
}
