# ConvertRiteService
A Service that encapsulates the processes involved in Convert Rite product and provides a REST end point to interact with the Convert Rite Schema
